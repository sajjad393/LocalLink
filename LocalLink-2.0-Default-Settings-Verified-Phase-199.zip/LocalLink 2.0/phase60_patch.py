from pathlib import Path

root = Path('/mnt/data/locallink-phase60')

sf = root/'flutter/lib/core/security/sensitive_file_protection_service.dart'
s = sf.read_text()
# Add lifecycle constants/helpers.
s = s.replace("  static const _magic = 'LLFILE1';\n", "  static const _magic = 'LLFILE1';\n  static const protectedPartSuffix = '.enc.part';\n  static const plaintextPartSuffix = '.plain.part';\n  static const viewPrefix = '.view-';\n  static const Duration viewRetention = Duration(minutes: 5);\n  static const Duration stalePlaintextRetention = Duration(minutes: 5);\n  static const Duration staleProtectedTempRetention = Duration(hours: 1);\n")
# Replace protectFile body with path safety and safer temp naming.
old = '''  Future<void> protectFile(String plaintextPath, String protectedPath) async {\n    final source = File(plaintextPath);\n    if (!await source.exists()) throw StateError('local source file does not exist');\n    final plaintext = await source.readAsBytes();\n    final box = await _aes.encrypt(plaintext, secretKey: await _key(), aad: utf8.encode(_magic));\n    final encoded = <int>[\n      ...utf8.encode(_magic),\n      box.nonce.length,\n      box.mac.bytes.length,\n      ...box.nonce,\n      ...box.mac.bytes,\n      ...box.cipherText,\n    ];\n    final part = File('$protectedPath.part');\n    await part.writeAsBytes(encoded, flush: true);\n    final output = File(protectedPath);\n    if (await output.exists()) await output.delete();\n    await part.rename(protectedPath);\n  }\n'''
new = '''  Future<void> protectFile(String plaintextPath, String protectedPath) async {\n    final source = File(plaintextPath);\n    final output = File(protectedPath);\n    if (!await source.exists()) throw StateError('local source file does not exist');\n    _assertAttachmentPath(source.path);\n    _assertAttachmentPath(output.path);\n    final plaintext = await source.readAsBytes();\n    final box = await _aes.encrypt(plaintext, secretKey: await _key(), aad: utf8.encode(_magic));\n    final encoded = <int>[\n      ...utf8.encode(_magic),\n      box.nonce.length,\n      box.mac.bytes.length,\n      ...box.nonce,\n      ...box.mac.bytes,\n      ...box.cipherText,\n    ];\n    final part = File('${output.path}$protectedPartSuffix');\n    await part.writeAsBytes(encoded, flush: true);\n    try {\n      if (await output.exists()) await output.delete();\n      await part.rename(output.path);\n    } catch (_) {\n      try { await part.delete(); } catch (_) {}\n      rethrow;\n    }\n  }\n'''
if old not in s:
    raise SystemExit('protectFile block not found')
s = s.replace(old, new)
# Harden materialize path and extension, no direct arbitrary paths.
s = s.replace("    final input = File(protectedPath);\n    if (!await input.exists()) throw StateError('protected file does not exist');\n", "    final input = File(protectedPath);\n    _assertAttachmentPath(input.path);\n    if (!await input.exists()) throw StateError('protected file does not exist');\n")
s = s.replace("    final normalizedExtension = extension.startsWith('.') ? extension : '.$extension';\n", "    final normalizedExtension = _safeViewExtension(extension);\n")
s = s.replace("    final view = File('${root.path}/.view-$id$normalizedExtension');\n", "    final view = File('${root.path}/$viewPrefix$id$normalizedExtension');\n")
# Replace cleanupViewCopies with broader lifecycle cleanup.
start = s.index("  /// Removes any decrypted temporary view copies")
end = s.index("  Future<bool> isProtected", start)
replacement = '''  /// Removes decrypted views and temporary plaintext artifacts that may survive\n  /// a force-kill. Durable protected attachments are never removed by this method.\n  Future<void> cleanupSensitiveArtifacts(Directory directory, {DateTime? now}) async {\n    try {\n      if (!await directory.exists()) return;\n      final cutoff = (now ?? DateTime.now()).subtract(viewRetention);\n      final plainCutoff = (now ?? DateTime.now()).subtract(stalePlaintextRetention);\n      final protectedCutoff = (now ?? DateTime.now()).subtract(staleProtectedTempRetention);\n      await for (final entry in directory.list(followLinks: false)) {\n        if (entry is! File) continue;\n        final name = entry.path.split(Platform.pathSeparator).last;\n        try {\n          final modified = await entry.lastModified();\n          if (name.startsWith(viewPrefix) && modified.isBefore(cutoff)) {\n            await entry.delete();\n          } else if (name.endsWith(plaintextPartSuffix) && modified.isBefore(plainCutoff)) {\n            await entry.delete();\n          } else if (name.endsWith(protectedPartSuffix) && modified.isBefore(protectedCutoff)) {\n            await entry.delete();\n          }\n        } catch (_) {}\n      }\n    } catch (_) {}\n  }\n\n  /// Backward-compatible alias retained for callers that only need view cleanup.\n  Future<void> cleanupViewCopies(Directory directory) => cleanupSensitiveArtifacts(directory);\n\n  void _assertAttachmentPath(String path) {\n    final value = File(path).absolute;\n    final parent = value.parent.absolute.path;\n    final name = value.path.split(Platform.pathSeparator).last;\n    // The service is only allowed to handle files inside the app's attachments\n    // directory. This prevents a malformed DB/local-path value from turning\n    // protect/delete/view operations into arbitrary filesystem access.\n    if (!parent.endsWith('${Platform.pathSeparator}attachments') && !parent.contains('${Platform.pathSeparator}attachments${Platform.pathSeparator}')) {\n      throw StateError('local attachment path is outside protected storage');\n    }\n    if (name.isEmpty || name.contains(Platform.pathSeparator)) throw StateError('invalid local attachment path');\n  }\n\n  String _safeViewExtension(String extension) {\n    final normalized = extension.startsWith('.') ? extension : '.$extension';\n    if (!RegExp(r'^\\.[A-Za-z0-9]{1,10}$').hasMatch(normalized)) return '.bin';\n    return normalized.toLowerCase();\n  }\n\n'''
s = s[:start] + replacement + s[end:]
s = s.replace("  Future<bool> isProtected(String path) async {\n", "  Future<bool> isProtected(String path) async {\n    try { _assertAttachmentPath(path); } catch (_) { return false; }\n")
sf.write_text(s)

fts = root/'flutter/lib/features/files/data/services/file_transfer_service.dart'
s = fts.read_text()
# Distinguish plaintext partials from protected temp files.
s = s.replace("final temp = File('$target.part');", "final temp = File('$target${SensitiveFileProtectionService.plaintextPartSuffix}');")
s = s.replace("final part = File('$target.part');", "final part = File('$target${SensitiveFileProtectionService.plaintextPartSuffix}');")
# Harden direct deletion to only attachment storage and clear active clients on cache reset.
old = '''  Future<void> deleteLocalFile(String path) async {\n    final value = path.trim();\n    if (value.isEmpty) return;\n    try {\n      final file = File(value);\n      if (await file.exists()) await file.delete();\n    } catch (_) {}\n  }\n\n  Future<void> cleanupSensitiveViewCopies() async {\n    try {\n      final root = await getDatabasesPath();\n      await sensitiveFiles.cleanupViewCopies(Directory('$root/attachments'));\n    } catch (_) {}\n  }\n\n  Future<void> clearLocalCache() async {\n    try {\n      final root = await getDatabasesPath();\n      final dir = Directory('$root/attachments');\n      if (await dir.exists()) await dir.delete(recursive: true);\n    } catch (_) {}\n  }\n'''
new = '''  Future<void> deleteLocalFile(String path) async {\n    final value = path.trim();\n    if (value.isEmpty) return;\n    try {\n      final root = await getDatabasesPath();\n      final dir = Directory('$root/attachments');\n      final file = File(value);\n      final attachmentRoot = await dir.resolveSymbolicLinks();\n      final candidate = await file.parent.resolveSymbolicLinks();\n      if (candidate != attachmentRoot && !candidate.startsWith('$attachmentRoot${Platform.pathSeparator}')) return;\n      await file.delete();\n    } catch (_) {}\n  }\n\n  Future<void> cleanupSensitiveViewCopies() async {\n    try {\n      final root = await getDatabasesPath();\n      await sensitiveFiles.cleanupSensitiveArtifacts(Directory('$root/attachments'));\n    } catch (_) {}\n  }\n\n  Future<void> cleanupSensitiveArtifacts() => cleanupSensitiveViewCopies();\n\n  Future<void> clearLocalCache() async {\n    for (final client in _activeClients.values) {\n      try { client.close(); } catch (_) {}\n    }\n    _activeClients.clear();\n    _cancelledTransfers.clear();\n    try {\n      final root = await getDatabasesPath();\n      final dir = Directory('$root/attachments');\n      if (await dir.exists()) await dir.delete(recursive: true);\n    } catch (_) {}\n  }\n'''
if old not in s:
    raise SystemExit('file service lifecycle block not found')
s = s.replace(old, new)
# Ensure successful plaintext download removes part after protect; existing flow already does.
fts.write_text(s)

rms = root/'flutter/lib/features/messaging/data/services/reliable_messaging_service.dart'
s = rms.read_text()
old = '''      _recentDirectFiles[fileId!] = meta;\n      await store.saveDirectFile(\n        fileId: fileId, messageId: messageId!, senderId: senderId!, localPath: path!,\n'''
new = '''      // Native direct-file reception uses app-private plaintext only as a short-lived\n      // handoff. Convert it to Flutter's protected attachment format before persisting\n      // the path in the local DB. Any crash before this handoff is bounded by the\n      // native stale-file cleanup policy.\n      final protectedPath = await files.protectLegacyLocalFile(path!);\n      _recentDirectFiles[fileId!] = {...meta, 'path': protectedPath};\n      await store.saveDirectFile(\n        fileId: fileId, messageId: messageId!, senderId: senderId!, localPath: protectedPath,\n'''
if old not in s:
    raise SystemExit('direct file event block not found')
s = s.replace(old, new)
rms.write_text(s)

# Add lifecycle cleanup on app pause/inactive/detached.
app = root/'flutter/lib/app/local_link_app.dart'
s = app.read_text()
s = s.replace("    if (state == AppLifecycleState.resumed && _configured) {\n", "    if (state != AppLifecycleState.resumed) {\n      unawaited(_deps.files.cleanupSensitiveArtifacts());\n    }\n    if (state == AppLifecycleState.resumed && _configured) {\n      unawaited(_deps.files.cleanupSensitiveArtifacts());\n")
app.write_text(s)

# Add native stale direct-file cleanup helper: plaintext direct-file payloads are only a short-lived handoff.
kt = root/'flutter/android/app/src/main/kotlin/com/sajjad/locallink/LocalLinkTransportService.kt'
s = kt.read_text()
needle = '''        d.listFiles()?.forEach{f->\n            val staleCutoff = if (f.name.startsWith(".done_")) DirectFileTransferPolicy.COMPLETION_MARKER_RETENTION_MS else DirectFileTransferPolicy.IDLE_TIMEOUT_MS\n            if((f.name.endsWith(".part")||f.name.endsWith(".meta.json")||f.name.endsWith(".out.json")||f.name.startsWith(".done_"))&&now-f.lastModified()>staleCutoff)try{f.delete()}catch(_:Exception){}\n        }\n'''
replacement = '''        d.listFiles()?.forEach{f->\n            val staleCutoff = if (f.name.startsWith(".done_")) DirectFileTransferPolicy.COMPLETION_MARKER_RETENTION_MS else DirectFileTransferPolicy.IDLE_TIMEOUT_MS\n            if((f.name.endsWith(".part")||f.name.endsWith(".meta.json")||f.name.endsWith(".out.json")||f.name.startsWith(".done_"))&&now-f.lastModified()>staleCutoff)try{f.delete()}catch(_:Exception){}\n            // Native direct-file delivery creates a plaintext final file only until\n            // Flutter receives the event and converts it to protected storage.\n            // Never retain an orphaned plaintext final file after a process crash.\n            if(!f.name.startsWith(".done_")&&!f.name.endsWith(".part")&&!f.name.endsWith(".meta.json")&&!f.name.endsWith(".out.json")&&now-f.lastModified()>DirectFileTransferPolicy.IDLE_TIMEOUT_MS){\n                try{f.delete()}catch(_:Exception){}\n            }\n        }\n'''
if needle not in s:
    raise SystemExit('native cleanup block not found')
s = s.replace(needle, replacement)
kt.write_text(s)

# Add phase documentation and audit script.
phase = root/'PHASE_60_SENSITIVE_FILE_LIFECYCLE.md'
phase.write_text('''# PHASE 60 — Sensitive File Lifecycle\n\n## Scope\n- Remove persistent plaintext attachment paths.\n- Bound decrypted view-copy lifetime.\n- Remove stale plaintext partial downloads after interruption/restart.\n- Harden local-file deletion and protection operations to app-private attachment storage.\n- Convert native direct-file plaintext handoff to protected Flutter storage before DB persistence.\n- Clean sensitive artifacts on startup, lifecycle transitions and cache reset.\n\n## Implementation\n- `SensitiveFileProtectionService` now has explicit lifecycle constants and stale-artifact cleanup.\n- Protected-file temporary writes use `.enc.part`; plaintext transfer partials use `.plain.part`.\n- `FileTransferService.deleteLocalFile` refuses paths outside the app attachment directory.\n- Native `file_received` handoff is protected before `direct_files.local_path` is persisted.\n- Native transport removes stale orphaned plaintext direct-file final files after the transfer idle timeout.\n- App startup and non-resumed lifecycle transitions trigger sensitive-artifact cleanup.\n\n## Verification gates\n- Structural scans for sensitive temporary patterns.\n- Dart import consistency scan.\n- Kotlin delimiter/static policy scan.\n- Backend compile/vet regression scan.\n- Sensitive lifecycle unit tests for cleanup classification and path policy.\n\n## Runtime limitations\n- Flutter SDK and Android runtime are not available in the current environment; physical Android lifecycle/crash testing remains a release gate.\n''')

# Add a lightweight static audit script.
audit = root/'scripts/sensitive-file-audit-060-static-audit.sh'
audit.write_text('''#!/usr/bin/env bash\nset -euo pipefail\nROOT="$(cd "$(dirname "$0")/.." && pwd)"\nfail=0\nrequire() { if ! grep -Fq -- "$1" "$2"; then echo "MISSING: $1 in $2"; fail=1; fi; }\nrequire "protectedPartSuffix = '.enc.part'" "$ROOT/flutter/lib/core/security/sensitive_file_protection_service.dart"\nrequire "plaintextPartSuffix = '.plain.part'" "$ROOT/flutter/lib/core/security/sensitive_file_protection_service.dart"\nrequire "cleanupSensitiveArtifacts" "$ROOT/flutter/lib/core/security/sensitive_file_protection_service.dart"\nrequire "local attachment path is outside protected storage" "$ROOT/flutter/lib/core/security/sensitive_file_protection_service.dart"\nrequire "final protectedPath = await files.protectLegacyLocalFile(path!)" "$ROOT/flutter/lib/features/messaging/data/services/reliable_messaging_service.dart"\nrequire "cleanupSensitiveArtifacts()" "$ROOT/flutter/lib/app/local_link_app.dart"\nrequire "Never retain an orphaned plaintext final file" "$ROOT/flutter/android/app/src/main/kotlin/com/sajjad/locallink/LocalLinkTransportService.kt"\nif grep -RIn --include='*.dart' --include='*.kt' --exclude-dir='.dart_tool' '\\.view-.*deleteLocalFile' "$ROOT/flutter" >/dev/null; then :; fi\nif [[ $fail -ne 0 ]]; then exit 1; fi\necho "PHASE 60 sensitive-file lifecycle static audit: PASS"\n''')
audit.chmod(0o755)

# Update status README succinctly.
status = root/'AUDIT-ALL-STATUS.md'
ss = status.read_text()
ss = ss.replace('AUDIT-023: COMPLETE', 'AUDIT-023: COMPLETE\nPHASE-60: COMPLETE — sensitive file lifecycle hardening') if 'PHASE-60' not in ss else ss
status.write_text(ss)

print('patched')
