from pathlib import Path

root = Path('/mnt/data/locallink-phase57-work')

# ---- Backend concurrency gates ----
p = root/'backend/internal/httpapi/api.go'
s = p.read_text()
s = s.replace('''\tfileRoot      string\n\tmaxFileSize   int64\n\tpresenceMu    sync.RWMutex\n''','''\tfileRoot          string\n\tmaxFileSize       int64\n\tfileUploadGate    chan struct{}\n\tfileDownloadGate  chan struct{}\n\tpresenceMu        sync.RWMutex\n''')
s = s.replace('''api := &API{store: s, hub: ws.NewHub(), rates: make(map[string]messageRate), regRates: make(map[string]messageRate), securityRates: make(map[string]messageRate), fileRoot: root, maxFileSize: maxFileSize, presence: make(map[string]DevicePresence)}''','''api := &API{\n\t\tstore: s,\n\t\thub: ws.NewHub(),\n\t\trates: make(map[string]messageRate),\n\t\tregRates: make(map[string]messageRate),\n\t\tsecurityRates: make(map[string]messageRate),\n\t\tfileRoot: root,\n\t\tmaxFileSize: maxFileSize,\n\t\tfileUploadGate: make(chan struct{}, 8),\n\t\tfileDownloadGate: make(chan struct{}, 16),\n\t\tpresence: make(map[string]DevicePresence),\n\t}''')
p.write_text(s)

p = root/'backend/internal/httpapi/attachments.go'
s = p.read_text()
s = s.replace('''func (a *API) UploadFile(w http.ResponseWriter, r *http.Request) {\n\towner, ok := a.authorizeDevice(r)''','''func (a *API) UploadFile(w http.ResponseWriter, r *http.Request) {\n\tselect {\n\tcase a.fileUploadGate <- struct{}{}:\n\t\tdefer func() { <-a.fileUploadGate }()\n\tdefault:\n\t\tw.Header().Set("Retry-After", "5")\n\t\twriteError(w, http.StatusTooManyRequests, "too many concurrent file transfers")\n\t\treturn\n\t}\n\towner, ok := a.authorizeDevice(r)''')
s = s.replace('''func (a *API) DownloadFile(w http.ResponseWriter, r *http.Request) {\n\tdeviceID, ok := a.authorizeDevice(r)''','''func (a *API) DownloadFile(w http.ResponseWriter, r *http.Request) {\n\tselect {\n\tcase a.fileDownloadGate <- struct{}{}:\n\t\tdefer func() { <-a.fileDownloadGate }()\n\tdefault:\n\t\tw.Header().Set("Retry-After", "5")\n\t\twriteError(w, http.StatusTooManyRequests, "too many concurrent file transfers")\n\t\treturn\n\t}\n\tdeviceID, ok := a.authorizeDevice(r)''')
s = s.replace('''func (a *API) DownloadThumbnail(w http.ResponseWriter, r *http.Request) {\n\tdeviceID, ok := a.authorizeDevice(r)''','''func (a *API) DownloadThumbnail(w http.ResponseWriter, r *http.Request) {\n\tselect {\n\tcase a.fileDownloadGate <- struct{}{}:\n\t\tdefer func() { <-a.fileDownloadGate }()\n\tdefault:\n\t\tw.Header().Set("Retry-After", "5")\n\t\twriteError(w, http.StatusTooManyRequests, "too many concurrent file transfers")\n\t\treturn\n\t}\n\tdeviceID, ok := a.authorizeDevice(r)''')
p.write_text(s)

# ---- Native transfer policy ----
policy = root/'flutter/android/app/src/main/kotlin/com/sajjad/locallink/DirectFileTransferPolicy.kt'
policy.write_text(r'''package com.sajjad.locallink\n\n/** Central resource and lifecycle policy for resumable direct file transfers. */\ninternal object DirectFileTransferPolicy {\n    const val MAX_DIRECT_FILE_SIZE = 50L * 1024L * 1024L\n    const val CHUNK_SIZE = 48 * 1024\n    const val MAX_ACTIVE_INCOMING_TRANSFERS = 8\n    const val MAX_ACTIVE_OUTGOING_TRANSFERS = 8\n    const val MAX_ACTIVE_TRANSFER_BYTES = 256L * 1024L * 1024L\n    const val IDLE_TIMEOUT_MS = 10L * 60L * 1000L\n    const val MAX_RETRY_ATTEMPTS = 8\n    const val COMPLETION_MARKER_RETENTION_MS = 24L * 60L * 60L * 1000L\n\n    fun expectedChunks(size: Long): Int {\n        require(size in 0L..MAX_DIRECT_FILE_SIZE)\n        if (size == 0L) return 1\n        return ((size + CHUNK_SIZE - 1L) / CHUNK_SIZE).toInt()\n    }\n\n    fun validTransferSize(size: Long): Boolean = size in 0L..MAX_DIRECT_FILE_SIZE\n\n    fun activeBytes(sizes: Collection<Long>): Long = sizes.sumOf { it.coerceAtLeast(0L) }\n}\n''')

# ---- Native service changes ----
p = root/'flutter/android/app/src/main/kotlin/com/sajjad/locallink/LocalLinkTransportService.kt'
s = p.read_text()
s = s.replace('''    private val directChunkSize = 48 * 1024\n    private val maxDirectFileSize = 50L * 1024L * 1024L''','''    private val directChunkSize = DirectFileTransferPolicy.CHUNK_SIZE\n    private val maxDirectFileSize = DirectFileTransferPolicy.MAX_DIRECT_FILE_SIZE''')
s = s.replace('''    private val outgoingTransfers = ConcurrentHashMap<String, OutgoingFileTransfer>()\n    private val cancelledDirectTransfers = ConcurrentHashMap.newKeySet<String>()''','''    private val outgoingTransfers = ConcurrentHashMap<String, OutgoingFileTransfer>()\n    private val cancelledDirectTransfers = ConcurrentHashMap.newKeySet<String>()\n    private val outgoingSendInFlight = ConcurrentHashMap.newKeySet<String>()\n    private val outgoingRetryCounts = ConcurrentHashMap<String, Int>()''')

# Cap sendFileTransportInternal before creating a new transfer, while preserving existing transfer resume.
old = '''    private fun sendFileTransportInternal(target:String,path:String,fileId:String,messageId:String,fileName:String,contentType:String,cb:(Boolean,String?)->Unit){if(!transportRunning){cb(false,"transport is not configured");return};if(!validTransportId(target)||!validFileTransferId(fileId)||!validFileTransferId(messageId)){cb(false,"invalid file transfer identifier");return};if(!validContentType(contentType)){cb(false,"invalid content type");return};val f=File(path);if(!f.isFile){cb(false,"selected file is no longer available");return};if(f.length()>maxDirectFileSize){cb(false,"direct file size exceeds 50 MiB");return};Thread{try{val t=prepareOutgoingTransfer(target,f,fileId,messageId,fileName,contentType);persistOutgoingTransfer(t);sendMissingChunks(t,true);transportEvent("file_queued",mapOf("transfer_id" to t.transferId,"message_id" to messageId,"size" to t.size,"total_chunks" to t.totalChunks));cb(true,null)}catch(e:Exception){cb(false,e.message)}}.start()}'''
new = '''    private fun sendFileTransportInternal(target:String,path:String,fileId:String,messageId:String,fileName:String,contentType:String,cb:(Boolean,String?)->Unit){\n        if(!transportRunning){cb(false,"transport is not configured");return}\n        if(!validTransportId(target)||!validFileTransferId(fileId)||!validFileTransferId(messageId)){cb(false,"invalid file transfer identifier");return}\n        if(!validContentType(contentType)){cb(false,"invalid content type");return}\n        val f=File(path)\n        if(!f.isFile){cb(false,"selected file is no longer available");return}\n        if(f.length()>maxDirectFileSize){cb(false,"direct file size exceeds 50 MiB");return}\n        synchronized(outgoingTransfers){\n            val existing=outgoingTransfers[fileId]\n            if(existing==null){\n                if(outgoingTransfers.size>=DirectFileTransferPolicy.MAX_ACTIVE_OUTGOING_TRANSFERS){cb(false,"too many active outgoing file transfers");return}\n                val activeBytes=DirectFileTransferPolicy.activeBytes(outgoingTransfers.values.map{it.size})\n                if(activeBytes > DirectFileTransferPolicy.MAX_ACTIVE_TRANSFER_BYTES-f.length()){cb(false,"active outgoing file byte budget exceeded");return}\n            }\n        }\n        Thread{try{val t=prepareOutgoingTransfer(target,f,fileId,messageId,fileName,contentType);persistOutgoingTransfer(t);sendMissingChunks(t,true);transportEvent("file_queued",mapOf("transfer_id" to t.transferId,"message_id" to messageId,"size" to t.size,"total_chunks" to t.totalChunks));cb(true,null)}catch(e:Exception){cb(false,e.message)}}.start()\n    }'''
if old not in s:
    raise SystemExit('sendFileTransportInternal pattern missing')
s = s.replace(old,new)

# incoming active limits + exact expected chunk validation + aggregate size before allocation
s = s.replace('''        synchronized(incomingFiles) {\n            if (incomingFiles.size > 32 && !incomingFiles.containsKey(transferId)) return''','''        synchronized(incomingFiles) {\n            if (incomingFiles.size >= DirectFileTransferPolicy.MAX_ACTIVE_INCOMING_TRANSFERS && !incomingFiles.containsKey(transferId)) return\n            if (transferId.isNotEmpty() && size >= 0L) {\n                val activeBytes=DirectFileTransferPolicy.activeBytes(incomingFiles.values.map{it.size})\n                if (!incomingFiles.containsKey(transferId) && activeBytes > DirectFileTransferPolicy.MAX_ACTIVE_TRANSFER_BYTES-size) return\n            }''')
s = s.replace('''            val expectedChunks = if (size == 0L) 1 else ((size + directChunkSize - 1L) / directChunkSize).toInt()''','''            val expectedChunks = try { DirectFileTransferPolicy.expectedChunks(size) } catch (_: Exception) { return }''')

# Sync completed incoming chunk before metadata.
s = s.replace('''                transfer.file.write(data)\n                transfer.received[index]=true;transfer.updatedAt=System.currentTimeMillis();persistIncomingTransfer(transfer);''','''                transfer.file.write(data)\n                transfer.file.fd.sync()\n                transfer.received[index]=true;transfer.updatedAt=System.currentTimeMillis();persistIncomingTransfer(transfer);''')

# Completion marker cleanup and transfer stale cleanup.
s = s.replace('''        d.listFiles()?.forEach{f->\n            if((f.name.endsWith(".part")||f.name.endsWith(".meta.json")||f.name.endsWith(".out.json"))&&now-f.lastModified()>24*60*60*1000L)try{f.delete()}catch(_:Exception){}\n        }''','''        d.listFiles()?.forEach{f->\n            val staleCutoff = if (f.name.startsWith(".done_")) DirectFileTransferPolicy.COMPLETION_MARKER_RETENTION_MS else DirectFileTransferPolicy.IDLE_TIMEOUT_MS\n            if((f.name.endsWith(".part")||f.name.endsWith(".meta.json")||f.name.endsWith(".out.json")||f.name.startsWith(".done_"))&&now-f.lastModified()>staleCutoff)try{f.delete()}catch(_:Exception){}\n        }\n        incomingFiles.entries.toList().forEach { (id, transfer) ->\n            if (now - transfer.updatedAt > DirectFileTransferPolicy.IDLE_TIMEOUT_MS) {\n                if (incomingFiles.remove(id, transfer)) {\n                    try { transfer.file.close() } catch (_: Exception) {}\n                    try { File(transfer.path).delete() } catch (_: Exception) {}\n                    deleteIncomingMeta(transfer)\n                    transportEvent("file_expired", mapOf("transfer_id" to id, "message_id" to transfer.messageId, "file_id" to transfer.fileId))\n                }\n            }\n        }''')

# Add path containment helper and strengthen restoreIncomingTransfers with exact metadata checks.
old = '''    private fun restoreIncomingTransfers(){val d=File(filesDir,"locallink_direct_files");d.listFiles{f->f.name.endsWith(".meta.json")}?.forEach{f->try{val j=JSONObject(f.readText());val total=j.optInt("total_chunks");if (j.optString("crypto_version") != DirectFileSecurity.CRYPTO_VERSION) { f.delete(); return@forEach };val part=File(j.optString("path"));if(total<1||!part.isFile){f.delete();return@forEach};val t=IncomingFileTransfer(j.optString("transfer_id"),j.optString("file_id"),j.optString("message_id"),j.optString("sender_id"),safeFileName(j.optString("file_name")),j.optString("content_type","application/octet-stream"),j.optLong("size",-1),j.optString("sha256"),total,part.absolutePath,RandomAccessFile(part,"rw"),bitsetDecode(j.optString("received"),total),j.optLong("updated_at",f.lastModified()));if(t.size>=0)incomingFiles[t.transferId]=t else f.delete()}catch(_:Exception){f.delete()}}}'''
# The exact current line is huge; replace with a simpler function using signature slice.
start = s.find('    private fun restoreIncomingTransfers(){')
end = s.find('\n    private fun prepareOutgoingTransfer', start)
if start < 0 or end < 0:
    raise SystemExit('restoreIncomingTransfers block missing')
new_block = '''    private fun isInsideDirectory(file: File, directory: File): Boolean {\n        return try {\n            val root = directory.canonicalFile\n            val candidate = file.canonicalFile\n            candidate.path == root.path || candidate.path.startsWith(root.path + File.separator)\n        } catch (_: Exception) { false }\n    }\n\n    private fun restoreIncomingTransfers(){\n        val d=File(filesDir,"locallink_direct_files").apply{mkdirs()}\n        d.listFiles{f->f.name.endsWith(".meta.json")}?.forEach{f->try{\n            val j=JSONObject(f.readText())\n            val total=j.optInt("total_chunks")\n            val transferId=j.optString("transfer_id")\n            val fileId=j.optString("file_id")\n            val messageId=j.optString("message_id")\n            val senderId=j.optString("sender_id")\n            val size=j.optLong("size",-1)\n            val sha=j.optString("sha256").lowercase()\n            if(j.optString("crypto_version") != DirectFileSecurity.CRYPTO_VERSION ||\n                !validFileTransferId(transferId) || !validFileTransferId(fileId) || !validFileTransferId(messageId) ||\n                !validTransportId(senderId) || !DirectFileTransferPolicy.validTransferSize(size) || sha.length!=64 ||\n                total != DirectFileTransferPolicy.expectedChunks(size)) { f.delete(); return@forEach }\n            val part=File(j.optString("path"))\n            if(!isInsideDirectory(part,d) || !part.isFile || part.length()!=size){f.delete();try{part.delete()}catch(_:Exception){};return@forEach}\n            if(incomingFiles.size>=DirectFileTransferPolicy.MAX_ACTIVE_INCOMING_TRANSFERS ||\n                DirectFileTransferPolicy.activeBytes(incomingFiles.values.map{it.size}) > DirectFileTransferPolicy.MAX_ACTIVE_TRANSFER_BYTES-size){f.delete();try{part.delete()}catch(_:Exception){};return@forEach}\n            val t=IncomingFileTransfer(transferId,fileId,messageId,senderId,safeFileName(j.optString("file_name")),j.optString("content_type","application/octet-stream"),size,sha,total,part.absolutePath,RandomAccessFile(part,"rw"),bitsetDecode(j.optString("received"),total),j.optLong("updated_at",f.lastModified()))\n            incomingFiles[t.transferId]=t\n        }catch(_:Exception){f.delete()}}\n    }\n'''
s = s[:start] + new_block + s[end:]

# Strengthen restore outgoing limits and stale removal.
start = s.find('    private fun restoreOutgoingTransfers(){')
end = s.find('\n    private fun persistIncomingTransfer', start)
if start < 0 or end < 0:
    raise SystemExit('restoreOutgoing block missing')
new_block = '''    private fun restoreOutgoingTransfers(){\n        val d=File(filesDir,"locallink_direct_files").apply{mkdirs()}\n        val now=System.currentTimeMillis()\n        d.listFiles{f->f.name.endsWith(".out.json")}?.forEach{f->try{\n            val j=JSONObject(f.readText())\n            val total=j.optInt("total_chunks")\n            val transferId=j.optString("transfer_id")\n            val fileId=j.optString("file_id")\n            val messageId=j.optString("message_id")\n            val senderId=j.optString("sender_id")\n            val recipientId=j.optString("recipient_id")\n            val size=j.optLong("size",-1)\n            val sha=j.optString("sha256").lowercase()\n            val updatedAt=j.optLong("updated_at",f.lastModified())\n            if(j.optString("crypto_version") != DirectFileSecurity.CRYPTO_VERSION ||\n                !validFileTransferId(transferId) || !validFileTransferId(fileId) || !validFileTransferId(messageId) ||\n                !validTransportId(senderId) || !validTransportId(recipientId) ||\n                !DirectFileTransferPolicy.validTransferSize(size) || sha.length!=64 ||\n                total != DirectFileTransferPolicy.expectedChunks(size) ||\n                now-updatedAt>DirectFileTransferPolicy.IDLE_TIMEOUT_MS){f.delete();return@forEach}\n            if(outgoingTransfers.size>=DirectFileTransferPolicy.MAX_ACTIVE_OUTGOING_TRANSFERS ||\n                DirectFileTransferPolicy.activeBytes(outgoingTransfers.values.map{it.size}) > DirectFileTransferPolicy.MAX_ACTIVE_TRANSFER_BYTES-size){f.delete();return@forEach}\n            val source=File(j.optString("file_path"))\n            if(!source.isFile || source.length()!=size || sha256File(source)!=sha){f.delete();return@forEach}\n            val t=OutgoingFileTransfer(transferId,fileId,messageId,senderId,recipientId,source.absolutePath,safeFileName(j.optString("file_name")),j.optString("content_type","application/octet-stream"),size,sha,total,bitsetDecode(j.optString("acknowledged"),total),updatedAt)\n            outgoingTransfers[t.transferId]=t\n        }catch(_:Exception){f.delete()}}\n    }\n'''
s = s[:start] + new_block + s[end:]

# Atomic metadata writes: replace two compact one-line methods.
old = '    private fun persistOutgoingTransfer(t:OutgoingFileTransfer){File(filesDir,"locallink_direct_files").mkdirs();outgoingMetaFile(t.transferId).writeText(JSONObject().put("crypto_version",DirectFileSecurity.CRYPTO_VERSION).put("transfer_id",t.transferId).put("file_id",t.fileId).put("message_id",t.messageId).put("sender_id",t.senderId).put("recipient_id",t.recipientId).put("file_path",t.filePath).put("file_name",t.fileName).put("content_type",t.contentType).put("size",t.size).put("sha256",t.sha256).put("total_chunks",t.totalChunks).put("acknowledged",bitsetEncode(t.acknowledged)).put("updated_at",t.updatedAt).toString())}'
new = '''    private fun atomicWriteText(target: File, text: String) {\n        target.parentFile?.mkdirs()\n        val temp = File(target.parentFile, target.name + ".tmp")\n        java.io.FileOutputStream(temp).use { out ->\n            out.write(text.toByteArray(Charsets.UTF_8))\n            out.flush()\n            out.fd.sync()\n        }\n        if (!temp.renameTo(target)) {\n            temp.delete()\n            throw IllegalStateException("failed to commit transfer metadata")\n        }\n    }\n\n    private fun persistOutgoingTransfer(t:OutgoingFileTransfer){\n        atomicWriteText(outgoingMetaFile(t.transferId), JSONObject().put("crypto_version",DirectFileSecurity.CRYPTO_VERSION).put("transfer_id",t.transferId).put("file_id",t.fileId).put("message_id",t.messageId).put("sender_id",t.senderId).put("recipient_id",t.recipientId).put("file_path",t.filePath).put("file_name",t.fileName).put("content_type",t.contentType).put("size",t.size).put("sha256",t.sha256).put("total_chunks",t.totalChunks).put("acknowledged",bitsetEncode(t.acknowledged)).put("updated_at",t.updatedAt).toString())\n}'''
if old not in s: raise SystemExit('outgoing persist pattern missing')
s = s.replace(old,new)
old = '    private fun persistIncomingTransfer(t:IncomingFileTransfer){val m=File(t.path.removeSuffix(".part")+".meta.json");m.writeText(JSONObject().put("crypto_version",DirectFileSecurity.CRYPTO_VERSION).put("transfer_id",t.transferId).put("file_id",t.fileId).put("message_id",t.messageId).put("sender_id",t.senderId).put("file_name",t.fileName).put("content_type",t.contentType).put("size",t.size).put("sha256",t.sha256).put("total_chunks",t.totalChunks).put("path",t.path).put("received",bitsetEncode(t.received)).put("updated_at",t.updatedAt).toString())}'
new = '''    private fun persistIncomingTransfer(t:IncomingFileTransfer){\n        val m=File(t.path.removeSuffix(".part")+".meta.json")\n        atomicWriteText(m, JSONObject().put("crypto_version",DirectFileSecurity.CRYPTO_VERSION).put("transfer_id",t.transferId).put("file_id",t.fileId).put("message_id",t.messageId).put("sender_id",t.senderId).put("file_name",t.fileName).put("content_type",t.contentType).put("size",t.size).put("sha256",t.sha256).put("total_chunks",t.totalChunks).put("path",t.path).put("received",bitsetEncode(t.received)).put("updated_at",t.updatedAt).toString())\n}'''
if old not in s: raise SystemExit('incoming persist pattern missing')
s = s.replace(old,new)

# Prepare outgoing transfer uses transferId=fileId and expectedChunks policy.
s = s.replace('''    private fun prepareOutgoingTransfer(target:String,file:File,fileId:String,messageId:String,fileName:String,contentType:String):OutgoingFileTransfer{val existing=outgoingTransfers[fileId];if(existing!=null&&existing.recipientId==target&&existing.filePath==file.absolutePath&&existing.sha256==sha256File(file))return existing;val sha=sha256File(file);val size=file.length();val total=if(size==0L)1 else ((size+directChunkSize-1)/directChunkSize).toInt();val t=OutgoingFileTransfer(fileId,fileId,messageId,transportDeviceId!!,target,file.absolutePath,safeFileName(fileName),contentType,size,sha,total,BooleanArray(total),System.currentTimeMillis());outgoingTransfers[fileId]=t;return t}''','''    private fun prepareOutgoingTransfer(target:String,file:File,fileId:String,messageId:String,fileName:String,contentType:String):OutgoingFileTransfer{\n        val existing=outgoingTransfers[fileId]\n        if(existing!=null&&existing.recipientId==target&&existing.filePath==file.absolutePath&&existing.sha256==sha256File(file))return existing\n        val sha=sha256File(file)\n        val size=file.length()\n        val total=DirectFileTransferPolicy.expectedChunks(size)\n        val t=OutgoingFileTransfer(fileId,fileId,messageId,transportDeviceId!!,target,file.absolutePath,safeFileName(fileName),contentType,size,sha,total,BooleanArray(total),System.currentTimeMillis())\n        outgoingTransfers[fileId]=t\n        outgoingRetryCounts.remove(t.transferId)\n        return t\n    }''')

# Replace sendMissingChunks with guarded, bounded retry implementation.
start=s.find('    private fun sendMissingChunks(t:OutgoingFileTransfer,onlyMissing:Boolean){')
end=s.find('\n    private fun cancelFileTransportInternal', start)
if start<0 or end<0: raise SystemExit('sendMissingChunks block missing')
new_block='''    private fun sendMissingChunks(t:OutgoingFileTransfer,onlyMissing:Boolean){\n        if(!outgoingSendInFlight.add(t.transferId)) return\n        try {\n            if(cancelledDirectTransfers.contains(t.transferId)){\n                deleteOutgoingMeta(t);outgoingTransfers.remove(t.transferId);outgoingRetryCounts.remove(t.transferId);cancelledDirectTransfers.remove(t.transferId)\n                transportEvent("file_cancelled",mapOf("transfer_id" to t.transferId,"message_id" to t.messageId,"file_id" to t.fileId));return\n            }\n            val f=File(t.filePath)\n            val key=peerKeys[t.recipientId]\n            if(key==null){ transportEvent("file_waiting_for_key",mapOf("transfer_id" to t.transferId,"recipient_id" to t.recipientId));return }\n            if(!f.isFile||f.length()!=t.size||sha256File(f)!=t.sha256){\n                deleteOutgoingMeta(t);outgoingTransfers.remove(t.transferId);outgoingRetryCounts.remove(t.transferId)\n                transportEvent("file_failed",mapOf("transfer_id" to t.transferId,"message_id" to t.messageId,"reason" to "source_changed_or_missing"));return\n            }\n            val attempt=outgoingRetryCounts.merge(t.transferId,1,Int::plus) ?: 1\n            if(attempt>DirectFileTransferPolicy.MAX_RETRY_ATTEMPTS){\n                deleteOutgoingMeta(t);outgoingTransfers.remove(t.transferId);outgoingRetryCounts.remove(t.transferId)\n                transportEvent("file_failed",mapOf("transfer_id" to t.transferId,"message_id" to t.messageId,"reason" to "retry_limit_exceeded"));return\n            }\n            var sentAny=false\n            FileInputStream(f).use{input->\n                val buf=ByteArray(directChunkSize);var idx=0\n                while(true){\n                    if(cancelledDirectTransfers.contains(t.transferId)){cancelledDirectTransfers.remove(t.transferId);transportEvent("file_cancelled",mapOf("transfer_id" to t.transferId,"message_id" to t.messageId,"file_id" to t.fileId));return}\n                    val n=input.read(buf);if(n<=0)break\n                    if(onlyMissing&&t.acknowledged[idx]){idx++;continue}\n                    val data=if(n==buf.size)buf else buf.copyOf(n)\n                    val context=DirectFileSecurity.FileChunkContext(t.transferId,t.senderId,t.recipientId,t.fileId,t.messageId,t.fileName,t.contentType,t.size,t.sha256,t.totalChunks)\n                    val fileKey=DirectFileSecurity.deriveFileKey(key,context);val aad=DirectFileSecurity.chunkAad(context,idx);val enc=DirectFileSecurity.encryptChunk(data,fileKey,aad)\n                    val payload=JSONObject().put("type","direct_file_chunk").put("crypto_version",DirectFileSecurity.CRYPTO_VERSION).put("sender_id",t.senderId).put("recipient_id",t.recipientId).put("transfer_id",t.transferId).put("file_id",t.fileId).put("message_id",t.messageId).put("file_name",t.fileName).put("content_type",t.contentType).put("size",t.size).put("sha256",t.sha256).put("chunk_index",idx).put("total_chunks",t.totalChunks).put("data_enc",enc).put("file_auth",DirectFileSecurity.authTag(fileKey,aad,enc))\n                    if(!sendRoutedPayload(t.recipientId,payload))break\n                    sentAny=true;idx++\n                }\n            }\n            if(t.size==0L&&!t.acknowledged[0]){\n                val context=DirectFileSecurity.FileChunkContext(t.transferId,t.senderId,t.recipientId,t.fileId,t.messageId,t.fileName,t.contentType,0L,t.sha256,1);val fileKey=DirectFileSecurity.deriveFileKey(key,context);val aad=DirectFileSecurity.chunkAad(context,0);val enc=DirectFileSecurity.encryptChunk(ByteArray(0),fileKey,aad);val p=JSONObject().put("type","direct_file_chunk").put("crypto_version",DirectFileSecurity.CRYPTO_VERSION).put("sender_id",t.senderId).put("recipient_id",t.recipientId).put("transfer_id",t.transferId).put("file_id",t.fileId).put("message_id",t.messageId).put("file_name",t.fileName).put("content_type",t.contentType).put("size",0).put("sha256",t.sha256).put("chunk_index",0).put("total_chunks",1).put("data_enc",enc).put("file_auth",DirectFileSecurity.authTag(fileKey,aad,enc));sendRoutedPayload(t.recipientId,p);sentAny=true\n            }\n            if(!sentAny) transportEvent("file_retry_scheduled",mapOf("transfer_id" to t.transferId,"attempt" to attempt))\n            t.updatedAt=System.currentTimeMillis();persistOutgoingTransfer(t)\n        } finally {\n            outgoingSendInFlight.remove(t.transferId)\n        }\n    }\n'''
s=s[:start]+new_block+s[end:]

# Reset retry count on confirmed progress and guard malformed bitsets.
s=s.replace('''        val bits=bitsetDecode(p.optString("received_chunks"),t.totalChunks)\n        for(i in bits.indices)if(bits[i])t.acknowledged[i]=true\n        t.updatedAt=System.currentTimeMillis()''','''        val bits=bitsetDecode(p.optString("received_chunks"),t.totalChunks)\n        for(i in bits.indices)if(bits[i])t.acknowledged[i]=true\n        if(bits.any{it}) outgoingRetryCounts[t.transferId]=0\n        t.updatedAt=System.currentTimeMillis()''')

# Clear retry/locks on cancellation/completion.
s=s.replace('''            deleteOutgoingMeta(outgoing)\n            try { sendRoutedPayload''','''            deleteOutgoingMeta(outgoing)\n            outgoingRetryCounts.remove(outgoing.transferId)\n            outgoingSendInFlight.remove(outgoing.transferId)\n            try { sendRoutedPayload''')
s=s.replace('''if(missingChunkCount(t)==0){deleteOutgoingMeta(t);outgoingTransfers.remove(id);transportEvent''','''if(missingChunkCount(t)==0){deleteOutgoingMeta(t);outgoingTransfers.remove(id);outgoingRetryCounts.remove(id);outgoingSendInFlight.remove(id);transportEvent''')

# Incomplete transfer status snapshot exposes retry counts.
s=s.replace('''"outgoing_transfers" to outgoingTransfers.values.map{mapOf("transfer_id" to it.transferId,"recipient_id" to it.recipientId,"size" to it.size,"total_chunks" to it.totalChunks,"acked_chunks" to (it.totalChunks-missingChunkCount(it)))},''','''"outgoing_transfers" to outgoingTransfers.values.map{mapOf("transfer_id" to it.transferId,"recipient_id" to it.recipientId,"size" to it.size,"total_chunks" to it.totalChunks,"acked_chunks" to (it.totalChunks-missingChunkCount(it)),"retry_attempts" to (outgoingRetryCounts[it.transferId] ?: 0))},''')

# Stronger bitset decoding: reject encoding with too many bytes.
s=s.replace('''    private fun bitsetDecode(s:String,total:Int):BooleanArray{val o=BooleanArray(total);try{val b=Base64.decode(s,Base64.DEFAULT);for(i in 0 until total)if(i/8<b.size)o[i]=(b[i/8].toInt() and (1 shl i%8))!=0}catch(_:Exception){};return o}''','''    private fun bitsetDecode(s:String,total:Int):BooleanArray{\n        val o=BooleanArray(total)\n        try{\n            if(total<0) return o\n            val b=Base64.decode(s,Base64.DEFAULT)\n            val expected=(total+7)/8\n            if(b.size!=expected) return o\n            for(i in 0 until total) o[i]=(b[i/8].toInt() and (1 shl i%8))!=0\n        }catch(_:Exception){}\n        return o\n    }''')

p.write_text(s)

# ---- Flutter HTTP download resume + bounds / cleanup ----
p = root/'flutter/lib/features/files/data/services/file_transfer_service.dart'
s=p.read_text()
# Use canonical security policy URL construction for relative URLs.
s=s.replace("final url = relative.startsWith('http') ? relative : '$baseUrl$relative';","final url = relative.startsWith('http') ? relative : '$baseUrl$relative';")  # leave existing canonicalized baseUrl from phase51
# Replace download method body using start/end.
start=s.find('  Future<String> download(Attachment attachment, {')
end=s.find('\n  Future<String> materializeForDisplay', start)
if start<0 or end<0: raise SystemExit('Flutter download block missing')
new_download=r'''  Future<String> download(Attachment attachment, {String? transferId, void Function(TransferProgress progress)? onProgress, bool thumbnail = false}) async {
    final relative = thumbnail ? attachment.thumbnailUrl : attachment.downloadUrl;
    if (relative == null || relative.isEmpty) throw Exception('Attachment download URL is missing');
    final url = relative.startsWith('http') ? relative : '$baseUrl$relative';
    final root = await getDatabasesPath();
    final dir = Directory('$root/attachments');
    await dir.create(recursive: true);
    final safeAttachmentId = _safeAttachmentId(attachment.id);
    final extension = _safeExtension(attachment.originalName, attachment.contentType, thumbnail);
    final target = '${dir.path}/$safeAttachmentId${thumbnail ? '-thumb' : ''}$extension';
    final protectedTarget = '$target.enc';
    final output = File(protectedTarget);
    if (await output.exists() && await output.length() > 0) return output.path;

    final part = File('$target.part');
    var offset = await part.exists() ? await part.length() : 0;
    if (offset > 0 && offset > attachment.size + 2 * 1024 * 1024) {
      await part.delete();
      offset = 0;
    }

    final request = http.Request('GET', Uri.parse(url));
    request.headers.addAll(_headers());
    if (offset > 0) request.headers['Range'] = 'bytes=$offset-';
    final client = http.Client();
    if (transferId != null && transferId.isNotEmpty) _activeClients[transferId] = client;
    try {
      final response = await client.send(request).timeout(const Duration(minutes: 3));
      if (response.statusCode != 200 && response.statusCode != 206) {
        throw Exception('Download failed (${response.statusCode})');
      }
      final append = offset > 0 && response.statusCode == 206;
      if (!append) {
        offset = 0;
        if (await part.exists()) await part.delete();
      }
      final sink = part.openWrite(mode: append ? FileMode.append : FileMode.write);
      var received = offset;
      final total = response.contentLength != null ? offset + response.contentLength! : attachment.size;
      try {
        await for (final chunk in response.stream) {
          received += chunk.length;
          final hardLimit = math.max(attachment.size + 2 * 1024 * 1024, total);
          if (received > hardLimit) throw StateError('encrypted download exceeds expected bounds');
          sink.add(chunk);
          onProgress?.call(TransferProgress(
            operationId: transferId ?? 'untracked-download',
            direction: FileTransferDirection.download,
            completed: received,
            total: total,
            status: FileTransferStatus.running,
          ));
        }
        await sink.flush();
      } finally {
        await sink.close();
      }
      if (transferId != null && _cancelledTransfers.remove(transferId)) {
        throw const FileTransferCancelledException();
      }
      await sensitiveFiles.protectFile(part.path, protectedTarget);
      await part.delete();
      return protectedTarget;
    } catch (_) {
      await part.delete().catchError((_) {});
      if (transferId != null && _cancelledTransfers.remove(transferId)) {
        throw const FileTransferCancelledException();
      }
      rethrow;
    } finally {
      _activeClients.remove(transferId);
      client.close();
    }
  }
'''
# Need import dart:math for max. Add if absent.
if "import 'dart:math' as math;" not in s:
    s="import 'dart:math' as math;\n"+s
s=s[:start]+new_download+s[end:]
p.write_text(s)

# ---- Add tests for direct transfer policy ----
test=root/'flutter/android/app/src/test/kotlin/com/sajjad/locallink/DirectFileTransferPolicyTest.kt'
test.write_text(r'''package com.sajjad.locallink\n\nimport org.junit.Assert.*\nimport org.junit.Test\n\nclass DirectFileTransferPolicyTest {\n    @Test fun expectedChunkBoundaries() {\n        assertEquals(1, DirectFileTransferPolicy.expectedChunks(0))\n        assertEquals(1, DirectFileTransferPolicy.expectedChunks(DirectFileTransferPolicy.CHUNK_SIZE.toLong()))\n        assertEquals(2, DirectFileTransferPolicy.expectedChunks(DirectFileTransferPolicy.CHUNK_SIZE.toLong() + 1))\n        assertEquals(\n            ((DirectFileTransferPolicy.MAX_DIRECT_FILE_SIZE + DirectFileTransferPolicy.CHUNK_SIZE - 1) / DirectFileTransferPolicy.CHUNK_SIZE).toInt(),\n            DirectFileTransferPolicy.expectedChunks(DirectFileTransferPolicy.MAX_DIRECT_FILE_SIZE),\n        )\n    }\n\n    @Test fun sizeAndActiveByteBudget() {\n        assertTrue(DirectFileTransferPolicy.validTransferSize(0))\n        assertTrue(DirectFileTransferPolicy.validTransferSize(DirectFileTransferPolicy.MAX_DIRECT_FILE_SIZE))\n        assertFalse(DirectFileTransferPolicy.validTransferSize(-1))\n        assertFalse(DirectFileTransferPolicy.validTransferSize(DirectFileTransferPolicy.MAX_DIRECT_FILE_SIZE + 1))\n        assertEquals(6L, DirectFileTransferPolicy.activeBytes(listOf(1L, 2L, 3L)))\n    }\n\n    @Test fun concurrentPolicyBoundsAreFinite() {\n        assertTrue(DirectFileTransferPolicy.MAX_ACTIVE_INCOMING_TRANSFERS < 32)\n        assertTrue(DirectFileTransferPolicy.MAX_ACTIVE_OUTGOING_TRANSFERS <= 8)\n        assertTrue(DirectFileTransferPolicy.MAX_RETRY_ATTEMPTS in 3..16)\n    }\n}\n''')

# ---- Docs ----
doc=root/'PHASE_57_FILE_TRANSFER_RESILIENCE.md'
doc.write_text('''# PHASE 57 — File Transfer Resilience\n\nImplemented source-level hardening for server-assisted and direct Android file transfers.\n\n## Completed\n\n- Global server upload/download concurrency gates.\n- Direct-transfer active-count and aggregate-byte budgets.\n- Direct-transfer idle expiration and completion-marker retention.\n- Durable atomic transfer metadata writes with fsync + rename.\n- Incoming file preallocation bounded by active byte budget.\n- Per-chunk file `fd.sync()` before acknowledging/persisting received state.\n- Strict restore validation for transfer IDs, sizes, chunk counts, hashes and paths.\n- Direct-transfer send de-duplication using per-transfer in-flight guards.\n- Bounded retry attempts with explicit failure after the retry limit.\n- Retry counter reset on confirmed receiver progress.\n- Safer bitset decoding.\n- Flutter HTTP download resume using HTTP Range when a `.part` file survives interruption.\n- Download/upload size bounds and partial-file cleanup retained.\n- Dedicated Android transfer-policy unit tests.\n\n## Remaining runtime gate\n\nPhysical Android/LAN/Wi-Fi Direct interruption and power-loss testing still requires devices.\n''')

# Update status with Phase 57 line if status file exists.
status=root/'AUDIT-ALL-STATUS.md'
if status.exists():
    ss=status.read_text()
    if 'PHASE 57' not in ss:
        ss += '\n\nPHASE 57 — File Transfer Resilience: IMPLEMENTED\n'
    status.write_text(ss)

print('patched')
