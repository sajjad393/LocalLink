import 'package:flutter_test/flutter_test.dart';
import 'package:locallink/core/security/security_policy.dart';

void main() {
  test('normalizes a valid HTTPS server address', () {
    expect(
      SecurityPolicy.normalizeServerAddress('https://192.168.1.20:8443/'),
      'https://192.168.1.20:8443',
    );
  });

  test('rejects credentials, paths, queries, and fragments', () {
    expect(
      () => SecurityPolicy.normalizeServerAddress('https://user:pass@192.168.1.20:8443'),
      throwsFormatException,
    );
    expect(
      () => SecurityPolicy.normalizeServerAddress('https://192.168.1.20:8443/api'),
      throwsFormatException,
    );
    expect(
      () => SecurityPolicy.normalizeServerAddress('https://192.168.1.20:8443?secret=x'),
      throwsFormatException,
    );
    expect(
      () => SecurityPolicy.normalizeServerAddress('https://192.168.1.20:8443#secret'),
      throwsFormatException,
    );
  });

  test('normalizes a development HTTP address when insecure HTTP is allowed', () {
    // flutter_test runs in debug mode, where LAN HTTP is intentionally allowed.
    expect(
      SecurityPolicy.normalizeServerAddress('192.168.1.20:8080'),
      'http://192.168.1.20:8080',
    );
  });
}
