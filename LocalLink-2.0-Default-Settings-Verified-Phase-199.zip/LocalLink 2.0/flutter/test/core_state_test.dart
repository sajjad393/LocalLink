import 'package:flutter_test/flutter_test.dart';
import 'package:locallink/core/state/async_state.dart';
void main(){
  test('AsyncState copyWith preserves data while changing status',(){
    const state=AsyncState<String>(status:AsyncStatus.success,data:'ok');
    final loading=state.copyWith(status:AsyncStatus.loading);
    expect(loading.isLoading,isTrue); expect(loading.data,'ok'); expect(loading.error,isNull);
  });
  test('AsyncState can clear an existing error',(){
    const state=AsyncState<String>(status:AsyncStatus.failure,error:'offline');
    expect(state.hasError,isTrue); expect(state.copyWith(status:AsyncStatus.idle,clearError:true).error,isNull);
  });
}
