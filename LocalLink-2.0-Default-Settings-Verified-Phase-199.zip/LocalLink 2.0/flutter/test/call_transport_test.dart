import 'package:flutter_test/flutter_test.dart';

import 'package:locallink/features/calls/data/transport/call_transport_mode.dart';
import 'package:locallink/features/calls/data/transport/call_transport_selection_policy.dart';
import 'package:locallink/features/calls/data/transport/network_preference.dart';
import 'package:locallink/features/calls/data/transport/call_transport_packet.dart';

void main() {
  test('transport modes have stable wire names', () {
    expect(CallTransportMode.auto.wireName, 'auto');
    expect(CallTransportMode.offlineMesh.wireName, 'offline_mesh');
    expect(CallTransportMode.webRtc.wireName, 'webrtc');
    expect(CallTransportMode.internetGateway.wireName, 'internet_gateway');
  });

  test('call media packet accepts the canonical encrypted envelope', () {
    final packet = CallMediaPacket.tryParse({
      'call_id': 'call-1',
      'sender_id': 'A',
      'recipient_id': 'D',
      'sequence': 7,
      'timestamp_ms': 1_757_000_000_000,
      'codec': 'opus',
      'sample_rate': 16000,
      'frame_ms': 20,
      'ttl': 8,
      'encrypted_payload': 'abc',
    });

    expect(packet, isNotNull);
    expect(packet!.codec, 'opus');
    expect(packet.ttl, 8);
  });

  test('call media packet rejects malformed or unsupported metadata', () {
    expect(CallMediaPacket.tryParse({
      'call_id': 'call-1',
      'sender_id': 'A',
      'recipient_id': 'D',
      'sequence': -1,
      'timestamp_ms': 1,
      'codec': 'opus',
      'sample_rate': 16000,
      'frame_ms': 20,
      'ttl': 8,
      'encrypted_payload': 'abc',
    }), isNull);

    expect(CallMediaPacket.tryParse({
      'call_id': 'call-1',
      'sender_id': 'A',
      'recipient_id': 'D',
      'sequence': 1,
      'timestamp_ms': 1,
      'codec': 'g711',
      'sample_rate': 16000,
      'frame_ms': 20,
      'ttl': 8,
      'encrypted_payload': 'abc',
    }), isNull);
  });


  test('AUTO prefers local route when Internet is also available', () {
    expect(
      CallTransportSelectionPolicy.select(
        preferredMode: CallTransportMode.auto,
        networkPreference: NetworkPreference.localFirst,
        localRouteAvailable: true,
        directInternetAvailable: true,
      ),
      CallTransportMode.offlineMesh,
    );
  });

  test('AUTO falls back to WebRTC when no local route exists', () {
    expect(
      CallTransportSelectionPolicy.select(
        preferredMode: CallTransportMode.auto,
        networkPreference: NetworkPreference.localFirst,
        localRouteAvailable: false,
        directInternetAvailable: true,
      ),
      CallTransportMode.webRtc,
    );
  });

  test('AUTO fails when neither local nor Internet route exists', () {
    expect(
      () => CallTransportSelectionPolicy.select(
        preferredMode: CallTransportMode.auto,
        networkPreference: NetworkPreference.localFirst,
        localRouteAvailable: false,
        directInternetAvailable: false,
      ),
      throwsStateError,
    );
  });

  test('Internet-only forces WebRTC and requires Internet', () {
    expect(
      CallTransportSelectionPolicy.select(
        preferredMode: CallTransportMode.auto,
        networkPreference: NetworkPreference.internetOnly,
        localRouteAvailable: true,
        directInternetAvailable: true,
      ),
      CallTransportMode.webRtc,
    );
    expect(
      () => CallTransportSelectionPolicy.select(
        preferredMode: CallTransportMode.auto,
        networkPreference: NetworkPreference.internetOnly,
        localRouteAvailable: true,
        directInternetAvailable: false,
      ),
      throwsStateError,
    );
  });

  test('AUTO uses an authenticated gateway only when its route is verified', () {
    expect(
      CallTransportSelectionPolicy.select(
        preferredMode: CallTransportMode.auto,
        networkPreference: NetworkPreference.localFirst,
        localRouteAvailable: false,
        directInternetAvailable: false,
        gatewayRouteAvailable: true,
        gatewayAuthorized: true,
        gatewayCapacityAvailable: true,
      ),
      CallTransportMode.internetGateway,
    );
  });

  test('AUTO rejects an advertised gateway without a verified route', () {
    expect(
      () => CallTransportSelectionPolicy.select(
        preferredMode: CallTransportMode.auto,
        networkPreference: NetworkPreference.localFirst,
        localRouteAvailable: false,
        directInternetAvailable: false,
        gatewayRouteAvailable: false,
        gatewayAuthorized: true,
        gatewayCapacityAvailable: true,
      ),
      throwsStateError,
    );
  });

  test('Internet Preferred chooses WebRTC before local mesh', () {
    expect(
      CallTransportSelectionPolicy.select(
        preferredMode: CallTransportMode.auto,
        networkPreference: NetworkPreference.internetPreferred,
        localRouteAvailable: true,
        directInternetAvailable: true,
      ),
      CallTransportMode.webRtc,
    );
  });

  test('Internet Preferred falls back to local mesh when WebRTC is unavailable', () {
    expect(
      CallTransportSelectionPolicy.select(
        preferredMode: CallTransportMode.auto,
        networkPreference: NetworkPreference.internetPreferred,
        localRouteAvailable: true,
        directInternetAvailable: false,
      ),
      CallTransportMode.offlineMesh,
    );
  });

  test('Local First uses gateway only after local and direct Internet paths fail', () {
    expect(
      CallTransportSelectionPolicy.select(
        preferredMode: CallTransportMode.auto,
        networkPreference: NetworkPreference.localFirst,
        localRouteAvailable: false,
        directInternetAvailable: false,
        gatewayRouteAvailable: true,
        gatewayAuthorized: true,
        gatewayCapacityAvailable: true,
        internetGatewayEnabled: true,
      ),
      CallTransportMode.internetGateway,
    );
  });

  test('Internet-only never falls back to a gateway', () {
    expect(
      () => CallTransportSelectionPolicy.select(
        preferredMode: CallTransportMode.auto,
        networkPreference: NetworkPreference.internetOnly,
        localRouteAvailable: false,
        directInternetAvailable: false,
        gatewayRouteAvailable: true,
        gatewayAuthorized: true,
        gatewayCapacityAvailable: true,
      ),
      throwsStateError,
    );
  });
}
