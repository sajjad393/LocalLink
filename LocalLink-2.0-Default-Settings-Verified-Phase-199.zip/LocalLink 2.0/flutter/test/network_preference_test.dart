import 'package:flutter_test/flutter_test.dart';
import 'package:locallink/core/services/local_store.dart';
import 'package:locallink/features/calls/data/transport/network_preference.dart';

void main() {
  test('network preferences have stable persisted values', () {
    expect(NetworkPreference.localFirst.storageValue, 'local_first');
    expect(NetworkPreference.internetPreferred.storageValue, 'internet_preferred');
    expect(NetworkPreference.internetOnly.storageValue, 'internet_only');
  });

  test('invalid persisted preference safely defaults to Local First', () {
    expect(NetworkPreferenceX.fromStorage('unexpected'), NetworkPreference.localFirst);
  });

  test('fresh LocalStore defaults to Local First with gateway sharing enabled', () {
    final store = LocalStore();

    expect(store.networkPreference, NetworkPreference.localFirst);
    expect(store.useInternetOnly, isFalse);
    expect(store.allowThisDeviceAsInternetGateway, isTrue);
    expect(store.useInternetGateway, isTrue);
  });

  test('labels and descriptions are explicit', () {
    expect(NetworkPreference.localFirst.label, 'Local First');
    expect(NetworkPreference.internetPreferred.label, 'Internet Preferred');
    expect(NetworkPreference.internetOnly.label, 'Internet Only');
    expect(NetworkPreference.internetOnly.description, contains('Never use LAN or mesh'));
  });
}
