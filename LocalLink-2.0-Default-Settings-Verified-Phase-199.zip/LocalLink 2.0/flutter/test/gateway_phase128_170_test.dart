import 'package:flutter_test/flutter_test.dart';
import 'package:locallink/features/calls/data/gateway/gateway_models.dart';
import 'package:locallink/features/calls/data/gateway/gateway_route_selector.dart';
import 'package:locallink/features/calls/data/gateway/gateway_runtime.dart';
import 'package:locallink/features/calls/data/gateway/gateway_traffic_scheduler.dart';

GatewayAdvertisement ad({required String id, required int upstream, required int slots, required double health, required int budgetRemaining}) => GatewayAdvertisement(
  gatewayId: id,
  nodeId: id,
  internetAvailable: true,
  lanAvailable: true,
  wifiDirectAvailable: true,
  meshAvailable: true,
  gatewayCapable: true,
  gatewayAvailable: slots > 0,
  gatewayVersion: '2',
  maxGatewaySessions: 4,
  currentGatewaySessions: 4 - slots,
  availableSlots: slots,
  latencyMs: 40,
  upstreamKbps: upstream,
  downstreamKbps: upstream * 2,
  packetLossPercent: 0,
  healthScore: health,
  budgetLimitBytes: 2 * 1024 * 1024,
  budgetUsedBytes: 2 * 1024 * 1024 - budgetRemaining,
  budgetRemainingBytes: budgetRemaining,
  identityPublicKey: 'id-key',
  signingPublicKey: 'sign-key',
  signature: 'sig',
  advertisedAt: DateTime.now().toUtc(),
  expiresAt: DateTime.now().toUtc().add(const Duration(minutes: 1)),
);

void main() {
  test('automatic gateway eligibility requires validated Internet and mesh', () {
    const policy = GatewayEligibilityPolicy();
    expect(policy.evaluate(capabilities: const {'internet_validated': false, 'mesh_available': true}, meshAvailable: true, activeSessions: 0, maxSessions: 2, budgetRemainingBytes: 100), GatewayPauseReason.noInternet);
    expect(policy.evaluate(capabilities: const {'internet_validated': true, 'mesh_available': false}, meshAvailable: false, activeSessions: 0, maxSessions: 2, budgetRemainingBytes: 100), GatewayPauseReason.noMesh);
  });

  test('route selector ranks resources, not latency alone', () {
    final selector = GatewayRouteSelector();
    final a = ad(id: 'a', upstream: 500, slots: 3, health: 95, budgetRemaining: 900000);
    final b = ad(id: 'b', upstream: 1000, slots: 1, health: 55, budgetRemaining: 50000);
    final routes = [
      (gateway: a, route: GatewayRoute(gatewayId: 'a', destinationId: 'dest', reachable: true, hopCount: 2, latencyMs: 80, expiresAt: DateTime.now().add(const Duration(minutes: 1)), resolvedAt: DateTime.now())),
      (gateway: b, route: GatewayRoute(gatewayId: 'b', destinationId: 'dest', reachable: true, hopCount: 1, latencyMs: 20, expiresAt: DateTime.now().add(const Duration(minutes: 1)), resolvedAt: DateTime.now())),
    ];
    final scores = routes.map((x) => selector.score(gateway: x.gateway, route: x.route, healthScore: x.gateway.healthScore)).toList();
    expect(scores.first, greaterThan(scores.last));
  });

  test('traffic classifier prioritizes signaling and voice over bulk', () {
    expect(gatewayTrafficClassFor(const {'type': 'call_invite'}), GatewayTrafficClass.signaling);
    expect(gatewayTrafficClassFor(const {'type': 'call_media'}), GatewayTrafficClass.voice);
    expect(gatewayTrafficClassFor(const {'type': 'file_chunk'}), GatewayTrafficClass.bulk);
  });

  test('advertisement canonical form carries budget and bandwidth metadata', () {
    final x = ad(id: 'a', upstream: 640, slots: 2, health: 90, budgetRemaining: 123456);
    final raw = x.toJson();
    expect(raw['upstream_kbps'], 640);
    expect(raw['available_upstream_kbps'], isNotNull);
    expect(raw['budget_remaining_bytes'], 123456);
    expect(GatewayAdvertisement.fromJson(raw).budgetRemainingBytes, 123456);
  });
}
