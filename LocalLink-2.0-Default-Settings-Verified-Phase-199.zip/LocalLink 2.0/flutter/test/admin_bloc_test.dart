import 'package:flutter_test/flutter_test.dart';
import 'package:locallink/features/admin/domain/admin_repository_contract.dart';
import 'package:locallink/features/admin/bloc/admin_bloc.dart';

class _FakeAdminRepository implements AdminRepositoryContract {
  Object? failure;
  int loadCalls = 0;
  @override Future<Map<String, dynamic>> summary() async { loadCalls++; if (failure != null) throw failure!; return const {'devices': 2}; }
  @override Future<List<Map<String, dynamic>>> devices() async => const [{'id':'d1'}];
  @override Future<List<Map<String, dynamic>>> groups() async => const [{'id':'g1'}];
  @override Future<List<Map<String, dynamic>>> calls() async => const [];
  @override Future<List<Map<String, dynamic>>> logs() async => const [];
  @override Future<List<Map<String, dynamic>>> recoveryRequests() async => const [];
  @override Future<void> rename(String id, String name) async {}
  @override Future<void> revoke(String id) async {}
  @override Future<Map<String, dynamic>> backup() async => const {'file':'backup.zip'};
  @override Future<Map<String, dynamic>> approveRecovery(String id) async => const {'recovery_credential':'abc'};
  @override Future<Map<String, dynamic>> reissueRecovery(String id) async => const {'recovery_credential':'def'};
  @override Future<void> rejectRecovery(String id, String reason) async {}
}

void main() {
  test('AdminBloc loads the complete administrative snapshot', () async {
    final bloc = AdminBloc(_FakeAdminRepository());
    await bloc.load();
    expect(bloc.summaryData?['devices'], 2);
    expect(bloc.devices, hasLength(1));
    expect(bloc.groups, hasLength(1));
    expect(bloc.loading, isFalse);
    await bloc.close();
  });

  test('AdminBloc converts repository failures into user-facing state', () async {
    final repo = _FakeAdminRepository()..failure = StateError('offline');
    final bloc = AdminBloc(repo);
    await bloc.load();
    expect(bloc.error, contains('offline'));
    expect(bloc.loading, isFalse);
    await bloc.close();
  });
}
