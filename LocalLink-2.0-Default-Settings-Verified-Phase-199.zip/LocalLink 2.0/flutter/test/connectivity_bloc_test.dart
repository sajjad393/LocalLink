import 'dart:async';


import 'package:flutter_test/flutter_test.dart';
import 'package:locallink/features/connectivity/data/models/connectivity_snapshot.dart';
import 'package:locallink/features/connectivity/data/models/discovered_server.dart';
import 'package:locallink/features/connectivity/data/models/network_snapshot.dart';
import 'package:locallink/features/connectivity/data/models/wifi_direct_models.dart';
import 'package:locallink/features/connectivity/domain/connectivity_repository_contract.dart';
import 'package:locallink/features/connectivity/bloc/connectivity_bloc.dart';

class _FakeConnectivityRepository implements ConnectivityRepositoryContract {
  final _server = StreamController<bool>.broadcast();
  final _wifi = StreamController<dynamic>.broadcast();
  final _transport = StreamController<Map<String, dynamic>>.broadcast();
  final _network = StreamController<NetworkSnapshot>.broadcast();
  bool started = false;

  @override
  Stream<bool> get serverConnectionState => _server.stream;
  @override
  Stream<dynamic> get wifiDirectEvents => _wifi.stream;
  @override
  Stream<Map<String, dynamic>> get wifiDirectTransportEvents => _transport.stream;
  @override
  Stream<NetworkSnapshot> get networkChanges => _network.stream;

  @override
  Future<void> startMonitoring() async => started = true;
  @override
  Future<void> stopMonitoring() async => started = false;

  @override
  Future<List<DiscoveredServer>> discoverServers({Duration timeout = const Duration(seconds: 3)}) async => const [];
  @override
  Future<bool> isWifiDirectSupported() async => true;
  @override
  Future<void> requestWifiDirectEnable() async {}
  @override
  Future<void> startWifiDirectDiscovery() async {}
  @override
  Future<List<WifiDirectPeer>> wifiDirectPeers() async => const [];
  @override
  Future<WifiDirectConnection> wifiDirectConnectionInfo() async => const WifiDirectConnection(connected: false, groupOwner: false);
  @override
  Future<void> connectWifiDirect(String address) async {}
  @override
  Future<void> cancelWifiDirectConnect() async {}
  @override
  Future<void> disconnectWifiDirect() async {}
  @override
  Future<Map<String, dynamic>> topology() async => const {};
  @override
  Future<bool> probeInternet() async => false;
  @override
  Future<ConnectivitySnapshot> refresh() async =>
      ConnectivitySnapshot.initial().copyWith(
        wifiDirectSupported: true,
        network: const NetworkSnapshot(
          interfaceNames: ['wlan0'],
          ipv4Addresses: ['192.168.1.10'],
        ),
      );

  void emitServer(bool connected) => _server.add(connected);
  void emitNetwork(NetworkSnapshot network) => _network.add(network);

  Future<void> close() async {
    await _server.close();
    await _wifi.close();
    await _transport.close();
    await _network.close();
  }
}

void main() {
  test('controller owns connectivity state and reacts to server changes', () async {
    final repository = _FakeConnectivityRepository();
    final controller = ConnectivityBloc(repository: repository);

    await controller.start();
    expect(repository.started, isTrue);
    expect(controller.snapshot.wifiDirectSupported, isTrue);

    repository.emitServer(true);
    await Future<void>.delayed(Duration.zero);
    expect(controller.snapshot.serverConnected, isTrue);

    repository.emitNetwork(const NetworkSnapshot(
      interfaceNames: ['wlan0'],
      ipv4Addresses: ['192.168.1.11'],
    ));
    await Future<void>.delayed(Duration.zero);
    expect(controller.snapshot.network.ipv4Addresses, ['192.168.1.11']);

    await controller.close();
    await repository.close();
  });

  test('network snapshot fingerprint changes when address changes', () {
    const first = NetworkSnapshot(
      interfaceNames: ['wlan0'],
      ipv4Addresses: ['192.168.1.10'],
    );
    const second = NetworkSnapshot(
      interfaceNames: ['wlan0'],
      ipv4Addresses: ['192.168.1.11'],
    );
    expect(first.sameNetworkAs(second), isFalse);
  });
}
