package com.sajjad.locallink.mesh

import org.junit.Test

class MeshLoadChaosHarnessTest {
    @Test
    fun deterministicLoadChaosPasses() {
        MeshLoadChaosHarness.main(emptyArray())
    }
}
