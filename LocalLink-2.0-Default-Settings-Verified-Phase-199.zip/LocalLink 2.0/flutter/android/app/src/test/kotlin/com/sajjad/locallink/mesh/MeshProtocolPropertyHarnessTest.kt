package com.sajjad.locallink.mesh

import org.junit.Test

class MeshProtocolPropertyHarnessTest {
    @Test
    fun deterministicPropertyHarnessPasses() {
        MeshProtocolPropertyHarness.main(emptyArray())
    }
}
