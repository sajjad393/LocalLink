package com.sajjad.locallink.mesh

import org.junit.Test

class MeshChaosResilienceHarnessTest {
    @Test
    fun allChaosScenariosPass() {
        MeshChaosResilienceHarness.runAll()
    }
}
