import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:locallink/core/diagnostics/app_diagnostics.dart';

class DiagnosticsScreen extends StatefulWidget {
  const DiagnosticsScreen({super.key});

  @override
  State<DiagnosticsScreen> createState() => _DiagnosticsScreenState();
}

class _DiagnosticsScreenState extends State<DiagnosticsScreen> {
  final AppDiagnostics diagnostics = AppDiagnostics.instance;

  @override
  Widget build(BuildContext context) {
    final snapshot = diagnostics.snapshot();
    final counters = Map<String, int>.from(
      snapshot['counters'] as Map? ?? const <String, int>{},
    );
    final sortedCounters = counters.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));
    final events = (snapshot['recent_events'] as List? ?? const [])
        .whereType<Map>()
        .map((e) => Map<String, Object?>.from(e))
        .toList(growable: false)
        .reversed
        .toList(growable: false);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Diagnostics'),
        actions: [
          IconButton(
            tooltip: 'Copy safe diagnostics JSON',
            onPressed: () async {
              await Clipboard.setData(
                ClipboardData(text: diagnostics.exportJson()),
              );
              if (mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Safe diagnostics copied')),
                );
              }
            },
            icon: const Icon(Icons.copy_outlined),
          ),
          IconButton(
            tooltip: 'Clear diagnostics',
            onPressed: () {
              diagnostics.clear();
              setState(() {});
            },
            icon: const Icon(Icons.delete_sweep_outlined),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Card(
            child: ListTile(
              leading: Icon(Icons.privacy_tip_outlined),
              title: Text('Privacy-safe diagnostics'),
              subtitle: Text(
                'Only aggregate operational events are retained in memory. Private messages, credentials, file paths, phone numbers, device IDs and payloads are excluded.',
              ),
            ),
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              _metric('Recent events', events.length),
              _metric('Counters', counters.length),
              _metric('Dropped', snapshot['dropped_events']),
            ],
          ),
          const SizedBox(height: 18),
          Text('Event counters', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          if (sortedCounters.isEmpty)
            const Text('No diagnostics recorded yet.')
          else
            ...sortedCounters.map(
              (entry) => ListTile(
                dense: true,
                title: Text(entry.key),
                trailing: Text('${entry.value}'),
              ),
            ),
          const SizedBox(height: 18),
          Text('Recent events', style: Theme.of(context).textTheme.titleMedium),
          const SizedBox(height: 8),
          if (events.isEmpty)
            const Text('No recent events.')
          else
            ...events.take(80).map(
              (event) => Card(
                child: ListTile(
                  dense: true,
                  title: Text('${event['category']}.${event['event']}'),
                  subtitle: Text(
                    '${event['at']}${event['data'] is Map ? '\n${event['data']}' : ''}',
                  ),
                ),
              ),
            ),
        ],
      ),
    );
  }

  Widget _metric(String title, Object? value) => SizedBox(
        width: 120,
        child: Card(
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(title),
                const SizedBox(height: 4),
                Text(
                  '$value',
                  style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                ),
              ],
            ),
          ),
        ),
      );
}
