import 'dart:async';

import 'package:equatable/equatable.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import 'package:locallink/features/calls/data/gateway/gateway_models.dart';
import 'package:locallink/features/calls/data/gateway/gateway_runtime.dart';
import 'package:locallink/features/calls/data/gateway/internet_gateway_service.dart';

sealed class GatewayEvent extends Equatable {
  const GatewayEvent();
  @override
  List<Object?> get props => [];
}

final class GatewayDiscoveryStarted extends GatewayEvent { const GatewayDiscoveryStarted(); }
final class GatewayDiscovered extends GatewayEvent {
  final GatewayAdvertisement advertisement;
  const GatewayDiscovered(this.advertisement);
  @override List<Object?> get props => [advertisement.gatewayId, advertisement.expiresAt, advertisement.currentGatewaySessions];
}
final class GatewayUpdated extends GatewayDiscovered { const GatewayUpdated(super.advertisement); }
final class GatewayLost extends GatewayEvent {
  final String gatewayId;
  const GatewayLost(this.gatewayId);
  @override List<Object?> get props => [gatewayId];
}
final class GatewayAuthStarted extends GatewayEvent { final String gatewayId; const GatewayAuthStarted(this.gatewayId); @override List<Object?> get props => [gatewayId]; }
final class GatewayAuthenticated extends GatewayEvent { final String gatewayId; final String sessionId; const GatewayAuthenticated(this.gatewayId, this.sessionId); @override List<Object?> get props => [gatewayId, sessionId]; }
final class GatewayAuthFailed extends GatewayEvent { final String gatewayId; final String reason; const GatewayAuthFailed(this.gatewayId, this.reason); @override List<Object?> get props => [gatewayId, reason]; }
final class GatewayRouteRequested extends GatewayEvent { final String gatewayId; final String destinationId; const GatewayRouteRequested(this.gatewayId, this.destinationId); @override List<Object?> get props => [gatewayId, destinationId]; }
final class GatewayRouteResolved extends GatewayEvent { final GatewayRoute route; const GatewayRouteResolved(this.route); @override List<Object?> get props => [route.gatewayId, route.destinationId, route.expiresAt]; }
final class GatewayRouteFailed extends GatewayEvent { final String gatewayId; final String destinationId; final String reason; const GatewayRouteFailed(this.gatewayId, this.destinationId, this.reason); @override List<Object?> get props => [gatewayId, destinationId, reason]; }
final class GatewaySessionStarted extends GatewayEvent { final String gatewayId; final String sessionId; const GatewaySessionStarted(this.gatewayId, this.sessionId); @override List<Object?> get props => [gatewayId, sessionId]; }
final class GatewaySessionLost extends GatewayEvent { final String gatewayId; final String sessionId; const GatewaySessionLost(this.gatewayId, this.sessionId); @override List<Object?> get props => [gatewayId, sessionId]; }
final class GatewayRuntimeChanged extends GatewayEvent { final GatewayRuntimeSnapshot snapshot; const GatewayRuntimeChanged(this.snapshot); @override List<Object?> get props => [snapshot.state, snapshot.reason, snapshot.evaluatedAt]; }

final class GatewayState extends Equatable {
  final String status;
  final GatewayRuntimeSnapshot? runtime;
  final Map<String, GatewayAdvertisement> gateways;
  final Map<String, GatewayRoute> routes;
  final String? activeGatewayId;
  final String? activeSessionId;
  final String? error;
  const GatewayState({this.status = 'initial', this.runtime, this.gateways = const {}, this.routes = const {}, this.activeGatewayId, this.activeSessionId, this.error});
  GatewayState copyWith({String? status, GatewayRuntimeSnapshot? runtime, Map<String, GatewayAdvertisement>? gateways, Map<String, GatewayRoute>? routes, String? activeGatewayId, String? activeSessionId, String? error, bool clearError = false}) => GatewayState(
    status: status ?? this.status,
    runtime: runtime ?? this.runtime,
    gateways: gateways ?? this.gateways,
    routes: routes ?? this.routes,
    activeGatewayId: activeGatewayId ?? this.activeGatewayId,
    activeSessionId: activeSessionId ?? this.activeSessionId,
    error: clearError ? null : (error ?? this.error),
  );
  @override List<Object?> get props => [status, runtime, gateways, routes, activeGatewayId, activeSessionId, error];
}

final class GatewayBloc extends Bloc<GatewayEvent, GatewayState> {
  final InternetGatewayService service;
  StreamSubscription<Map<String, dynamic>>? _serviceSub;

  GatewayBloc({required this.service}) : super(const GatewayState()) {
    on<GatewayDiscoveryStarted>((event, emit) => emit(state.copyWith(status: 'discovering', clearError: true)));
    on<GatewayDiscovered>((event, emit) => emit(state.copyWith(status: event.advertisement.state.name, gateways: {...state.gateways, event.advertisement.gatewayId: event.advertisement})));
    on<GatewayUpdated>((event, emit) => emit(state.copyWith(status: event.advertisement.state.name, gateways: {...state.gateways, event.advertisement.gatewayId: event.advertisement})));
    on<GatewayLost>((event, emit) { final next = {...state.gateways}..remove(event.gatewayId); emit(state.copyWith(status: next.isEmpty ? 'unavailable' : state.status, gateways: next)); });
    on<GatewayAuthStarted>((event, emit) => emit(state.copyWith(status: 'authenticating')));
    on<GatewayAuthenticated>((event, emit) => emit(state.copyWith(status: 'ready', activeGatewayId: event.gatewayId, activeSessionId: event.sessionId, clearError: true)));
    on<GatewayAuthFailed>((event, emit) => emit(state.copyWith(status: 'error', error: event.reason)));
    on<GatewayRouteRequested>((event, emit) => emit(state.copyWith(status: 'discovering', clearError: true)));
    on<GatewayRouteResolved>((event, emit) => emit(state.copyWith(status: 'ready', routes: {...state.routes, '${event.route.gatewayId}:${event.route.destinationId}': event.route})));
    on<GatewayRouteFailed>((event, emit) => emit(state.copyWith(status: 'unavailable', error: event.reason)));
    on<GatewaySessionStarted>((event, emit) => emit(state.copyWith(status: 'ready', activeGatewayId: event.gatewayId, activeSessionId: event.sessionId)));
    on<GatewaySessionLost>((event, emit) => emit(state.copyWith(status: 'unavailable', activeGatewayId: state.activeGatewayId == event.gatewayId ? null : state.activeGatewayId, activeSessionId: state.activeSessionId == event.sessionId ? null : state.activeSessionId)));
    on<GatewayRuntimeChanged>((event, emit) => emit(state.copyWith(status: event.snapshot.state.name, runtime: event.snapshot)));
  }

  void start() {
    if (_serviceSub != null) return;
    add(const GatewayDiscoveryStarted());
    _serviceSub = service.events.listen(_onServiceEvent);
  }

  void _onServiceEvent(Map<String, dynamic> event) {
    final type = event['type']?.toString() ?? '';
    switch (type) {
      case 'gateway_runtime':
        add(GatewayRuntimeChanged(service.runtime));
        break;
      case 'gateway_discovered':
      case 'gateway_advertisement_published':
        try { add(GatewayDiscovered(GatewayAdvertisement.fromJson(Map<String, dynamic>.from(event)))); } catch (_) {}
        break;
      case 'gateway_route_resolved':
        try { add(GatewayRouteResolved(GatewayRoute.fromJson(Map<String, dynamic>.from(event)))); } catch (_) {}
        break;
      case 'gateway_session_authenticated':
      case 'gateway_session_accept':
        final id = event['gateway_id']?.toString() ?? '';
        final sid = event['gateway_session_id']?.toString() ?? event['session_id']?.toString() ?? '';
        if (id.isNotEmpty && sid.isNotEmpty) add(GatewaySessionStarted(id, sid));
        break;
      case 'gateway_session_closed':
      case 'gateway_error':
        final id = event['gateway_id']?.toString() ?? '';
        final sid = event['gateway_session_id']?.toString() ?? '';
        if (id.isNotEmpty && sid.isNotEmpty) add(GatewaySessionLost(id, sid));
        break;
    }
  }

  @override Future<void> close() async { await _serviceSub?.cancel(); _serviceSub = null; return super.close(); }
}
