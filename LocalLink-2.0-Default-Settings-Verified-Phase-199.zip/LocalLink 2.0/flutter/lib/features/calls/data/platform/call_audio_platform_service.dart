import 'package:flutter/services.dart';

/// Native audio routing boundary. The call domain deliberately has no
/// WebRTC audio routing is isolated in the WebRTC transport; this adapter owns only Android audio routing.
class CallAudioPlatformService {
  static const MethodChannel _channel = MethodChannel('locallink/call_audio');

  Future<void> setSpeakerphoneOn(bool enabled) async {
    await _channel.invokeMethod('setSpeakerphoneOn', {'enabled': enabled});
  }

  Future<void> clearCommunicationDevice() async {
    await _channel.invokeMethod('clearCommunicationDevice');
  }
}
