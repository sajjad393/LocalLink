import 'package:locallink/features/calls/data/models/call_session.dart';
import 'package:locallink/features/calls/data/transport/call_transport_mode.dart';

/// One call API shared by offline mesh and WebRTC transports.
/// Signaling policy is owned by CallSessionManager; transports own media and
/// transport-specific control such as ICE or mesh media startup.
abstract interface class CallTransport {
  CallTransportMode get mode;
  bool get supportsVideo;
  bool get isActive;
  Stream<Map<String, dynamic>> get events;

  Future<void> start(CallSession session);

  Future<void> sendControl({required String recipientId, required Map<String, dynamic> payload});

  Future<void> sendOffer(CallSession session, {bool iceRestart = false});

  Future<void> handleSignal(CallSession session, Map<String, dynamic> message);

  Future<Map<String, dynamic>> stats(CallSession session);

  Future<void> setMuted(CallSession session, bool muted);

  Future<void> setVideoEnabled(CallSession session, bool enabled);

  Future<Map<String, dynamic>> startVideo(CallSession session);

  Future<void> switchCamera(CallSession session);

  Future<void> stopVideo(CallSession session);

  Future<void> stop(CallSession session);
}
