import 'call_transport_mode.dart';
import 'network_preference.dart';

/// Central, deterministic transport selection. Local and Internet transports
/// share one call/session architecture; gateway is only considered after the
/// preferred direct/local paths are unavailable.
final class CallTransportSelectionPolicy {
  const CallTransportSelectionPolicy._();

  static CallTransportMode select({
    required CallTransportMode preferredMode,
    required NetworkPreference networkPreference,
    required bool localRouteAvailable,
    required bool directInternetAvailable,
    bool gatewayRouteAvailable = false,
    bool gatewayAuthorized = false,
    bool gatewayCapacityAvailable = false,
    bool internetGatewayEnabled = true,
  }) {
    if (networkPreference == NetworkPreference.internetOnly) {
      if (!directInternetAvailable) throw StateError('Internet-only calling is unavailable');
      return CallTransportMode.webRtc;
    }

    switch (preferredMode) {
      case CallTransportMode.offlineMesh:
        if (!localRouteAvailable) throw StateError('offline mesh transport is unavailable for this peer');
        return CallTransportMode.offlineMesh;
      case CallTransportMode.webRtc:
        if (!directInternetAvailable) throw StateError('Internet/WebRTC calling is unavailable');
        return CallTransportMode.webRtc;
      case CallTransportMode.internetGateway:
        if (!internetGatewayEnabled || !gatewayRouteAvailable || !gatewayAuthorized || !gatewayCapacityAvailable) {
          throw StateError('Internet gateway transport is unavailable for this peer');
        }
        return CallTransportMode.internetGateway;
      case CallTransportMode.auto:
        if (networkPreference == NetworkPreference.localFirst) {
          if (localRouteAvailable) return CallTransportMode.offlineMesh;
          if (directInternetAvailable) return CallTransportMode.webRtc;
        } else if (networkPreference == NetworkPreference.internetPreferred) {
          if (directInternetAvailable) return CallTransportMode.webRtc;
          if (localRouteAvailable) return CallTransportMode.offlineMesh;
        }
        if (internetGatewayEnabled && gatewayRouteAvailable && gatewayAuthorized && gatewayCapacityAvailable) {
          return CallTransportMode.internetGateway;
        }
        throw StateError('No usable call route is available');
    }
  }
}
