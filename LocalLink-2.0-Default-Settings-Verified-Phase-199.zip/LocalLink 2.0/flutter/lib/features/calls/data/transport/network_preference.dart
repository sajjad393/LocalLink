enum NetworkPreference {
  localFirst,
  internetPreferred,
  internetOnly,
}

extension NetworkPreferenceX on NetworkPreference {
  String get storageValue => switch (this) {
    NetworkPreference.localFirst => 'local_first',
    NetworkPreference.internetPreferred => 'internet_preferred',
    NetworkPreference.internetOnly => 'internet_only',
  };

  String get label => switch (this) {
    NetworkPreference.localFirst => 'Local First',
    NetworkPreference.internetPreferred => 'Internet Preferred',
    NetworkPreference.internetOnly => 'Internet Only',
  };

  String get description => switch (this) {
    NetworkPreference.localFirst => 'Use LAN, Wi-Fi Direct and mesh first; use Internet when no local route exists.',
    NetworkPreference.internetPreferred => 'Prefer WebRTC when available; fall back to local mesh, then an Internet gateway.',
    NetworkPreference.internetOnly => 'Never use LAN or mesh. Requires WebRTC Internet calling.',
  };

  static NetworkPreference fromStorage(String value) => switch (value.trim().toLowerCase()) {
    'internet_preferred' => NetworkPreference.internetPreferred,
    'internet_only' => NetworkPreference.internetOnly,
    _ => NetworkPreference.localFirst,
  };
}
