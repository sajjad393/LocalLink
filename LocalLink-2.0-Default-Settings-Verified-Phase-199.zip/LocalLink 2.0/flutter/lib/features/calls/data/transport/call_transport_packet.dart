class CallMediaPacket {
  final String callId;
  final String senderId;
  final String recipientId;
  final int sequence;
  final int timestampMs;
  final String codec;
  final int sampleRate;
  final int frameMs;
  final int ttl;
  final String encryptedPayload;

  const CallMediaPacket({
    required this.callId,
    required this.senderId,
    required this.recipientId,
    required this.sequence,
    required this.timestampMs,
    required this.codec,
    required this.sampleRate,
    required this.frameMs,
    required this.ttl,
    required this.encryptedPayload,
  });

  Map<String, dynamic> toJson() => {
        'type': 'call_media',
        'call_id': callId,
        'sender_id': senderId,
        'recipient_id': recipientId,
        'sequence': sequence,
        'timestamp_ms': timestampMs,
        'codec': codec,
        'sample_rate': sampleRate,
        'frame_ms': frameMs,
        'ttl': ttl,
        'encrypted_payload': encryptedPayload,
      };

  static CallMediaPacket? tryParse(Map<String, dynamic> json) {
    final callId = json['call_id']?.toString().trim() ?? '';
    final senderId = json['sender_id']?.toString().trim() ?? '';
    final recipientId = json['recipient_id']?.toString().trim() ?? '';
    final codec = json['codec']?.toString().trim().toLowerCase() ?? '';
    final sequence = int.tryParse('${json['sequence'] ?? ''}');
    final timestamp = int.tryParse('${json['timestamp_ms'] ?? ''}');
    final sampleRate = int.tryParse('${json['sample_rate'] ?? ''}');
    final frameMs = int.tryParse('${json['frame_ms'] ?? ''}');
    final ttl = int.tryParse('${json['ttl'] ?? ''}');
    final encrypted = (json['encrypted_payload'] ?? json['audio_enc'])?.toString() ?? '';

    if (callId.isEmpty || senderId.isEmpty || recipientId.isEmpty || encrypted.isEmpty) return null;
    if (callId.length > 128 || senderId.length > 128 || recipientId.length > 128) return null;
    if (sequence == null || sequence < 0 || timestamp == null || timestamp <= 0) return null;
    if (sampleRate == null || sampleRate < 8000 || sampleRate > 48000) return null;
    if (frameMs == null || frameMs < 5 || frameMs > 60) return null;
    if (ttl == null || ttl < 0 || ttl > 32) return null;
    if (codec != 'opus' && codec != 'pcm_s16le') return null;

    return CallMediaPacket(
      callId: callId,
      senderId: senderId,
      recipientId: recipientId,
      sequence: sequence,
      timestampMs: timestamp,
      codec: codec,
      sampleRate: sampleRate,
      frameMs: frameMs,
      ttl: ttl,
      encryptedPayload: encrypted,
    );
  }
}
