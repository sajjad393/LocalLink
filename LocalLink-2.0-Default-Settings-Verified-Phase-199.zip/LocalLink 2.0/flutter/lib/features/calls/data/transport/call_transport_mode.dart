enum CallTransportMode {
  auto,
  offlineMesh,
  webRtc,
  internetGateway,
}

extension CallTransportModeX on CallTransportMode {
  String get wireName => switch (this) {
        CallTransportMode.auto => 'auto',
        CallTransportMode.offlineMesh => 'offline_mesh',
        CallTransportMode.webRtc => 'webrtc',
        CallTransportMode.internetGateway => 'internet_gateway',
      };
}
