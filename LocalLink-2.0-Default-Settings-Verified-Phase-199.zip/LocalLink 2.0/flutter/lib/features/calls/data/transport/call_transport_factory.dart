import 'package:locallink/core/services/identity_crypto_service.dart';
import 'package:locallink/features/calls/data/platform/call_audio_platform_service.dart';
import 'package:locallink/features/calls/data/platform/call_media_platform_service.dart';
import 'package:locallink/features/calls/data/models/call_session.dart';
import 'package:locallink/features/calls/data/transport/call_transport.dart';
import 'package:locallink/features/calls/data/transport/call_transport_mode.dart';
import 'package:locallink/features/calls/data/transport/native_mesh_call_transport.dart';
import 'package:locallink/features/calls/data/transport/webrtc_call_transport.dart';
import 'package:locallink/features/calls/data/gateway/gateway_relay_platform_service.dart';
import 'package:locallink/features/calls/data/gateway/internet_gateway_call_transport.dart';
import 'package:locallink/features/calls/data/gateway/internet_gateway_service.dart';
import 'package:locallink/features/connectivity/domain/peer_transport_contract.dart';

/// Selects exactly one media/control transport for a call session. The call
/// state machine never depends directly on either implementation.
final class CallTransportFactory {
  final PeerTransportContract mesh;
  final NativeMeshCallTransport nativeMesh;
  final WebRTCCallTransport webRtc;
  final InternetGatewayCallTransport internetGateway;

  CallTransportFactory({
    required this.mesh,
    required CallMediaPlatformService media,
    required IdentityCryptoService crypto,
    required CallAudioPlatformService audio,
    required CallSignalSender sendSignal,
    required CallTransportStateCallback onState,
    required InternetGatewayService gatewayService,
    required GatewayRelayPlatformService gatewayRelayPlatform,
  }) : nativeMesh = NativeMeshCallTransport(mesh: mesh, media: media, crypto: crypto),
       webRtc = WebRTCCallTransport(audioPlatform: audio, sendSignal: sendSignal, onState: onState),
       internetGateway = InternetGatewayCallTransport(
         gateway: gatewayService,
         media: media,
         audio: audio,
         crypto: crypto,
         relayPlatform: gatewayRelayPlatform,
         directTransport: mesh,
       );

  CallTransport resolve({required CallTransportMode requested, required CallSession session}) {
    switch (requested) {
      case CallTransportMode.offlineMesh:
        if (!mesh.isStarted) throw StateError('offline mesh transport is unavailable');
        return nativeMesh;
      case CallTransportMode.webRtc:
        return webRtc;
      case CallTransportMode.internetGateway:
        return internetGateway;
      case CallTransportMode.auto:
        if (session.transportMode == CallTransportMode.internetGateway) return internetGateway;
        if (mesh.isStarted) return nativeMesh;
        return webRtc;
    }
  }

  Future<void> dispose() async {
    await nativeMesh.dispose();
    await webRtc.dispose();
    await internetGateway.dispose();
  }
}
