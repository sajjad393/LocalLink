import 'dart:async';

import 'package:flutter_webrtc/flutter_webrtc.dart';
import 'package:locallink/features/calls/data/models/call_session.dart';
import 'package:locallink/features/calls/data/platform/call_audio_platform_service.dart';
import 'package:locallink/features/calls/data/transport/call_transport.dart';
import 'package:locallink/features/calls/data/transport/call_transport_mode.dart';

typedef CallSignalSender = Future<void> Function(Map<String, dynamic> message);
typedef CallTransportStateCallback = void Function(CallSession session, String state, String? reason);

/// WebRTC is deliberately isolated here. Offline mesh calling has no import or
/// runtime dependency on this class other than the transport factory.
final class WebRTCCallTransport implements CallTransport {
  final CallAudioPlatformService audioPlatform;
  final CallSignalSender sendSignal;
  final CallTransportStateCallback onState;

  WebRTCCallTransport({
    required this.audioPlatform,
    required this.sendSignal,
    required this.onState,
  });

  final _events = StreamController<Map<String, dynamic>>.broadcast();
  RTCPeerConnection? _peerConnection;
  MediaStream? _localStream;
  final List<RTCIceCandidate> _pendingCandidates = [];
  Timer? _connectionTimer;
  Timer? _recoveryTimer;
  bool _recovering = false;
  bool _disposed = false;
  int _recoveryAttempts = 0;
  DateTime? _lastRecoveryAt;
  CallSession? _session;

  @override
  CallTransportMode get mode => CallTransportMode.webRtc;

  @override
  bool get supportsVideo => false;

  @override
  bool get isActive => _peerConnection != null;

  @override
  Stream<Map<String, dynamic>> get events => _events.stream;

  @override
  Future<void> sendControl({required String recipientId, required Map<String, dynamic> payload}) async =>
      sendSignal(payload);

  @override
  Future<void> start(CallSession session) async {
    _session = session;
    await _preparePeerConnection(session);
  }

  @override
  Future<void> sendOffer(CallSession session, {bool iceRestart = false}) async {
    final pc = _peerConnection;
    if (pc == null) throw StateError('WebRTC peer connection is not initialized');
    final offer = await pc.createOffer({
      'offerToReceiveAudio': 1,
      'offerToReceiveVideo': 0,
      if (iceRestart) 'iceRestart': true,
    });
    final localOffer = RTCSessionDescription(_preferOpus(offer.sdp), offer.type);
    await pc.setLocalDescription(localOffer);
    await sendSignal({
      'type': 'call_offer',
      'call_id': session.id,
      'recipient_id': session.peerId,
      'sdp': localOffer.sdp,
      'sdp_type': localOffer.type,
    });
  }

  @override
  Future<void> handleSignal(CallSession session, Map<String, dynamic> message) async {
    final type = message['type']?.toString() ?? '';
    if (_session?.id != session.id) {
      _session = session;
    }
    switch (type) {
      case 'call_offer':
        await _handleOffer(session, message);
        return;
      case 'call_answer':
        await _handleAnswer(session, message);
        return;
      case 'call_candidate':
        await _handleCandidate(session, message);
        return;
      case 'call_recover':
        await recover(session, message['reason']?.toString() ?? 'peer_requested_recovery');
        return;
      default:
        return;
    }
  }

  Future<void> recover(CallSession session, String reason) async {
    final pc = _peerConnection;
    if (pc == null || _recovering) return;
    if (_recoveryAttempts >= 3) {
      onState(session, 'failed', 'media_recovery_exhausted');
      return;
    }
    final now = DateTime.now();
    if (_lastRecoveryAt != null && now.difference(_lastRecoveryAt!) < const Duration(seconds: 3)) return;
    _lastRecoveryAt = now;
    _recovering = true;
    _recoveryAttempts++;
    onState(session, 'reconnecting', reason);
    try {
      if (session.direction == CallDirection.outgoing) {
        await pc.restartIce();
        await sendOffer(session, iceRestart: true);
      } else {
        await sendSignal({
          'type': 'call_recover',
          'call_id': session.id,
          'recipient_id': session.peerId,
          'reason': reason,
        });
      }
    } catch (_) {
      if (_recoveryAttempts >= 3) onState(session, 'failed', 'media_recovery_failed');
    } finally {
      _recovering = false;
    }
  }

  @override
  Future<Map<String, dynamic>> stats(CallSession session) async {
    final pc = _peerConnection;
    if (pc == null) return const {};
    final reports = await pc.getStats();
    double? rttMs;
    double? jitterMs;
    var packetsLost = 0;
    var packetsReceived = 0;
    final connection = (await pc.getConnectionState())?.name ?? 'unknown';
    final ice = (await pc.getIceConnectionState())?.name ?? 'unknown';
    for (final report in reports) {
      final values = Map<String, dynamic>.from(report.values);
      if (report.type == 'candidate-pair') {
        final state = values['state']?.toString();
        if (state == 'succeeded' || state == 'in-progress' || state == 'waiting') {
          final current = double.tryParse('${values['currentRoundTripTime'] ?? ''}');
          if (current != null) rttMs = current * 1000;
        }
      }
      if (report.type == 'remote-inbound-rtp') {
        final value = double.tryParse('${values['roundTripTime'] ?? ''}');
        if (value != null) rttMs = value * 1000;
      }
      if (report.type == 'inbound-rtp' &&
          (values['kind']?.toString() == 'audio' || values['mediaType']?.toString() == 'audio')) {
        packetsLost += int.tryParse('${values['packetsLost'] ?? 0}') ?? 0;
        packetsReceived += int.tryParse('${values['packetsReceived'] ?? 0}') ?? 0;
        final jitter = double.tryParse('${values['jitter'] ?? ''}');
        if (jitter != null) jitterMs = jitter * 1000;
      }
    }
    final total = packetsLost + packetsReceived;
    return {
      'connection_state': connection,
      'ice_connection_state': ice,
      'rtt_ms': rttMs,
      'jitter_ms': jitterMs,
      'packets_lost': packetsLost,
      'packets_received': packetsReceived,
      'packet_loss_percent': total > 0 ? packetsLost * 100 / total : 0.0,
      'transport': 'webrtc',
    };
  }

  @override
  Future<void> setMuted(CallSession session, bool muted) async {
    for (final track in _localStream?.getAudioTracks() ?? const <MediaStreamTrack>[]) {
      track.enabled = !muted;
    }
  }

  @override
  Future<void> setVideoEnabled(CallSession session, bool enabled) async {
    throw StateError('WebRTC video transport is not enabled by the unified voice transport');
  }

  @override
  Future<Map<String, dynamic>> startVideo(CallSession session) async =>
      throw StateError('WebRTC transport is voice-only in this architecture');

  @override
  Future<void> switchCamera(CallSession session) async =>
      throw StateError('WebRTC transport is voice-only in this architecture');

  @override
  Future<void> stopVideo(CallSession session) async {}

  @override
  Future<void> stop(CallSession session) async {
    _connectionTimer?.cancel();
    _recoveryTimer?.cancel();
    _connectionTimer = null;
    _recoveryTimer = null;
    final stream = _localStream;
    _localStream = null;
    _pendingCandidates.clear();
    try {
      for (final track in stream?.getTracks() ?? const <MediaStreamTrack>[]) {
        await track.stop();
      }
      await stream?.dispose();
    } catch (_) {}
    final pc = _peerConnection;
    _peerConnection = null;
    try {
      await pc?.close();
      await pc?.dispose();
    } catch (_) {}
    try {
      await audioPlatform.clearCommunicationDevice();
    } catch (_) {}
    _session = null;
    _recoveryAttempts = 0;
    _recovering = false;
  }

  Future<void> _preparePeerConnection(CallSession session) async {
    if (_peerConnection != null) return;
    await audioPlatform.setSpeakerphoneOn(session.speakerOn);
    _peerConnection = await createPeerConnection({
      'iceServers': const <Map<String, dynamic>>[],
      'sdpSemantics': 'unified-plan',
    });
    final pc = _peerConnection!;
    pc.onIceCandidate = (candidate) {
      final value = candidate.candidate;
      if (value == null || value.isEmpty) return;
      unawaited(sendSignal({
        'type': 'call_candidate',
        'call_id': session.id,
        'recipient_id': session.peerId,
        'candidate': value,
        'sdp_mid': candidate.sdpMid,
        'sdp_m_line_index': candidate.sdpMLineIndex,
      }));
    };
    pc.onConnectionState = (state) {
      switch (state) {
        case RTCPeerConnectionState.RTCPeerConnectionStateConnected:
          _connectionTimer?.cancel();
          _recoveryAttempts = 0;
          onState(session, 'connected', null);
          break;
        case RTCPeerConnectionState.RTCPeerConnectionStateDisconnected:
          _scheduleRecovery(session, 'peer_disconnected');
          break;
        case RTCPeerConnectionState.RTCPeerConnectionStateFailed:
          unawaited(recover(session, 'peer_failed'));
          break;
        case RTCPeerConnectionState.RTCPeerConnectionStateClosed:
          if (!_disposed) onState(session, 'failed', 'peer_connection_closed');
          break;
        default:
          _armConnectionTimeout(session);
      }
    };
    pc.onIceConnectionState = (state) {
      if (state == RTCIceConnectionState.RTCIceConnectionStateConnected ||
          state == RTCIceConnectionState.RTCIceConnectionStateCompleted) {
        _connectionTimer?.cancel();
        _recoveryAttempts = 0;
        onState(session, 'connected', null);
      } else if (state == RTCIceConnectionState.RTCIceConnectionStateDisconnected) {
        _scheduleRecovery(session, 'ice_disconnected');
      } else if (state == RTCIceConnectionState.RTCIceConnectionStateFailed) {
        unawaited(recover(session, 'ice_failed'));
      }
    };

    _localStream = await navigator.mediaDevices.getUserMedia({
      'audio': {
        'echoCancellation': true,
        'noiseSuppression': true,
        'autoGainControl': true,
      },
      'video': false,
    });
    for (final track in _localStream!.getAudioTracks()) {
      await pc.addTrack(track, _localStream!);
    }
  }

  void _armConnectionTimeout(CallSession session) {
    _connectionTimer?.cancel();
    _connectionTimer = Timer(const Duration(seconds: 20), () async {
      final pc = _peerConnection;
      if (pc == null) return;
      final state = await pc.getConnectionState();
      if (state != RTCPeerConnectionState.RTCPeerConnectionStateConnected) {
        await recover(session, 'connection_timeout');
      }
    });
  }

  void _scheduleRecovery(CallSession session, String reason) {
    if (_recovering) return;
    onState(session, 'reconnecting', reason);
    _recoveryTimer?.cancel();
    _recoveryTimer = Timer(const Duration(seconds: 2), () => unawaited(recover(session, reason)));
  }

  Future<void> _handleOffer(CallSession session, Map<String, dynamic> message) async {
    try {
      await _preparePeerConnection(session);
      final sdp = message['sdp']?.toString();
      if (sdp == null || sdp.isEmpty) throw StateError('empty offer');
      await _peerConnection!.setRemoteDescription(
        RTCSessionDescription(sdp, message['sdp_type']?.toString() ?? 'offer'),
      );
      await _flushCandidates();
      final answer = await _peerConnection!.createAnswer({
        'offerToReceiveAudio': 1,
        'offerToReceiveVideo': 0,
      });
      final localAnswer = RTCSessionDescription(_preferOpus(answer.sdp), answer.type);
      await _peerConnection!.setLocalDescription(localAnswer);
      await sendSignal({
        'type': 'call_answer',
        'call_id': session.id,
        'recipient_id': session.peerId,
        'sdp': localAnswer.sdp,
        'sdp_type': localAnswer.type,
      });
      onState(session, 'connecting', null);
    } catch (_) {
      onState(session, 'failed', 'offer_failed');
    }
  }

  Future<void> _handleAnswer(CallSession session, Map<String, dynamic> message) async {
    final sdp = message['sdp']?.toString();
    if (sdp == null || sdp.isEmpty || _peerConnection == null) return;
    try {
      await _peerConnection!.setRemoteDescription(
        RTCSessionDescription(sdp, message['sdp_type']?.toString() ?? 'answer'),
      );
      await _flushCandidates();
    } catch (_) {
      onState(session, 'failed', 'answer_failed');
    }
  }

  Future<void> _handleCandidate(CallSession session, Map<String, dynamic> message) async {
    final candidateText = message['candidate']?.toString();
    if (candidateText == null || candidateText.isEmpty) return;
    final candidate = RTCIceCandidate(
      candidateText,
      message['sdp_mid']?.toString(),
      int.tryParse(message['sdp_m_line_index']?.toString() ?? '') ?? 0,
    );
    final pc = _peerConnection;
    if (pc == null) {
      _pendingCandidates.add(candidate);
      return;
    }
    final remote = await pc.getRemoteDescription();
    if (remote == null) {
      _pendingCandidates.add(candidate);
      return;
    }
    try {
      await pc.addCandidate(candidate);
    } catch (_) {
      _pendingCandidates.add(candidate);
    }
  }

  Future<void> _flushCandidates() async {
    final pc = _peerConnection;
    if (pc == null || _pendingCandidates.isEmpty) return;
    final remote = await pc.getRemoteDescription();
    if (remote == null) return;
    final pending = List<RTCIceCandidate>.from(_pendingCandidates);
    _pendingCandidates.clear();
    for (final candidate in pending) {
      try {
        await pc.addCandidate(candidate);
      } catch (_) {
        _pendingCandidates.add(candidate);
      }
    }
  }

  String _preferOpus(String? sdp) {
    if (sdp == null || sdp.isEmpty) return sdp ?? '';
    final opusMatch = RegExp(r'a=rtpmap:(\d+) opus/48000(?:/\d+)?', caseSensitive: false).firstMatch(sdp);
    if (opusMatch == null) return sdp;
    final opusPayload = opusMatch.group(1);
    if (opusPayload == null || opusPayload.isEmpty) return sdp;
    final lines = sdp.split('\r\n');
    final audioIndex = lines.indexWhere((line) => line.startsWith('m=audio '));
    if (audioIndex < 0) return sdp;
    final parts = lines[audioIndex].trim().split(RegExp(r'\s+'));
    if (parts.length < 4) return sdp;
    final payloads = parts.sublist(3);
    if (!payloads.contains(opusPayload) || payloads.first == opusPayload) return sdp;
    payloads.remove(opusPayload);
    payloads.insert(0, opusPayload);
    lines[audioIndex] = '${parts.sublist(0, 3).join(' ')} ${payloads.join(' ')}';
    return lines.join('\r\n');
  }

  Future<void> dispose() async {
    _disposed = true;
    final current = _session;
    if (current != null) await stop(current);
    await _events.close();
  }
}
