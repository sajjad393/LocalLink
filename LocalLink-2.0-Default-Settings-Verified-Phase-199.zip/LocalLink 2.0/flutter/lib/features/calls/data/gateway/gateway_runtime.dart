import 'dart:async';


enum GatewayRuntimeState { disabled, evaluating, ready, active, limited, paused, recovering }
enum GatewayPauseReason { none, noInternet, noMesh, meteredNetwork, lowBattery, powerSave, chargingRequired, budgetExhausted, capacityExhausted, thermal, unavailable }

class GatewayRuntimeSnapshot {
  final GatewayRuntimeState state;
  final GatewayPauseReason reason;
  final bool internetValidated;
  final bool wifi;
  final bool metered;
  final bool charging;
  final bool powerSave;
  final int batteryPercent;
  final bool meshAvailable;
  final int upstreamKbps;
  final int downstreamKbps;
  final int activeSessions;
  final int maxSessions;
  final int budgetLimitBytes;
  final int budgetUsedBytes;
  final int budgetRemainingBytes;
  final DateTime? budgetResetAt;
  final DateTime evaluatedAt;

  GatewayRuntimeSnapshot({
    required this.state,
    required this.reason,
    required this.internetValidated,
    required this.wifi,
    required this.metered,
    required this.charging,
    required this.powerSave,
    required this.batteryPercent,
    required this.meshAvailable,
    required this.upstreamKbps,
    required this.downstreamKbps,
    required this.activeSessions,
    required this.maxSessions,
    required this.budgetLimitBytes,
    required this.budgetUsedBytes,
    required this.budgetRemainingBytes,
    required this.budgetResetAt,
    required this.evaluatedAt,
  });

  factory GatewayRuntimeSnapshot.initial() => GatewayRuntimeSnapshot(
        state: GatewayRuntimeState.evaluating,
        reason: GatewayPauseReason.none,
        internetValidated: false,
        wifi: false,
        metered: false,
        charging: false,
        powerSave: false,
        batteryPercent: 100,
        meshAvailable: false,
        upstreamKbps: 0,
        downstreamKbps: 0,
        activeSessions: 0,
        maxSessions: 2,
        budgetLimitBytes: 0,
        budgetUsedBytes: 0,
        budgetRemainingBytes: 0,
        budgetResetAt: null,
        evaluatedAt: DateTime.now().toUtc(),
      );

  bool get gatewayAvailable => state == GatewayRuntimeState.ready || state == GatewayRuntimeState.active || state == GatewayRuntimeState.limited;
}

class GatewayEligibilityPolicy {
  final int minimumBatteryPercent;
  final int minimumUpstreamKbps;
  final bool requireWifi;
  final bool allowMetered;
  final bool requireCharging;

  const GatewayEligibilityPolicy({
    this.minimumBatteryPercent = 20,
    this.minimumUpstreamKbps = 128,
    this.requireWifi = false,
    this.allowMetered = true,
    this.requireCharging = false,
  });

  GatewayPauseReason evaluate({required Map<String, dynamic> capabilities, required bool meshAvailable, required int activeSessions, required int maxSessions, required int budgetRemainingBytes}) {
    if (capabilities['internet_validated'] != true) return GatewayPauseReason.noInternet;
    if (!meshAvailable) return GatewayPauseReason.noMesh;
    if (requireWifi && capabilities['wifi'] != true) return GatewayPauseReason.unavailable;
    if (!allowMetered && capabilities['metered'] == true) return GatewayPauseReason.meteredNetwork;
    final battery = int.tryParse(capabilities['battery_percent']?.toString() ?? '') ?? 100;
    if (battery < minimumBatteryPercent && capabilities['charging'] != true) return GatewayPauseReason.lowBattery;
    if (capabilities['power_save'] == true && capabilities['charging'] != true) return GatewayPauseReason.powerSave;
    if (requireCharging && capabilities['charging'] != true) return GatewayPauseReason.chargingRequired;
    final upstream = int.tryParse(capabilities['upstream_kbps']?.toString() ?? '') ?? 0;
    if (upstream > 0 && upstream < minimumUpstreamKbps) return GatewayPauseReason.unavailable;
    if (activeSessions >= maxSessions) return GatewayPauseReason.capacityExhausted;
    if (budgetRemainingBytes <= 0) return GatewayPauseReason.budgetExhausted;
    return GatewayPauseReason.none;
  }
}

class GatewayAutoManager {
  final dynamic service;
  final dynamic bandwidth;
  final dynamic budget;
  final GatewayEligibilityPolicy policy;
  final Duration interval;
  Timer? _timer;
  bool _started = false;

  GatewayAutoManager({required this.service, required this.bandwidth, required this.budget, this.policy = const GatewayEligibilityPolicy(), this.interval = const Duration(seconds: 5)});

  Future<void> start() async {
    if (_started) return;
    _started = true;
    await budget.start();
    await evaluate();
    _timer = Timer.periodic(interval, (_) { unawaited(evaluate()); });
  }

  Future<void> evaluate() async {
    try {
      if (!service.store.allowThisDeviceAsInternetGateway) {
        await service.updateRuntime(GatewayRuntimeSnapshot(
          state: GatewayRuntimeState.disabled,
          reason: GatewayPauseReason.unavailable,
          internetValidated: false,
          wifi: false,
          metered: false,
          charging: false,
          powerSave: false,
          batteryPercent: 100,
          meshAvailable: service.directTransport.isStarted,
          upstreamKbps: 0,
          downstreamKbps: 0,
          activeSessions: service.activeSessionCount,
          maxSessions: service.maxGatewaySessions,
          budgetLimitBytes: budget.limitBytes,
          budgetUsedBytes: budget.usedBytes,
          budgetRemainingBytes: budget.remainingBytes,
          budgetResetAt: budget.resetAt,
          evaluatedAt: DateTime.now().toUtc(),
        ));
        await service.publishAdvertisement();
        return;
      }
      final caps = await service.deviceCapabilities();
      bandwidth.updateLink(
        upstreamKbps: _int(caps['upstream_kbps']),
        downstreamKbps: _int(caps['downstream_kbps']),
        metered: caps['metered'] == true,
      );
      final mesh = caps['mesh_available'] == true && service.directTransport.isStarted;
      final budgetRemaining = budget.remainingBytes;
      final maxSessions = service.maxGatewaySessions;
      final active = service.activeSessionCount;
      final reason = policy.evaluate(capabilities: caps, meshAvailable: mesh, activeSessions: active, maxSessions: maxSessions, budgetRemainingBytes: budgetRemaining);
      final state = reason == GatewayPauseReason.none
          ? (active > 0 ? GatewayRuntimeState.active : GatewayRuntimeState.ready)
          : GatewayRuntimeState.paused;
      await service.updateRuntime(GatewayRuntimeSnapshot(
        state: state,
        reason: reason,
        internetValidated: caps['internet_validated'] == true,
        wifi: caps['wifi'] == true,
        metered: caps['metered'] == true,
        charging: caps['charging'] == true,
        powerSave: caps['power_save'] == true,
        batteryPercent: _int(caps['battery_percent'], fallback: 100),
        meshAvailable: mesh,
        upstreamKbps: _int(caps['upstream_kbps']),
        downstreamKbps: _int(caps['downstream_kbps']),
        activeSessions: active,
        maxSessions: maxSessions,
        budgetLimitBytes: budget.limitBytes,
        budgetUsedBytes: budget.usedBytes,
        budgetRemainingBytes: budget.remainingBytes,
        budgetResetAt: budget.resetAt,
        evaluatedAt: DateTime.now().toUtc(),
      ));
      await service.publishAdvertisement();
    } catch (_) {
      await service.updateRuntime(GatewayRuntimeSnapshot(
        state: GatewayRuntimeState.recovering,
        reason: GatewayPauseReason.unavailable,
        internetValidated: false,
        wifi: false,
        metered: false,
        charging: false,
        powerSave: false,
        batteryPercent: 100,
        meshAvailable: false,
        upstreamKbps: 0,
        downstreamKbps: 0,
        activeSessions: service.activeSessionCount,
        maxSessions: service.maxGatewaySessions,
        budgetLimitBytes: budget.limitBytes,
        budgetUsedBytes: budget.usedBytes,
        budgetRemainingBytes: budget.remainingBytes,
        budgetResetAt: budget.resetAt,
        evaluatedAt: DateTime.now().toUtc(),
      ));
    }
  }

  Future<void> dispose() async { _timer?.cancel(); _timer = null; _started = false; }
  int _int(Object? v, {int fallback = 0}) => int.tryParse(v?.toString() ?? '') ?? fallback;
}
