import 'dart:convert';

enum GatewayNodeState { discovering, available, busy, unavailable, offline, stale }

GatewayNodeState gatewayNodeStateFromString(String? raw) => switch ((raw ?? '').trim().toUpperCase()) {
      'AVAILABLE' => GatewayNodeState.available,
      'BUSY' => GatewayNodeState.busy,
      'UNAVAILABLE' => GatewayNodeState.unavailable,
      'OFFLINE' => GatewayNodeState.offline,
      'STALE' => GatewayNodeState.stale,
      _ => GatewayNodeState.discovering,
    };

class GatewayAdvertisement {
  final String gatewayId;
  final String nodeId;
  final bool internetAvailable;
  final bool lanAvailable;
  final bool wifiDirectAvailable;
  final bool meshAvailable;
  final bool gatewayCapable;
  final bool gatewayAvailable;
  final String gatewayVersion;
  final int maxGatewaySessions;
  final int currentGatewaySessions;
  final int availableSlots;
  final int? latencyMs;
  final int upstreamKbps;
  final int downstreamKbps;
  final int availableUpstreamKbps;
  final int availableDownstreamKbps;
  final int reservedUpstreamKbps;
  final int packetLossPercent;
  final int healthScore;
  final int budgetLimitBytes;
  final int budgetUsedBytes;
  final int budgetRemainingBytes;
  final DateTime? budgetResetAt;
  final String identityPublicKey;
  final String signingPublicKey;
  final String signature;
  final DateTime advertisedAt;
  final DateTime expiresAt;

  const GatewayAdvertisement({
    required this.gatewayId,
    required this.nodeId,
    required this.internetAvailable,
    required this.lanAvailable,
    required this.wifiDirectAvailable,
    required this.meshAvailable,
    required this.gatewayCapable,
    required this.gatewayAvailable,
    required this.gatewayVersion,
    required this.maxGatewaySessions,
    required this.currentGatewaySessions,
    required this.availableSlots,
    required this.latencyMs,
    this.upstreamKbps = 0,
    this.downstreamKbps = 0,
    this.availableUpstreamKbps = 0,
    this.availableDownstreamKbps = 0,
    this.reservedUpstreamKbps = 0,
    this.packetLossPercent = 0,
    this.healthScore = 100,
    this.budgetLimitBytes = 0,
    this.budgetUsedBytes = 0,
    this.budgetRemainingBytes = 0,
    this.budgetResetAt,
    required this.identityPublicKey,
    required this.signingPublicKey,
    required this.signature,
    required this.advertisedAt,
    required this.expiresAt,
  });

  GatewayNodeState get state {
    if (DateTime.now().isAfter(expiresAt)) return GatewayNodeState.stale;
    if (!gatewayCapable || !internetAvailable || !meshAvailable) return GatewayNodeState.unavailable;
    if (!gatewayAvailable || availableSlots <= 0) return GatewayNodeState.busy;
    return GatewayNodeState.available;
  }

  String canonical() => jsonEncode({
        'gateway_id': gatewayId,
        'node_id': nodeId,
        'internet_available': internetAvailable,
        'lan_available': lanAvailable,
        'wifi_direct_available': wifiDirectAvailable,
        'mesh_available': meshAvailable,
        'gateway_capable': gatewayCapable,
        'gateway_available': gatewayAvailable,
        'gateway_version': gatewayVersion,
        'max_gateway_sessions': maxGatewaySessions,
        'current_gateway_sessions': currentGatewaySessions,
        'available_slots': availableSlots,
        'latency_ms': latencyMs,
        'upstream_kbps': upstreamKbps,
        'downstream_kbps': downstreamKbps,
        'available_upstream_kbps': availableUpstreamKbps,
        'available_downstream_kbps': availableDownstreamKbps,
        'reserved_upstream_kbps': reservedUpstreamKbps,
        'packet_loss_percent': packetLossPercent,
        'health_score': healthScore,
        'budget_limit_bytes': budgetLimitBytes,
        'budget_used_bytes': budgetUsedBytes,
        'budget_remaining_bytes': budgetRemainingBytes,
        'budget_reset_at': budgetResetAt?.toUtc().toIso8601String(),
        'identity_public_key': identityPublicKey,
        'signing_public_key': signingPublicKey,
        'advertised_at': advertisedAt.toUtc().toIso8601String(),
        'expires_at': expiresAt.toUtc().toIso8601String(),
      });

  Map<String, dynamic> toJson() => {
        ...jsonDecode(canonical()) as Map<String, dynamic>,
        'signature': signature,
      };

  factory GatewayAdvertisement.fromJson(Map<String, dynamic> json) => GatewayAdvertisement(
        gatewayId: json['gateway_id']?.toString().trim() ?? '',
        nodeId: json['node_id']?.toString().trim() ?? json['gateway_id']?.toString().trim() ?? '',
        internetAvailable: json['internet_available'] == true,
        lanAvailable: json['lan_available'] == true,
        wifiDirectAvailable: json['wifi_direct_available'] == true,
        meshAvailable: json['mesh_available'] == true,
        gatewayCapable: json['gateway_capable'] != false,
        gatewayAvailable: json['gateway_available'] == true,
        gatewayVersion: json['gateway_version']?.toString() ?? '1',
        maxGatewaySessions: _int(json['max_gateway_sessions'], 1),
        currentGatewaySessions: _int(json['current_gateway_sessions'], 0),
        availableSlots: _int(json['available_slots'], 0),
        latencyMs: _nullableInt(json['latency_ms']),
        upstreamKbps: _int(json['upstream_kbps'], 0),
        downstreamKbps: _int(json['downstream_kbps'], 0),
        availableUpstreamKbps: _int(json['available_upstream_kbps'], _int(json['upstream_kbps'], 0)),
        availableDownstreamKbps: _int(json['available_downstream_kbps'], _int(json['downstream_kbps'], 0)),
        reservedUpstreamKbps: _int(json['reserved_upstream_kbps'], 0),
        packetLossPercent: int.tryParse(json['packet_loss_percent']?.toString() ?? '') ?? 0,
        healthScore: int.tryParse(json['health_score']?.toString() ?? '') ?? 100,
        budgetLimitBytes: _int(json['budget_limit_bytes'], 0),
        budgetUsedBytes: _int(json['budget_used_bytes'], 0),
        budgetRemainingBytes: _int(json['budget_remaining_bytes'], 0),
        budgetResetAt: DateTime.tryParse(json['budget_reset_at']?.toString() ?? '')?.toUtc(),
        identityPublicKey: json['identity_public_key']?.toString() ?? '',
        signingPublicKey: json['signing_public_key']?.toString() ?? '',
        signature: json['signature']?.toString() ?? '',
        advertisedAt: DateTime.tryParse(json['advertised_at']?.toString() ?? '')?.toUtc() ?? DateTime.fromMillisecondsSinceEpoch(0, isUtc: true),
        expiresAt: DateTime.tryParse(json['expires_at']?.toString() ?? '')?.toUtc() ?? DateTime.fromMillisecondsSinceEpoch(0, isUtc: true),
      );

  static int _int(Object? value, int fallback) => int.tryParse(value?.toString() ?? '') ?? fallback;
  static int? _nullableInt(Object? value) => value == null ? null : int.tryParse(value.toString());
}

class GatewayRoute {
  final String gatewayId;
  final String destinationId;
  final bool reachable;
  final String? nextHopId;
  final int hopCount;
  final int? latencyMs;
  final DateTime expiresAt;
  final DateTime resolvedAt;
  final String reason;
  final String signingPublicKey;
  final String signature;

  const GatewayRoute({
    required this.gatewayId,
    required this.destinationId,
    required this.reachable,
    this.nextHopId,
    this.hopCount = 0,
    this.latencyMs,
    required this.expiresAt,
    required this.resolvedAt,
    this.reason = '',
    this.signingPublicKey = '',
    this.signature = '',
  });

  bool get isValid => reachable && DateTime.now().isBefore(expiresAt) && gatewayId.isNotEmpty && destinationId.isNotEmpty;

  factory GatewayRoute.fromJson(Map<String, dynamic> json) => GatewayRoute(
        gatewayId: json['gateway_id']?.toString() ?? '',
        destinationId: json['destination_id']?.toString() ?? '',
        reachable: json['reachable'] == true,
        nextHopId: json['next_hop_id']?.toString(),
        hopCount: int.tryParse(json['hop_count']?.toString() ?? '') ?? 0,
        latencyMs: int.tryParse(json['latency_ms']?.toString() ?? ''),
        expiresAt: DateTime.tryParse(json['expires_at']?.toString() ?? '')?.toUtc() ?? DateTime.fromMillisecondsSinceEpoch(0, isUtc: true),
        resolvedAt: DateTime.tryParse(json['resolved_at']?.toString() ?? '')?.toUtc() ?? DateTime.now().toUtc(),
        reason: json['reason']?.toString() ?? '',
        signingPublicKey: json['signing_public_key']?.toString() ?? '',
        signature: json['signature']?.toString() ?? '',
      );

  String canonical() => jsonEncode({
        'gateway_id': gatewayId,
        'destination_id': destinationId,
        'reachable': reachable,
        'next_hop_id': nextHopId,
        'hop_count': hopCount,
        'latency_ms': latencyMs,
        'expires_at': expiresAt.toUtc().toIso8601String(),
        'resolved_at': resolvedAt.toUtc().toIso8601String(),
        'reason': reason,
      });

  Map<String, dynamic> toJson() => {
        ...jsonDecode(canonical()) as Map<String, dynamic>,
        'signing_public_key': signingPublicKey,
        'signature': signature,
      };
}

class GatewaySession {
  final String sessionId;
  final String gatewayId;
  final String callerId;
  final String destinationId;
  final String nonce;
  final DateTime createdAt;
  final DateTime expiresAt;
  final String gatewaySigningPublicKey;
  final String gatewaySignature;

  const GatewaySession({
    required this.sessionId,
    required this.gatewayId,
    required this.callerId,
    required this.destinationId,
    required this.nonce,
    required this.createdAt,
    required this.expiresAt,
    required this.gatewaySigningPublicKey,
    required this.gatewaySignature,
  });

  bool get isExpired => DateTime.now().isAfter(expiresAt);

  String canonical() => jsonEncode({
        'session_id': sessionId,
        'gateway_id': gatewayId,
        'caller_id': callerId,
        'destination_id': destinationId,
        'nonce': nonce,
        'created_at': createdAt.toUtc().toIso8601String(),
        'expires_at': expiresAt.toUtc().toIso8601String(),
      });

  factory GatewaySession.fromJson(Map<String, dynamic> json) => GatewaySession(
        sessionId: json['session_id']?.toString() ?? '',
        gatewayId: json['gateway_id']?.toString() ?? '',
        callerId: json['caller_id']?.toString() ?? '',
        destinationId: json['destination_id']?.toString() ?? '',
        nonce: json['nonce']?.toString() ?? '',
        createdAt: DateTime.tryParse(json['created_at']?.toString() ?? '')?.toUtc() ?? DateTime.now().toUtc(),
        expiresAt: DateTime.tryParse(json['expires_at']?.toString() ?? '')?.toUtc() ?? DateTime.fromMillisecondsSinceEpoch(0, isUtc: true),
        gatewaySigningPublicKey: json['signing_public_key']?.toString() ?? '',
        gatewaySignature: json['gateway_signature']?.toString() ?? '',
      );
}
