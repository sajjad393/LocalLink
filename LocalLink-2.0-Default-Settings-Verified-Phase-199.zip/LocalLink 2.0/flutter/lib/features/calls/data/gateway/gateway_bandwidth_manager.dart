class GatewaySessionUsage {
  int sentBytes = 0;
  int receivedBytes = 0;
  int reservedKbps = 0;
  int lastActivityMs = 0;
  int get totalBytes => sentBytes + receivedBytes;
}

class GatewayBandwidthManager {
  final Map<String, GatewaySessionUsage> _sessions = {};
  int upstreamKbps = 0;
  int downstreamKbps = 0;
  bool metered = false;
  void updateLink({required int upstreamKbps, required int downstreamKbps, required bool metered}) {
    this.upstreamKbps = upstreamKbps.clamp(0, 1000000).toInt();
    this.downstreamKbps = downstreamKbps.clamp(0, 1000000).toInt();
    this.metered = metered;
  }
  GatewaySessionUsage usage(String id) => _sessions.putIfAbsent(id, GatewaySessionUsage.new);
  bool reserve(String id, int kbps) {
    final requested = kbps.clamp(1, 4096).toInt();
    final capacity = (upstreamKbps > 0 ? upstreamKbps : 512) * 0.8;
    final used = _sessions.values.fold<int>(0, (sum, v) => sum + v.reservedKbps);
    if (used + requested > capacity) return false;
    usage(id).reservedKbps = requested;
    usage(id).lastActivityMs = DateTime.now().millisecondsSinceEpoch;
    return true;
  }
  void ensureSession(String id, {int kbps = 64}) { usage(id); if (_sessions[id]!.reservedKbps == 0) reserve(id, kbps); }
  void release(String id) { _sessions.remove(id); }
  void recordSent(String id, int bytes) { final u=usage(id); u.sentBytes += bytes; u.lastActivityMs=DateTime.now().millisecondsSinceEpoch; }
  void recordReceived(String id, int bytes) { final u=usage(id); u.receivedBytes += bytes; u.lastActivityMs=DateTime.now().millisecondsSinceEpoch; }
  Map<String, GatewaySessionUsage> get snapshot => Map.unmodifiable(_sessions);
}
