class GatewayHealthMonitor {
  final Map<String,_Health> _health = {};
  void recordSuccess(String gatewayId,{int? rttMs}) { final h=_health.putIfAbsent(gatewayId,_Health.new); h.success++; if(rttMs!=null){h.rttMs=.8*h.rttMs+.2*rttMs;} }
  void recordFailure(String gatewayId) { final h=_health.putIfAbsent(gatewayId,_Health.new); h.failures++; }
  void recordLoss(String gatewayId,double percent) { final h=_health.putIfAbsent(gatewayId,_Health.new); h.lossPercent=.8*h.lossPercent+.2*percent.clamp(0,100).toDouble(); }
  double score(String gatewayId) { final h=_health[gatewayId]; if(h==null)return 100; final total=h.success+h.failures; final successRatio=total==0?1.0:h.success/total; final lossPenalty=(h.lossPercent/100).clamp(0,1).toDouble(); final rttPenalty=((h.rttMs)/1000).clamp(0,1).toDouble(); return (100*(.65*successRatio+.20*(1-lossPenalty)+.15*(1-rttPenalty))).clamp(0,100).toDouble(); }
}
class _Health { int success=0; int failures=0; double lossPercent=0; double rttMs=100; }
