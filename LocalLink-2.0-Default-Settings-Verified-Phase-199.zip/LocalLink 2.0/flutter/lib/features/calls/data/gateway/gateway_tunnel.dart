import 'dart:async';
import 'dart:convert';
import 'package:flutter_webrtc/flutter_webrtc.dart';

class GatewayTunnel {
  final String sessionId, localId, remoteId;
  final Future<void> Function(Map<String,dynamic>) sendSignal;
  final Future<void> Function(String packet) onPacket;
  RTCPeerConnection? _pc;
  RTCDataChannel? _channel;
  final List<RTCIceCandidate> _earlyCandidates=[];
  final _opened = Completer<void>();
  bool _closed=false;
  GatewayTunnel({required this.sessionId,required this.localId,required this.remoteId,required this.sendSignal,required this.onPacket});
  Future<void> startOfferer() async { await _ensurePeer(); final dc=await _pc!.createDataChannel('locallink-gateway', RTCDataChannelInit()..ordered=true); _bindChannel(dc); final offer=await _pc!.createOffer({}); await _pc!.setLocalDescription(offer); await _sendSdp('offer',offer); }
  Future<void> handleSignal(Map<String,dynamic> msg) async {
    await _ensurePeer();
    final type=msg['gateway_tunnel_type']?.toString()??'';
    if(type=='offer'){ await _pc!.setRemoteDescription(RTCSessionDescription(msg['sdp']?.toString()??'',msg['sdp_type']?.toString()??'offer')); final answer=await _pc!.createAnswer({}); await _pc!.setLocalDescription(answer); await _sendSdp('answer',answer); }
    else if(type=='answer'){ await _pc!.setRemoteDescription(RTCSessionDescription(msg['sdp']?.toString()??'',msg['sdp_type']?.toString()??'answer')); }
    else if(type=='candidate'){ final c=RTCIceCandidate(msg['candidate']?.toString()??'',msg['sdp_mid']?.toString(),int.tryParse(msg['sdp_m_line_index']?.toString()??'')); if(_pc?.remoteDescription==null){_earlyCandidates.add(c);}else{await _pc!.addCandidate(c);} }
    await _flushCandidates();
  }
  Future<void> sendPacket(String packet) async { if(packet.length>256*1024) throw StateError('gateway packet too large'); if(_channel==null){ await _opened.future.timeout(const Duration(seconds:15)); } final dc=_channel; if(dc==null)throw StateError('gateway data channel unavailable'); dc.send(RTCDataChannelMessage(base64Url.encode(utf8.encode(packet)))); }
  Future<void> _ensurePeer() async { if(_pc!=null)return; _pc=await createPeerConnection({'iceServers':[{'urls':'stun:stun.l.google.com:19302'}],'sdpSemantics':'unified-plan'}); _pc!.onIceCandidate=(c){if(c!=null){sendSignal({'gateway_tunnel_type':'candidate','gateway_session_id':sessionId,'sender_id':localId,'recipient_id':remoteId,'candidate':c.candidate,'sdp_mid':c.sdpMid,'sdp_m_line_index':c.sdpMLineIndex});}}; _pc!.onDataChannel=(c){_bindChannel(c);}; }
  void _bindChannel(RTCDataChannel c){_channel=c;c.onMessage=(m){try{final raw=base64Url.decode(m.text);final packet=utf8.decode(raw);if(!_opened.isCompleted)_opened.complete();unawaited(onPacket(packet));}catch(_){}};c.onDataChannelState=(s){if(s==RTCDataChannelState.RTCDataChannelOpen&&!_opened.isCompleted)_opened.complete();};}
  Future<void> _sendSdp(String type,RTCSessionDescription sdp)=>sendSignal({'gateway_tunnel_type':type,'gateway_session_id':sessionId,'sender_id':localId,'recipient_id':remoteId,'sdp':sdp.sdp,'sdp_type':sdp.type});
  Future<void> _flushCandidates() async {if(_pc?.remoteDescription==null)return;while(_earlyCandidates.isNotEmpty){await _pc!.addCandidate(_earlyCandidates.removeAt(0));}}
  Future<void> close() async {if(_closed)return;_closed=true;try{await _channel?.close();}catch(_){ }try{await _pc?.close();}catch(_){ }_channel=null;_pc=null;if(!_opened.isCompleted)_opened.complete();}
}
