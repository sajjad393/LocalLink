import 'dart:async';

import 'package:locallink/core/services/identity_crypto_service.dart';
import 'package:locallink/features/calls/data/models/call_session.dart';
import 'package:locallink/features/calls/data/platform/call_audio_platform_service.dart';
import 'package:locallink/features/calls/data/platform/call_media_platform_service.dart';
import 'package:locallink/features/calls/data/transport/call_transport.dart';
import 'package:locallink/features/calls/data/transport/call_transport_mode.dart';
import 'package:locallink/features/connectivity/domain/peer_transport_contract.dart';

import 'gateway_models.dart';
import 'gateway_relay_platform_service.dart';
import 'internet_gateway_service.dart';

final class InternetGatewayCallTransport implements CallTransport {
  final InternetGatewayService gateway;
  final CallMediaPlatformService media;
  final CallAudioPlatformService audio;
  final IdentityCryptoService crypto;
  final GatewayRelayPlatformService relayPlatform;
  final PeerTransportContract directTransport;

  final _events = StreamController<Map<String, dynamic>>.broadcast();
  StreamSubscription<Map<String, dynamic>>? _gatewaySub;
  String? _callId;
  GatewaySession? _session;
  bool _active = false;

  InternetGatewayCallTransport({
    required this.gateway,
    required this.media,
    required this.audio,
    required this.crypto,
    required this.relayPlatform,
    required this.directTransport,
  });

  @override
  CallTransportMode get mode => CallTransportMode.internetGateway;
  @override
  bool get supportsVideo => true;
  @override
  bool get isActive => _active;
  @override
  Stream<Map<String, dynamic>> get events {
    _gatewaySub ??= gateway.events.listen((event) {
      if (event['session_id']?.toString() == _session?.sessionId || event['gateway_id']?.toString() == _session?.gatewayId) {
        _events.add(Map<String, dynamic>.from(event));
      }
    });
    return _events.stream;
  }

  GatewaySession? get session => _session;

  @override
  Future<void> start(CallSession session) async {
    final gatewayId = session.gatewayId?.trim();
    final sessionId = session.gatewaySessionId?.trim();
    if (gatewayId == null || gatewayId.isEmpty || sessionId == null || sessionId.isEmpty) {
      throw StateError('gateway route was not selected');
    }
    final isMeshEdge = session.direction == CallDirection.incoming;
    GatewayRoute? route;
    if (!isMeshEdge) {
      route = gateway.registry.routeFor(gatewayId, session.peerId) ?? await gateway.resolveRouteForGateway(gatewayId, session.peerId).then((r) => r.route);
      if (route == null || !route.isValid || route.gatewayId != gatewayId) {
        throw StateError('selected gateway cannot currently reach the callee');
      }
      _session = gateway.sessionForCall(session.id, gatewayId, session.peerId, sessionId: sessionId);
      _session ??= await gateway.createSession(destinationId: session.peerId, route: route);
    } else {
      final expiry = session.gatewaySessionId == null
          ? DateTime.now().add(const Duration(minutes: 5))
          : DateTime.now().add(const Duration(minutes: 5));
      gateway.attachRemoteSession(
        sessionId: sessionId,
        gatewayId: gatewayId,
        callerId: session.peerId,
        destinationId: gateway.store.deviceId ?? '',
        expiresAt: expiry,
        gatewaySigningPublicKey: '',
      );
      _session = gateway.sessionForId(sessionId);
    }
    if (_session == null) throw StateError('gateway session could not be attached');
    _callId = session.id;
    _active = true;
    await relayPlatform.configureCallGateway(
      callId: session.id,
      gatewayId: gatewayId,
      sessionId: sessionId,
      role: isMeshEdge ? 'mesh_gateway_edge' : 'internet_gateway_egress',
    );
    final publicKeys = await crypto.cachedPeerPublicKeys();
    final publicKey = publicKeys[session.peerId];
    if (publicKey == null || publicKey.isEmpty) throw StateError('Peer identity key is unavailable for gateway call');
    final mediaKey = await crypto.deriveCallMediaKey(peerId: session.peerId, peerPublicKey: publicKey, callId: session.id);
    try {
      await audio.setSpeakerphoneOn(session.speakerOn);
      await media.start(callId: session.id, peerId: session.peerId, mediaKey: mediaKey, codec: session.mediaCodec);
      _events.add({'type': 'gateway_ready', 'call_id': session.id, 'gateway_id': gatewayId, 'gateway_session_id': sessionId, 'hop_count': route?.hopCount ?? session.gatewayHopCount, 'latency_ms': route?.latencyMs ?? session.gatewayLatencyMs, 'route_role': isMeshEdge ? 'mesh_gateway_edge' : 'internet_gateway_egress'});
    } catch (_) {
      _active = false;
      await relayPlatform.clearCallGateway(callId: session.id).catchError((_) {});
      rethrow;
    }
  }

  @override
  Future<void> sendControl({required String recipientId, required Map<String, dynamic> payload}) async {
    final session = _session;
    if (session == null || session.isExpired) throw StateError('gateway call session is unavailable');
    final type = payload['type']?.toString() ?? '';
    final signal = CallSessionSignal(
      type: type,
      callId: payload['call_id']?.toString() ?? _callId ?? '',
      senderId: payload['sender_id']?.toString() ?? '',
      recipientId: recipientId,
      reason: payload['reason']?.toString() ?? '',
      transportMode: payload['transport_mode']?.toString() ?? '',
      selectedMediaCodec: payload['selected_media_codec']?.toString() ?? '',
      supportedMediaCodecs: payload['supported_media_codecs'] is List
          ? (payload['supported_media_codecs'] as List).map((e) => e.toString()).toList()
          : const [],
    );
    await gateway.sendCallSignal(signal: signal, session: session, routeRole: _session?.callerId == gateway.store.deviceId ? 'internet_gateway_egress' : 'mesh_gateway_edge');
  }

  @override
  Future<void> sendOffer(CallSession session, {bool iceRestart = false}) =>
      throw StateError('gateway calling does not use WebRTC SDP');

  @override
  Future<void> handleSignal(CallSession session, Map<String, dynamic> message) async {
    if ((message['type']?.toString() ?? '').startsWith('call_offer')) throw StateError('WebRTC signaling cannot be used on an Internet gateway transport');
  }

  @override
  Future<Map<String, dynamic>> stats(CallSession session) async {
    final stats = await media.stats(callId: session.id);
    return {...stats, 'transport': mode.wireName, 'gateway_id': _session?.gatewayId, 'gateway_session_id': _session?.sessionId};
  }

  @override
  Future<void> setMuted(CallSession session, bool muted) => media.setMuted(callId: session.id, muted: muted);
  @override
  Future<void> setVideoEnabled(CallSession session, bool enabled) => media.setVideoEnabled(callId: session.id, enabled: enabled);
  @override
  Future<Map<String, dynamic>> startVideo(CallSession session) async {
    return media.startVideo(callId: session.id, peerId: session.peerId, mediaKey: await _deriveMediaKey(session));
  }
  @override
  Future<void> switchCamera(CallSession session) => media.switchCamera(callId: session.id);
  @override
  Future<void> stopVideo(CallSession session) => media.stopVideo(callId: session.id);

  @override
  Future<void> stop(CallSession session) async {
    final gatewaySession = _session;
    try { await media.stop(callId: session.id); } finally {
      await relayPlatform.clearCallGateway(callId: session.id).catchError((_) {});
      if (gatewaySession != null) await gateway.closeSession(gatewaySession);
      _active = false;
      _callId = null;
      _session = null;
    }
  }

  Future<String> _deriveMediaKey(CallSession session) async {
    final publicKeys = await crypto.cachedPeerPublicKeys();
    final peerKey = publicKeys[session.peerId];
    if (peerKey == null || peerKey.isEmpty) throw StateError('Peer identity key is unavailable');
    return crypto.deriveCallMediaKey(peerId: session.peerId, peerPublicKey: peerKey, callId: session.id);
  }

  String? _extractGatewayId(CallSession session) => session.gatewayId;

  Future<void> dispose() async {
    await _gatewaySub?.cancel();
    await _events.close();
  }
}
