import 'dart:async';
import 'package:locallink/core/services/local_store.dart';

class GatewayBudgetManager {
  final LocalStore store;
  final int defaultLimitBytes;
  Timer? _persistTimer;
  int limitBytes = 2 * 1024 * 1024 * 1024;
  int usedBytes = 0;
  DateTime? resetAt;
  GatewayBudgetManager({required this.store, this.defaultLimitBytes = 2 * 1024 * 1024 * 1024});
  int get remainingBytes => (limitBytes - usedBytes).clamp(0, limitBytes).toInt();

  Future<void> start() async {
    limitBytes = int.tryParse(await store.readSetting('gateway_budget_limit_bytes') ?? '') ?? defaultLimitBytes;
    usedBytes = int.tryParse(await store.readSetting('gateway_budget_used_bytes') ?? '') ?? 0;
    resetAt = DateTime.tryParse(await store.readSetting('gateway_budget_reset_at') ?? '')?.toUtc();
    final now = DateTime.now().toUtc();
    if (resetAt == null || !now.isBefore(resetAt!)) {
      resetAt = DateTime.utc(now.year, now.month + 1, 1);
      usedBytes = 0;
      await persist();
    }
    _persistTimer ??= Timer.periodic(const Duration(seconds: 10), (_) { persist(); });
  }

  bool canConsume(int bytes) => bytes >= 0 && usedBytes + bytes <= limitBytes;
  bool consume(int bytes) { if (!canConsume(bytes)) return false; usedBytes += bytes; return true; }
  Future<void> persist() async {
    await store.writeSetting('gateway_budget_limit_bytes', limitBytes.toString());
    await store.writeSetting('gateway_budget_used_bytes', usedBytes.toString());
    if (resetAt != null) await store.writeSetting('gateway_budget_reset_at', resetAt!.toUtc().toIso8601String());
  }
  Future<void> dispose() async { _persistTimer?.cancel(); _persistTimer = null; await persist(); }
}
