import 'dart:async';
import 'dart:convert';
import 'dart:math';

import 'package:flutter/foundation.dart';
import 'package:locallink/core/services/identity_crypto_service.dart';
import 'package:locallink/core/services/local_store.dart';
import 'package:locallink/core/services/websocket_service.dart';
import 'package:locallink/features/connectivity/domain/peer_transport_contract.dart';

import 'gateway_models.dart';
import 'gateway_registry.dart';
import 'gateway_relay_platform_service.dart';
import 'gateway_runtime.dart';
import 'gateway_budget_manager.dart';
import 'gateway_bandwidth_manager.dart';
import 'gateway_traffic_scheduler.dart';
import 'gateway_route_selector.dart';
import 'gateway_health_monitor.dart';
import 'gateway_tunnel.dart';

final class InternetGatewayService {
  final LocalStore store;
  final WebSocketService socket;
  final PeerTransportContract directTransport;
  final IdentityCryptoService crypto;
  final GatewayRegistry registry;
  final GatewayRelayPlatformService relayPlatform;
  final GatewayBudgetManager budget;
  final GatewayBandwidthManager bandwidth;
  final GatewayTrafficScheduler trafficScheduler;
  final GatewayRouteSelector routeSelector;
  final GatewayHealthMonitor healthMonitor;
  GatewayRuntimeSnapshot _runtime = GatewayRuntimeSnapshot.initial();
  final Map<String, GatewayTunnel> _tunnels = {};

  final _events = StreamController<Map<String, dynamic>>.broadcast();
  final Map<String, Completer<GatewayRoute?>> _routeRequests = {};
  final Map<String, GatewaySession> _sessions = {};
  StreamSubscription<Map<String, dynamic>>? _socketSub;
  StreamSubscription<Map<String, dynamic>>? _nativeSub;
  Timer? _advertisementTimer;
  Timer? _expiryTimer;
  bool _started = false;

  InternetGatewayService({
    required this.store,
    required this.socket,
    required this.directTransport,
    required this.crypto,
    required this.registry,
    required this.relayPlatform,
    required this.budget,
    required this.bandwidth,
    required this.trafficScheduler,
    required this.routeSelector,
    required this.healthMonitor,
  });

  Stream<Map<String, dynamic>> get events => _events.stream;
  bool get started => _started;
  GatewayRuntimeSnapshot get runtime => _runtime;
  int get activeSessionCount => _sessions.values.where((s) => s.gatewayId == store.deviceId).length;
  int get maxGatewaySessions => max(1, store.maxInternetGatewaySessions);
  bool get canActAsGateway => store.allowThisDeviceAsInternetGateway && _runtime.gatewayAvailable && directTransport.isStarted;
  Future<Map<String,dynamic>> deviceCapabilities() => _safeCapabilities();
  Future<void> updateRuntime(GatewayRuntimeSnapshot snapshot) async { _runtime = snapshot; _events.add({'type':'gateway_runtime','state':snapshot.state.name,'reason':snapshot.reason.name,'internet_validated':snapshot.internetValidated,'mesh_available':snapshot.meshAvailable,'active_sessions':snapshot.activeSessions,'max_sessions':snapshot.maxSessions,'upstream_kbps':snapshot.upstreamKbps,'downstream_kbps':snapshot.downstreamKbps,'budget_remaining_bytes':snapshot.budgetRemainingBytes}); }

  Future<void> start() async {
    if (_started) return;
    _started = true;
    _socketSub = socket.messages.listen(_handleSocketMessage);
    _nativeSub = directTransport.events.listen(_handleNativeEvent);
    _advertisementTimer = Timer.periodic(const Duration(seconds: 10), (_) => unawaited(publishAdvertisement()));
    _expiryTimer = Timer.periodic(const Duration(seconds: 5), (_) {
      registry.removeExpired();
      final expired = _sessions.values.where((s) => s.isExpired).toList();
      for (final session in expired) { bandwidth.release(session.sessionId); unawaited(_closeTunnel(session.sessionId)); _sessions.remove(session.sessionId); }
    });
    await budget.start();
    await trafficScheduler.start();
    await publishAdvertisement();
  }

  Future<void> publishAdvertisement() async {
    if (!_started || store.deviceId == null) return;
    final self = store.deviceId!.trim();
    if (self.isEmpty) return;
    if (!store.allowThisDeviceAsInternetGateway) {
      _events.add({'type': 'gateway_sharing_disabled', 'gateway_id': self});
      return;
    }
    final caps = await _safeCapabilities();
    final now = DateTime.now().toUtc();
    final maxSessions = maxGatewaySessions;
    final currentSessions = activeSessionCount;
    final availableSlots = max(0, maxSessions - currentSessions);
    final internet = caps['internet_validated'] == true;
    final mesh = caps['mesh_available'] == true && directTransport.isStarted;
    final allowed = store.allowThisDeviceAsInternetGateway;
    final gatewayAvailable = allowed && canActAsGateway && internet && mesh && availableSlots > 0 && budget.remainingBytes > 0;
    final advertisement = GatewayAdvertisement(
      gatewayId: self,
      nodeId: self,
      internetAvailable: internet,
      lanAvailable: caps['lan_available'] == true,
      wifiDirectAvailable: caps['wifi_direct_available'] == true,
      meshAvailable: mesh,
      gatewayCapable: allowed,
      gatewayAvailable: gatewayAvailable,
      gatewayVersion: '2',
      maxGatewaySessions: maxSessions,
      currentGatewaySessions: currentSessions,
      availableSlots: availableSlots,
      latencyMs: null,
      upstreamKbps: int.tryParse(caps['upstream_kbps']?.toString() ?? '') ?? 0,
      downstreamKbps: int.tryParse(caps['downstream_kbps']?.toString() ?? '') ?? 0,
      availableUpstreamKbps: ((bandwidth.upstreamKbps * 0.8).round() - bandwidth.snapshot.values.fold<int>(0, (sum, usage) => sum + usage.reservedKbps)).clamp(0, 1000000).toInt(),
      availableDownstreamKbps: (bandwidth.downstreamKbps * 0.8).round().clamp(0, 1000000).toInt(),
      reservedUpstreamKbps: bandwidth.snapshot.values.fold<int>(0, (sum, usage) => sum + usage.reservedKbps),
      packetLossPercent: 0,
      healthScore: 100,
      budgetLimitBytes: budget.limitBytes,
      budgetUsedBytes: budget.usedBytes,
      budgetRemainingBytes: budget.remainingBytes,
      budgetResetAt: budget.resetAt,
      identityPublicKey: await crypto.publicKey(),
      signingPublicKey: await crypto.signingPublicKey(),
      signature: '',
      advertisedAt: now,
      expiresAt: now.add(const Duration(seconds: 35)),
    );
    final signed = await _signAdvertisement(advertisement);
    registry.rememberSigningKey(self, signed.signingPublicKey);
    await registry.upsertAdvertisement(signed.toJson());
    if (socket.isConnected) socket.send({
      'type': 'gateway_advertisement',
      'sender_id': self,
      'device_id': self,
      ...signed.toJson(),
    });
    if (directTransport.isStarted) { await directTransport.broadcast({'type':'gateway_advertisement', ...signed.toJson(), 'sender_id': self, 'device_id': self}); }
    _events.add({'type': 'gateway_advertisement_published', ...signed.toJson()});
  }

  Future<RouteResolution> resolveRouteForGateway(String gatewayId, String destinationId) async {
    final gateway = registry[gatewayId];
    if (gateway == null || gateway.state == GatewayNodeState.stale || !gateway.gatewayCapable || !gateway.gatewayAvailable) {
      return const RouteResolution.unavailable('gateway_not_available');
    }
    final cached = registry.routeFor(gatewayId, destinationId);
    if (cached != null && cached.isValid) return RouteResolution(cached);
    final requestId = _randomId('gwroute');
    final completer = Completer<GatewayRoute?>();
    _routeRequests[requestId] = completer;
    try {
      final request = {
        'type': 'gateway_route_query',
        'sender_id': store.deviceId,
        'recipient_id': gatewayId,
        'gateway_id': gatewayId,
        'destination_id': destinationId,
        'request_id': requestId,
        'created_at': DateTime.now().toUtc().toIso8601String(),
      };
      if (socket.isConnected) {
        socket.send(request);
      } else if (gatewayId == store.deviceId) {
        final snapshot = await relayPlatform.routeSnapshot(destinationId: destinationId);
        final localRoute = _routeFromSnapshot(gatewayId, destinationId, snapshot);
        if (localRoute != null) {
          registry.rememberSigningKey(gatewayId, await crypto.signingPublicKey());
          final signed = await _signRoute(localRoute);
          registry.upsertRoute(signed);
          return RouteResolution(signed);
        }
      } else {
        final ok = await relayPlatform.forwardSignalToMesh(destinationId: gatewayId, sessionId: requestId, message: request);
        if (!ok) return const RouteResolution.unavailable('gateway_signaling_unavailable');
      }
      final route = await completer.future.timeout(const Duration(seconds: 4), onTimeout: () => null);
      if (route == null || !route.isValid) return const RouteResolution.unavailable('destination_unreachable');
      return RouteResolution(route);
    } finally {
      _routeRequests.remove(requestId);
    }
  }

  Future<GatewayRoute?> resolveRoute(String destinationId, {Set<String> excludedGatewayIds = const {}}) async {
    final candidates = routeSelector.rankAdvertisements(registry.gateways.where((g) => !excludedGatewayIds.contains(g.gatewayId)));
    final resolved = <({GatewayAdvertisement gateway, GatewayRoute route, double score})>[];
    for (final candidate in candidates) {
      final result = await resolveRouteForGateway(candidate.gatewayId, destinationId);
      final route = result.route;
      if (route != null && route.isValid) {
        resolved.add((gateway: candidate, route: route, score: routeSelector.score(gateway: candidate, route: route, healthScore: healthMonitor.score(candidate.gatewayId))));
      }
    }
    if (resolved.isEmpty) return null;
    resolved.sort((a, b) => b.score.compareTo(a.score));
    return resolved.first.route;
  }

  Future<GatewaySession> createSession({required String destinationId, required GatewayRoute route}) async {
    if (!route.isValid) throw StateError('invalid gateway route');
    final gateway = registry[route.gatewayId];
    if (gateway == null || gateway.state != GatewayNodeState.available) throw StateError('gateway unavailable');
    final self = store.deviceId?.trim() ?? '';
    if (self.isEmpty) throw StateError('device identity unavailable');
    final sessionId = _randomId('gws');
    final nonce = _randomId('nonce');
    final now = DateTime.now().toUtc();
    final expires = now.add(const Duration(minutes: 5));
    final canonical = jsonEncode({
      'session_id': sessionId,
      'gateway_id': route.gatewayId,
      'caller_id': self,
      'destination_id': destinationId,
      'nonce': nonce,
      'created_at': now.toIso8601String(),
      'expires_at': expires.toIso8601String(),
    });
    final signature = await crypto.signPayload(canonical);
    final request = {
      'type': 'gateway_session_create',
      'sender_id': self,
      'recipient_id': route.gatewayId,
      'gateway_id': route.gatewayId,
      'gateway_session_id': sessionId,
      'gateway_nonce': nonce,
      'gateway_signature': signature,
      'signing_public_key': await crypto.signingPublicKey(),
      'gateway_destination_id': destinationId,
      'gateway_expires_at': expires.toIso8601String(),
      'gateway_hop_count': route.hopCount,
      'gateway_latency_ms': route.latencyMs,
      'created_at': now.toIso8601String(),
    };
    if (socket.isConnected) {
      socket.send(request);
    } else {
      final ok = await relayPlatform.forwardSignalToMesh(destinationId: route.gatewayId, sessionId: sessionId, message: request);
      if (!ok) throw StateError('gateway authentication channel is unavailable');
    }
    final provisional = GatewaySession(
      sessionId: sessionId,
      gatewayId: route.gatewayId,
      callerId: self,
      destinationId: destinationId,
      nonce: nonce,
      createdAt: now,
      expiresAt: expires,
      gatewaySigningPublicKey: gateway.signingPublicKey,
      gatewaySignature: '',
    );
    _sessions[sessionId] = provisional;
    _events.add({'type': 'gateway_session_requested', 'gateway_id': route.gatewayId, 'session_id': sessionId});
    return await _waitForAcceptedSession(provisional);
  }

  GatewaySession? sessionForCall(String callId, String gatewayId, String destinationId, {String? sessionId}) {
    if (sessionId != null && sessionId.isNotEmpty) {
      final exact = _sessions[sessionId];
      if (exact != null && !exact.isExpired) return exact;
    }
    return _sessions.values.firstWhereOrNull((s) => s.gatewayId == gatewayId && s.destinationId == destinationId && !s.isExpired);
  }

  GatewaySession? sessionForId(String sessionId) => _sessions[sessionId];

  void attachRemoteSession({required String sessionId, required String gatewayId, required String callerId, required String destinationId, required DateTime expiresAt, required String gatewaySigningPublicKey, String gatewaySignature = ''}) {
    final current = _sessions[sessionId];
    if (current != null && !current.isExpired) return;
    _sessions[sessionId] = GatewaySession(
      sessionId: sessionId,
      gatewayId: gatewayId,
      callerId: callerId,
      destinationId: destinationId,
      nonce: '',
      createdAt: DateTime.now().toUtc(),
      expiresAt: expiresAt,
      gatewaySigningPublicKey: gatewaySigningPublicKey,
      gatewaySignature: gatewaySignature,
    );
  }

  Future<void> sendCallSignal({required CallSessionSignal signal, required GatewaySession session, String? routeRole}) async {
    if (session.isExpired) throw StateError('gateway session expired');
    final self = store.deviceId?.trim() ?? '';
    if (self.isEmpty) throw StateError('device identity unavailable');
    final envelope = {
      'type': 'gateway_call_signal',
      'sender_id': self,
      'recipient_id': session.gatewayId,
      'gateway_id': session.gatewayId,
      'gateway_session_id': session.sessionId,
      'call_id': signal.callId,
      'gateway_destination_id': session.callerId == self ? session.destinationId : session.callerId,
      'body': jsonEncode(signal.toJson()),
      'created_at': DateTime.now().toUtc().toIso8601String(),
      'route_role': routeRole ?? (socket.isConnected ? 'internet_gateway_egress' : 'mesh_gateway_edge'),
    };
    if (socket.isConnected && session.callerId == self) {
      socket.send(envelope);
      return;
    }
    if (session.gatewayId == self) {
      socket.send({...envelope, 'recipient_id': session.destinationId});
      return;
    }
    final ok = await relayPlatform.forwardSignalToMesh(destinationId: session.gatewayId, sessionId: session.sessionId, message: envelope);
    if (!ok) throw StateError('gateway route is unavailable');
  }

  Future<void> sendGatewayPacket({required String sessionId, required String gatewayId, required String destinationId, required String packet}) async {
    final session = _sessions[sessionId];
    if (session == null || session.isExpired) throw StateError('gateway session unavailable');
    final tunnel = _tunnels[sessionId];
    if (tunnel != null && gatewayId != store.deviceId) {
      final bytes = utf8.encode(packet).length;
      bandwidth.recordSent(sessionId, bytes);
      Map<String,dynamic> meta = const {};
      try { meta = _decodeMap(packet) ?? const {}; } catch (_) {}
      final cls = gatewayTrafficClassFor(meta);
      await trafficScheduler.schedule(cls, () => tunnel.sendPacket(packet));
      return;
    }
    if (gatewayId == store.deviceId) {
      final tunnel = _tunnels[sessionId];
      if (tunnel == null) throw StateError('gateway tunnel unavailable');
      final bytes = utf8.encode(packet).length;
      if (!budget.canConsume(bytes)) throw StateError('gateway data budget exhausted');
      budget.consume(bytes); bandwidth.recordSent(sessionId, bytes);
      await trafficScheduler.schedule(GatewayTrafficClass.voice, () => tunnel.sendPacket(packet));
      return;
    }
    // Legacy mesh ingress is intentionally retained only as the local caller→gateway edge.
    final ok = await relayPlatform.forwardToMesh(destinationId: gatewayId, sessionId: sessionId, packet: packet);
    if (!ok) throw StateError('gateway route is unavailable');
  }

  Future<void> closeSession(GatewaySession session) async {
    _sessions.remove(session.sessionId);
    bandwidth.release(session.sessionId);
    await _closeTunnel(session.sessionId);
    if (socket.isConnected && store.deviceId == session.callerId) {
      socket.send({'type': 'gateway_session_close', 'sender_id': store.deviceId, 'recipient_id': session.gatewayId, 'gateway_session_id': session.sessionId, 'gateway_id': session.gatewayId});
    } else if (session.gatewayId != store.deviceId) {
      await relayPlatform.forwardSignalToMesh(
        destinationId: session.gatewayId,
        sessionId: session.sessionId,
        message: {
          'type': 'gateway_session_close',
          'sender_id': store.deviceId,
          'recipient_id': session.gatewayId,
          'gateway_id': session.gatewayId,
          'gateway_session_id': session.sessionId,
        },
      );
    }
  }

  Future<void> _handleSocketMessage(Map<String, dynamic> msg) async {
    final type = msg['type']?.toString() ?? '';
    switch (type) {
      case 'gateway_advertisement':
        final accepted = await registry.upsertAdvertisement(msg);
        if (accepted) _events.add({'type': 'gateway_discovered', ...msg});
        break;
      case 'gateway_tunnel_signal':
        await _handleGatewayTunnelSignal(msg);
        break;
      case 'gateway_route_query':
        final destination = msg['destination_id']?.toString().trim() ?? '';
        if (msg['gateway_id']?.toString().trim() == store.deviceId && destination.isNotEmpty) {
          final snapshot = await relayPlatform.routeSnapshot(destinationId: destination);
          final route = _routeFromSnapshot(store.deviceId!, destination, snapshot);
          final signed = route == null ? GatewayRoute(
            gatewayId: store.deviceId!, destinationId: destination, reachable: false,
            expiresAt: DateTime.now().toUtc().add(const Duration(seconds: 10)), resolvedAt: DateTime.now().toUtc(), reason: 'destination_unreachable') : await _signRoute(route);
          socket.send({'type':'gateway_route_response','sender_id':store.deviceId,'recipient_id':msg['sender_id'],'gateway_id':store.deviceId,'destination_id':destination,'request_id':msg['request_id'],'reachable':signed.reachable,'next_hop_id':signed.nextHopId,'hop_count':signed.hopCount,'latency_ms':signed.latencyMs,'expires_at':signed.expiresAt.toUtc().toIso8601String(),'resolved_at':signed.resolvedAt.toUtc().toIso8601String(),'reason':signed.reason,'signing_public_key':signed.signingPublicKey,'signature':signed.signature});
        }
        break;
      case 'gateway_session_create':
        await _handleGatewaySessionCreate(msg);
        break;
      case 'gateway_route_response':
        final route = GatewayRoute.fromJson(msg);
        final ok = await registry.upsertRoute(route);
        if (ok) {
          final requestId = msg['request_id']?.toString() ?? '';
          final completer = _routeRequests[requestId];
          if (completer != null && !completer.isCompleted) completer.complete(route);
          _events.add({'type': 'gateway_route_resolved', ...msg});
        }
        break;
      case 'gateway_session_accept':
      case 'gateway_session_reject':
        final sessionId = msg['gateway_session_id']?.toString() ?? '';
        _events.add({'type': type, ...msg});
        final current = _sessions[sessionId];
        if (type == 'gateway_session_accept' && current != null) {
          final signingKey = msg['signing_public_key']?.toString() ?? current.gatewaySigningPublicKey;
          final gatewaySignature = msg['gateway_signature']?.toString() ?? '';
          final canonical = jsonEncode({
            'session_id': current.sessionId,
            'gateway_id': current.gatewayId,
            'caller_id': current.callerId,
            'destination_id': current.destinationId,
            'nonce': current.nonce,
            'created_at': current.createdAt.toUtc().toIso8601String(),
            'expires_at': DateTime.tryParse(msg['gateway_expires_at']?.toString() ?? '')?.toUtc().toIso8601String() ?? current.expiresAt.toUtc().toIso8601String(),
          });
          if (signingKey.isEmpty || gatewaySignature.isEmpty || !await crypto.verifyPayloadSignature(canonicalPayload: canonical, signature: gatewaySignature, signingPublicKey: signingKey)) {
            _sessions.remove(sessionId);
            _events.add({'type': 'gateway_error', 'gateway_session_id': sessionId, 'gateway_id': current.gatewayId, 'reason': 'invalid_gateway_session_signature'});
            break;
          }
          final accepted = GatewaySession(
            sessionId: current.sessionId,
            gatewayId: current.gatewayId,
            callerId: current.callerId,
            destinationId: current.destinationId,
            nonce: current.nonce,
            createdAt: current.createdAt,
            expiresAt: DateTime.tryParse(msg['gateway_expires_at']?.toString() ?? '')?.toUtc() ?? current.expiresAt,
            gatewaySigningPublicKey: msg['signing_public_key']?.toString() ?? current.gatewaySigningPublicKey,
            gatewaySignature: msg['gateway_signature']?.toString() ?? '',
          );
          _sessions[sessionId] = accepted;
        }
        break;
      case 'gateway_packet':
        await _handleIncomingGatewayPacket(msg);
        break;
      case 'gateway_call_signal':
        await _handleIncomingGatewaySignal(msg);
        break;
      case 'gateway_session_closed':
        final sessionId = msg['gateway_session_id']?.toString() ?? '';
        _sessions.remove(sessionId);
        _events.add({'type': 'gateway_session_closed', ...msg});
        break;
      case 'gateway_error':
      case 'error':
        if (msg['gateway_session_id'] != null || msg['gateway_id'] != null) _events.add({'type': 'gateway_error', ...msg});
        break;
    }
  }

  Future<void> _handleGatewaySessionCreate(Map<String, dynamic> msg) async {
    final self = store.deviceId?.trim() ?? '';
    if (msg['gateway_id']?.toString().trim() != self || msg['recipient_id']?.toString().trim() != self) return;
    if (!store.allowThisDeviceAsInternetGateway || !canActAsGateway) {
      _events.add({'type': 'gateway_session_rejected', 'gateway_id': self, 'reason': 'gateway_sharing_disabled'});
      return;
    }
    final sessionId = msg['gateway_session_id']?.toString().trim() ?? '';
    final callerId = msg['sender_id']?.toString().trim() ?? '';
    final destination = msg['destination_id']?.toString().trim() ?? msg['gateway_destination_id']?.toString().trim() ?? '';
    final nonce = msg['gateway_nonce']?.toString() ?? '';
    final createdText = msg['created_at']?.toString() ?? '';
    final expiresText = msg['gateway_expires_at']?.toString() ?? '';
    final signingKey = msg['signing_public_key']?.toString() ?? '';
    final requestSignature = msg['gateway_signature']?.toString() ?? '';
    Future<void> reject(String error) async {
      final out={'type':'gateway_session_reject','sender_id':self,'recipient_id':callerId,'gateway_id':self,'gateway_session_id':sessionId,'error':error};
      if (socket.isConnected) socket.send(out);
      await relayPlatform.forwardSignalToMesh(destinationId: callerId, sessionId: sessionId, message: out).catchError((_) {});
    }
    if (sessionId.isEmpty || callerId.isEmpty || destination.isEmpty || signingKey.isEmpty || requestSignature.isEmpty) { await reject('invalid_gateway_session_request'); return; }
    if (activeSessionCount >= maxGatewaySessions || budget.remainingBytes <= 0) { await reject('gateway_unavailable'); return; }
    if (!bandwidth.reserve(sessionId, 64)) { await reject('gateway_bandwidth_unavailable'); return; }
    final destinationRoute = _routeFromSnapshot(self, destination, await relayPlatform.routeSnapshot(destinationId: destination));
    if (destinationRoute == null || !destinationRoute.isValid) { bandwidth.release(sessionId); await reject('destination_unreachable'); return; }
    final canonical = jsonEncode({'session_id':sessionId,'gateway_id':self,'caller_id':callerId,'destination_id':destination,'nonce':nonce,'created_at':createdText,'expires_at':expiresText});
    if (!await crypto.verifyPayloadSignature(canonicalPayload: canonical, signature: requestSignature, signingPublicKey: signingKey)) { bandwidth.release(sessionId); await reject('gateway_auth_failed'); return; }
    final expiresAt = DateTime.tryParse(expiresText)?.toUtc() ?? DateTime.now().toUtc().add(const Duration(minutes: 5));
    final session = GatewaySession(sessionId:sessionId,gatewayId:self,callerId:callerId,destinationId:destination,nonce:nonce,createdAt:DateTime.tryParse(createdText)?.toUtc() ?? DateTime.now().toUtc(),expiresAt:expiresAt,gatewaySigningPublicKey:await crypto.signingPublicKey(),gatewaySignature:'');
    _sessions[sessionId]=session;
    final signedCanonical = jsonEncode({'session_id':sessionId,'gateway_id':self,'caller_id':callerId,'destination_id':destination,'nonce':nonce,'created_at':createdText,'expires_at':expiresText});
    final gatewaySig = await crypto.signPayload(signedCanonical);
    final accept={'type':'gateway_session_accept','sender_id':self,'recipient_id':callerId,'gateway_id':self,'gateway_session_id':sessionId,'gateway_expires_at':expiresText,'signing_public_key':await crypto.signingPublicKey(),'gateway_signature':gatewaySig,'created_at':DateTime.now().toUtc().toIso8601String()};
    if (socket.isConnected) socket.send(accept);
    await relayPlatform.forwardSignalToMesh(destinationId: callerId, sessionId: sessionId, message: accept).catchError((_) {});
    await _ensureTunnelForSession(sessionId, session, true);
    _events.add({'type':'gateway_session_authenticated','gateway_id':self,'gateway_session_id':sessionId,'destination_id':destination});
  }

  Future<void> _handleIncomingGatewaySignal(Map<String, dynamic> msg) async {
    final self = store.deviceId?.trim() ?? '';
    final body = _decodeMap(msg['body']);
    if (body == null) return;
    final gatewayId = msg['gateway_id']?.toString() ?? '';
    final destination = msg['gateway_destination_id']?.toString() ?? msg['recipient_id']?.toString() ?? '';
    final sessionId = msg['gateway_session_id']?.toString() ?? '';
    final routeRole = msg['route_role']?.toString() ?? '';
    if (gatewayId == self) {
      if (routeRole == 'internet_gateway_egress' && destination.isNotEmpty && destination != self) {
        final forwarded = await relayPlatform.forwardSignalToMesh(
          destinationId: destination,
          sessionId: sessionId,
          message: body,
        );
        if (!forwarded) _events.add({'type': 'gateway_error', 'gateway_id': self, 'gateway_session_id': sessionId, 'call_id': body['call_id'], 'reason': 'gateway_mesh_signal_unreachable'});
        return;
      }
      // A signal arriving from the local mesh edge is headed back to the
      // Internet participant. Forward the original call signal without opening
      // or decoding any media state at the gateway.
      final sender = body['sender_id']?.toString() ?? '';
      if (sender.isEmpty || destination.isEmpty) return;
      socket.send({
        'type': 'gateway_call_signal',
        'sender_id': sender,
        'recipient_id': self,
        'gateway_id': self,
        'gateway_session_id': sessionId,
        'call_id': body['call_id'],
        'gateway_destination_id': destination,
        'body': jsonEncode(body),
        'created_at': DateTime.now().toUtc().toIso8601String(),
        'route_role': 'mesh_gateway_edge',
      });
      return;
    }
    // This device is the LAN/mesh edge. The original call signal came from the
    // gateway's remote participant and is now delivered locally.
    _events.add({'type': 'gateway_call_signal', 'signal': body, 'call_id': body['call_id'], 'gateway_id': gatewayId, 'gateway_session_id': sessionId});
  }

  Future<void> _handleIncomingGatewayPacket(Map<String, dynamic> msg) async {
    final self = store.deviceId?.trim() ?? '';
    final packet = msg['gateway_packet']?.toString() ?? msg['packet']?.toString() ?? '';
    final destination = msg['gateway_destination_id']?.toString() ?? '';
    final gatewayId = msg['gateway_id']?.toString() ?? '';
    if (packet.isEmpty) return;
    if (self == gatewayId && destination.isNotEmpty && destination != self) {
      final forwarded = await relayPlatform.forwardToMesh(destinationId: destination, sessionId: msg['gateway_session_id']?.toString() ?? '', packet: packet);
      if (forwarded) _events.add({'type': 'gateway_packet_forwarded', ...msg});
      return;
    }
    final delivered = await relayPlatform.deliverGatewayPacket(packet: packet);
    if (delivered) _events.add({'type': 'gateway_packet_received', 'gateway_id': gatewayId, 'gateway_session_id': msg['gateway_session_id'], 'packet': packet});
  }

  Future<void> _handleGatewayRouteQueryFromMesh(Map<String,dynamic> message) async {
    final self=store.deviceId?.trim()??'';
    if(message['gateway_id']?.toString()!=self || message['recipient_id']?.toString()!=self) return;
    final destination=message['destination_id']?.toString().trim()??''; final sender=message['sender_id']?.toString().trim()??''; final requestId=message['request_id']?.toString()??'';
    if(destination.isEmpty || sender.isEmpty) return;
    final route=_routeFromSnapshot(self,destination,await relayPlatform.routeSnapshot(destinationId:destination));
    final signed=route==null?GatewayRoute(gatewayId:self,destinationId:destination,reachable:false,expiresAt:DateTime.now().toUtc().add(const Duration(seconds:10)),resolvedAt:DateTime.now().toUtc(),reason:'destination_unreachable'):await _signRoute(route);
    final response={'type':'gateway_route_response','sender_id':self,'recipient_id':sender,'gateway_id':self,'destination_id':destination,'request_id':requestId,'reachable':signed.reachable,'next_hop_id':signed.nextHopId,'hop_count':signed.hopCount,'latency_ms':signed.latencyMs,'expires_at':signed.expiresAt.toUtc().toIso8601String(),'resolved_at':signed.resolvedAt.toUtc().toIso8601String(),'reason':signed.reason,'signing_public_key':signed.signingPublicKey,'signature':signed.signature};
    if(socket.isConnected) socket.send(response);
    await relayPlatform.forwardSignalToMesh(destinationId:sender,sessionId:requestId,message:response).catchError((_) {});
  }

  Future<void> _handleNativeEvent(Map<String, dynamic> event) async {
    final type = event['type']?.toString() ?? '';
    if (type == 'gateway_advertisement_received') {
      final ad = _decodeMap(event['advertisement']);
      if (ad != null && await registry.upsertAdvertisement(ad)) _events.add({'type':'gateway_discovered', ...ad});
    } else if (type == 'gateway_packet_outbound') {
      final gatewayId = event['gateway_id']?.toString() ?? '';
      final destination = event['destination_id']?.toString() ?? '';
      final sessionId = event['session_id']?.toString() ?? '';
      final packet = event['packet']?.toString() ?? '';
      final session = _sessions[sessionId];
      if (session != null && packet.isNotEmpty) {
        final tunnel = _tunnels[sessionId];
        if (tunnel != null && session.destinationId == store.deviceId) {
          final bytes=utf8.encode(packet).length; bandwidth.recordSent(sessionId,bytes); await trafficScheduler.schedule(GatewayTrafficClass.voice,()=>tunnel.sendPacket(packet));
        } else if (gatewayId.isNotEmpty && destination.isNotEmpty) {
          await sendGatewayPacket(sessionId: sessionId, gatewayId: gatewayId, destinationId: destination, packet: packet);
        }
      }
    } else if (type == 'gateway_packet_forwarded') {
      final self=store.deviceId?.trim()??''; final sessionId=event['session_id']?.toString()??''; final packet=event['packet']?.toString()??''; final session=_sessions[sessionId];
      if (self.isNotEmpty && session != null && session.gatewayId==self && packet.isNotEmpty) {
        final tunnel=_tunnels[sessionId]; if(tunnel==null) return; final bytes=utf8.encode(packet).length; if(!budget.consume(bytes))return; bandwidth.recordSent(sessionId,bytes); await trafficScheduler.schedule(GatewayTrafficClass.voice,()=>tunnel.sendPacket(packet));
      }
      _events.add(event);
    } else if (type == 'gateway_signal_received') {
      final gatewayId=event['gateway_id']?.toString()??''; final self=store.deviceId?.trim()??''; final message=_decodeMap(event['message']); final sessionId=event['session_id']?.toString()??''; if(message==null)return;
      final msgType=message['type']?.toString()??'';
      if(msgType=='gateway_session_create' && gatewayId==self){ await _handleGatewaySessionCreate(message); return; }
      if(msgType=='gateway_route_query' && gatewayId==self){ await _handleGatewayRouteQueryFromMesh(message); return; }
      if(msgType=='gateway_session_accept' || msgType=='gateway_session_reject' || msgType=='gateway_route_response'){ await _handleSocketMessage(message); return; }
      if(gatewayId==self){
        final bodyRecipient=message['recipient_id']?.toString()??'';
        final envelope={'type':'gateway_call_signal','sender_id':message['sender_id']??event['sender_id']??self,'recipient_id':self,'gateway_id':self,'gateway_session_id':sessionId,'call_id':message['call_id'],'gateway_destination_id':bodyRecipient,'body':jsonEncode(message),'created_at':DateTime.now().toUtc().toIso8601String()};
        if(socket.isConnected) socket.send(envelope); else { await relayPlatform.forwardSignalToMesh(destinationId: bodyRecipient, sessionId: sessionId, message: message); }
      } else {
        _events.add({'type':'gateway_call_signal','signal':message,'call_id':message['call_id'],'gateway_id':gatewayId,'gateway_session_id':sessionId});
      }
    } else if (type == 'gateway_signal_outbound') {
      final gatewayId=event['gateway_id']?.toString()??''; final sessionId=event['session_id']?.toString()??''; final message=_decodeMap(event['message']);
      if(gatewayId.isNotEmpty && sessionId.isNotEmpty && message!=null){ if(socket.isConnected && gatewayId!=store.deviceId) socket.send(message); else if(gatewayId!=store.deviceId) await relayPlatform.forwardSignalToMesh(destinationId:gatewayId,sessionId:sessionId,message:message); }
    } else if (type == 'gateway_tunnel_signal') {
      final msg=_decodeMap(event['message']); if(msg!=null) await _handleGatewayTunnelSignal(msg);
    } else if (type == 'gateway_signal_forwarded') { _events.add(event); }
  }


  Future<void> _ensureTunnelForSession(String sessionId, GatewaySession session, bool localIsGateway) async {
    if (_tunnels.containsKey(sessionId)) return;
    final tunnel = GatewayTunnel(
      sessionId: sessionId,
      localId: store.deviceId ?? '',
      remoteId: localIsGateway ? session.destinationId : session.gatewayId,
      sendSignal: (signal) async {
        final msg={...signal,'type':'gateway_tunnel_signal','gateway_id':session.gatewayId,'gateway_session_id':session.sessionId};
        if(socket.isConnected) socket.send(msg); else if(session.gatewayId != store.deviceId) await relayPlatform.forwardSignalToMesh(destinationId:session.gatewayId,sessionId:session.sessionId,message:msg);
      },
      onPacket: (packet) async {
        final bytes=utf8.encode(packet).length;
        if(localIsGateway){
          if(!budget.canConsume(bytes)) return; budget.consume(bytes); bandwidth.recordReceived(sessionId,bytes);
          final ok=await relayPlatform.forwardToMesh(destinationId:session.callerId,sessionId:sessionId,packet:packet); if(!ok) healthMonitor.recordFailure(session.gatewayId); else healthMonitor.recordSuccess(session.gatewayId);
        } else {
          bandwidth.recordReceived(sessionId,bytes); await relayPlatform.deliverGatewayPacket(packet:packet);
        }
      },
    );
    _tunnels[sessionId]=tunnel;
    if(localIsGateway) await tunnel.startOfferer();
  }

  Future<void> _handleGatewayTunnelSignal(Map<String,dynamic> msg) async {
    final self=store.deviceId?.trim()??''; final sessionId=msg['gateway_session_id']?.toString()??''; final gatewayId=msg['gateway_id']?.toString()??''; final sender=msg['sender_id']?.toString()??''; final recipient=msg['recipient_id']?.toString()??'';
    if(sessionId.isEmpty || gatewayId.isEmpty || recipient!=self || (sender.isEmpty || sender==self)) return;
    GatewaySession? session=_sessions[sessionId];
    if(session==null){
      final destination=self; session=GatewaySession(sessionId:sessionId,gatewayId:gatewayId,callerId:msg['caller_id']?.toString()??gatewayId,destinationId:destination,nonce:'',createdAt:DateTime.now().toUtc(),expiresAt:DateTime.now().toUtc().add(const Duration(minutes:5)),gatewaySigningPublicKey:'',gatewaySignature:''); _sessions[sessionId]=session;
    }
    final localIsGateway=session.gatewayId==self;
    await _ensureTunnelForSession(sessionId,session,localIsGateway);
    await _tunnels[sessionId]!.handleSignal(msg);
  }

  Future<Map<String, dynamic>> _safeCapabilities() async {
    try { return await relayPlatform.deviceCapabilities(); } catch (_) { return const {}; }
  }

  Future<GatewayAdvertisement> _signAdvertisement(GatewayAdvertisement ad) async => GatewayAdvertisement(
        gatewayId: ad.gatewayId, nodeId: ad.nodeId, internetAvailable: ad.internetAvailable,
        lanAvailable: ad.lanAvailable, wifiDirectAvailable: ad.wifiDirectAvailable, meshAvailable: ad.meshAvailable,
        gatewayCapable: ad.gatewayCapable, gatewayAvailable: ad.gatewayAvailable, gatewayVersion: ad.gatewayVersion,
        maxGatewaySessions: ad.maxGatewaySessions, currentGatewaySessions: ad.currentGatewaySessions, availableSlots: ad.availableSlots,
        latencyMs: ad.latencyMs, upstreamKbps: ad.upstreamKbps, downstreamKbps: ad.downstreamKbps, availableUpstreamKbps: ad.availableUpstreamKbps, availableDownstreamKbps: ad.availableDownstreamKbps, reservedUpstreamKbps: ad.reservedUpstreamKbps, packetLossPercent: ad.packetLossPercent, healthScore: ad.healthScore, budgetLimitBytes: ad.budgetLimitBytes, budgetUsedBytes: ad.budgetUsedBytes, budgetRemainingBytes: ad.budgetRemainingBytes, budgetResetAt: ad.budgetResetAt, identityPublicKey: ad.identityPublicKey, signingPublicKey: ad.signingPublicKey,
        signature: await crypto.signPayload(ad.canonical()), advertisedAt: ad.advertisedAt, expiresAt: ad.expiresAt,
      );

  GatewayRoute? _routeFromSnapshot(String gatewayId, String destinationId, Map<String, dynamic> raw) {
    final reachable = raw['reachable'] == true;
    if (!reachable) return null;
    final expiresMs = int.tryParse(raw['expires_at']?.toString() ?? '') ?? DateTime.now().millisecondsSinceEpoch + 15_000;
    return GatewayRoute(
      gatewayId: gatewayId,
      destinationId: destinationId,
      reachable: true,
      nextHopId: raw['next_hop_id']?.toString(),
      hopCount: int.tryParse(raw['hop_count']?.toString() ?? '') ?? 0,
      latencyMs: int.tryParse(raw['latency_ms']?.toString() ?? ''),
      expiresAt: DateTime.fromMillisecondsSinceEpoch(expiresMs, isUtc: true),
      resolvedAt: DateTime.now().toUtc(),
    );
  }

  Future<GatewayRoute> _signRoute(GatewayRoute route) async {
    final key = await crypto.signingPublicKey();
    final canonical = jsonEncode({
      'gateway_id': route.gatewayId, 'destination_id': route.destinationId, 'reachable': route.reachable,
      'next_hop_id': route.nextHopId, 'hop_count': route.hopCount, 'latency_ms': route.latencyMs,
      'expires_at': route.expiresAt.toUtc().toIso8601String(), 'resolved_at': route.resolvedAt.toUtc().toIso8601String(),
      'reason': route.reason,
    });
    return GatewayRoute(gatewayId: route.gatewayId, destinationId: route.destinationId, reachable: route.reachable,
      nextHopId: route.nextHopId, hopCount: route.hopCount, latencyMs: route.latencyMs, expiresAt: route.expiresAt,
      resolvedAt: route.resolvedAt, reason: route.reason, signingPublicKey: key, signature: await crypto.signPayload(canonical));
  }

  Future<GatewaySession> _waitForAcceptedSession(GatewaySession provisional) async {
    final deadline = DateTime.now().add(const Duration(seconds: 5));
    while (DateTime.now().isBefore(deadline)) {
      final current = _sessions[provisional.sessionId];
      if (current != null && current.gatewaySignature.isNotEmpty) return current;
      await Future<void>.delayed(const Duration(milliseconds: 100));
    }
    _sessions.remove(provisional.sessionId);
    throw StateError('gateway authentication timeout');
  }

  Map<String, dynamic>? _decodeMap(Object? value) {
    if (value is Map) return Map<String, dynamic>.from(value);
    if (value is String && value.isNotEmpty) {
      try { return Map<String, dynamic>.from(jsonDecode(value) as Map); } catch (_) { return null; }
    }
    return null;
  }

  String _randomId(String prefix) {
    final random = Random.secure();
    final bytes = List<int>.generate(12, (_) => random.nextInt(256));
    return '$prefix-${base64UrlEncode(bytes).replaceAll('=', '')}';
  }

  Future<void> _closeTunnel(String sessionId) async { final tunnel=_tunnels.remove(sessionId); if(tunnel!=null){await tunnel.close();} }

  Future<void> dispose() async {
    _started = false;
    _advertisementTimer?.cancel();
    _expiryTimer?.cancel();
    await _socketSub?.cancel();
    await _nativeSub?.cancel();
    _advertisementTimer = null;
    _expiryTimer = null;
    _socketSub = null;
    _nativeSub = null;
    for (final c in _routeRequests.values) { if (!c.isCompleted) c.complete(null); }
    _routeRequests.clear();
    for (final tunnel in _tunnels.values) { await tunnel.close(); }
    _tunnels.clear();
    await trafficScheduler.dispose();
    await budget.dispose();
    _sessions.clear();
    await registry.dispose();
    await _events.close();
  }
}

final class RouteResolution {
  final GatewayRoute? route;
  final String? reason;
  const RouteResolution(this.route, [this.reason]);
  const RouteResolution.unavailable(String reason) : this(null, reason);
}

extension _GatewayFirstWhere on Iterable<GatewaySession> {
  GatewaySession? firstWhereOrNull(bool Function(GatewaySession) predicate) {
    for (final value in this) { if (predicate(value)) return value; }
    return null;
  }
}

final class CallSessionSignal {
  final String type;
  final String callId;
  final String senderId;
  final String recipientId;
  final String reason;
  final String transportMode;
  final String selectedMediaCodec;
  final List<String> supportedMediaCodecs;
  const CallSessionSignal({required this.type, required this.callId, required this.senderId, required this.recipientId, this.reason = '', this.transportMode = '', this.selectedMediaCodec = '', this.supportedMediaCodecs = const []});
  Map<String, dynamic> toJson() => {
    'type': type, 'call_id': callId, 'sender_id': senderId, 'recipient_id': recipientId,
    if (reason.isNotEmpty) 'reason': reason, if (transportMode.isNotEmpty) 'transport_mode': transportMode,
    if (selectedMediaCodec.isNotEmpty) 'selected_media_codec': selectedMediaCodec,
    if (supportedMediaCodecs.isNotEmpty) 'supported_media_codecs': supportedMediaCodecs,
  };
}
