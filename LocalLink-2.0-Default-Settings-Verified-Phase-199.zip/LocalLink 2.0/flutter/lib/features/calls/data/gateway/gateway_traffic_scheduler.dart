import 'dart:async';

enum GatewayTrafficClass { signaling, voice, video, message, bulk }
GatewayTrafficClass gatewayTrafficClassFor(Map<String,dynamic> packet) {
  final type = (packet['type']?.toString() ?? '').toLowerCase();
  if (type.contains('signal') || type.contains('call_invite') || type.contains('call_accept') || type.contains('call_end')) return GatewayTrafficClass.signaling;
  if (type.contains('call_media') || type.contains('audio')) return GatewayTrafficClass.voice;
  if (type.contains('video')) return GatewayTrafficClass.video;
  if (type.contains('message') || type.contains('chat')) return GatewayTrafficClass.message;
  return GatewayTrafficClass.bulk;
}

class GatewayTrafficScheduler {
  final int maxQueue;
  final List<_Job> _queue = [];
  bool _running = false;
  GatewayTrafficScheduler({this.maxQueue = 256});
  Future<void> start() async { _running = true; await _drain(); }
  Future<void> dispose() async { _running = false; _queue.clear(); }
  Future<T> schedule<T>(GatewayTrafficClass cls, Future<T> Function() action) {
    if (_queue.length >= maxQueue) return Future<T>.error(StateError('gateway traffic queue full'));
    final c = Completer<T>();
    _queue.add(_Job(cls, action, c));
    _queue.sort((a,b) => a.cls.index.compareTo(b.cls.index));
    unawaited(_drain());
    return c.future;
  }
  Future<void> _drain() async {
    if (!_running) return;
    if (_draining) return;
    _draining = true;
    try {
      while (_running && _queue.isNotEmpty) {
        final job = _queue.removeAt(0);
        try { job.complete(await job.action()); } catch (e, st) { job.completeError(e, st); }
      }
    } finally { _draining = false; }
  }
  bool _draining = false;
}
class _Job<T> {
  final GatewayTrafficClass cls; final Future<T> Function() action; final Completer<T> completer;
  _Job(this.cls,this.action,this.completer);
  void complete(T value)=>completer.complete(value); void completeError(Object e, StackTrace st)=>completer.completeError(e,st);
}
