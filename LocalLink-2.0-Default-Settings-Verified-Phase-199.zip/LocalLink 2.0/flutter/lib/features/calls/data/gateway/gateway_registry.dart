import 'dart:async';
import 'dart:convert';

import 'package:locallink/core/services/identity_crypto_service.dart';
import 'gateway_models.dart';

final class GatewayRegistry {
  final IdentityCryptoService crypto;
  final Map<String, GatewayAdvertisement> _advertisements = {};
  final Map<String, GatewayRoute> _routes = {};
  final Map<String, String> _signingKeys = {};
  final _changes = StreamController<void>.broadcast();

  GatewayRegistry({required this.crypto});

  Stream<void> get changes => _changes.stream;

  List<GatewayAdvertisement> get gateways => _advertisements.values.toList(growable: false);

  GatewayAdvertisement? operator [](String gatewayId) => _advertisements[gatewayId];

  GatewayRoute? routeFor(String gatewayId, String destinationId) {
    final route = _routes['$gatewayId|$destinationId'];
    if (route == null || !route.isValid) return null;
    return route;
  }

  String? signingKeyFor(String deviceId) => _signingKeys[deviceId];

  Future<bool> upsertAdvertisement(Map<String, dynamic> json) async {
    final advertisement = GatewayAdvertisement.fromJson(json);
    if (advertisement.gatewayId.isEmpty || advertisement.gatewayId != advertisement.nodeId) return false;
    if (advertisement.signingPublicKey.isEmpty || advertisement.signature.isEmpty) return false;
    if (DateTime.now().toUtc().isAfter(advertisement.expiresAt.add(const Duration(seconds: 5)))) return false;
    final valid = await crypto.verifyPayloadSignature(
      canonicalPayload: advertisement.canonical(),
      signature: advertisement.signature,
      signingPublicKey: advertisement.signingPublicKey,
    );
    if (!valid) return false;
    _advertisements[advertisement.gatewayId] = advertisement;
    _signingKeys[advertisement.nodeId] = advertisement.signingPublicKey;
    _changes.add(null);
    return true;
  }

  void rememberSigningKey(String deviceId, String publicKey) {
    final id = deviceId.trim();
    final key = publicKey.trim();
    if (id.isEmpty || key.isEmpty || key.length > 128) return;
    _signingKeys[id] = key;
  }

  Future<bool> upsertRoute(GatewayRoute route) async {
    if (route.gatewayId.isEmpty || route.destinationId.isEmpty || route.signingPublicKey.isEmpty || route.signature.isEmpty) return false;
    final knownKey = _signingKeys[route.gatewayId] ?? _advertisements[route.gatewayId]?.signingPublicKey;
    if (knownKey == null || knownKey.isEmpty || knownKey != route.signingPublicKey) return false;
    final valid = await crypto.verifyPayloadSignature(
      canonicalPayload: jsonEncode({
        'gateway_id': route.gatewayId,
        'destination_id': route.destinationId,
        'reachable': route.reachable,
        'next_hop_id': route.nextHopId,
        'hop_count': route.hopCount,
        'latency_ms': route.latencyMs,
        'expires_at': route.expiresAt.toUtc().toIso8601String(),
        'resolved_at': route.resolvedAt.toUtc().toIso8601String(),
        'reason': route.reason,
      }),
      signature: route.signature,
      signingPublicKey: route.signingPublicKey,
    );
    if (!valid) return false;
    _routes['${route.gatewayId}|${route.destinationId}'] = route;
    _changes.add(null);
    return true;
  }

  void removeExpired() {
    final now = DateTime.now();
    _routes.removeWhere((_, route) => now.isAfter(route.expiresAt));
    _advertisements.removeWhere((_, ad) => now.isAfter(ad.expiresAt));
  }

  List<GatewayRoute> validRoutesFor(String destinationId) => _routes.values
      .where((route) => route.destinationId == destinationId && route.isValid)
      .toList(growable: false);

  Future<void> dispose() async => _changes.close();
}
