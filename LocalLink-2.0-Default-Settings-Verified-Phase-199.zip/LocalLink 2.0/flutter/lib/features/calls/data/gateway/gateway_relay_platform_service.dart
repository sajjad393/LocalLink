import 'package:flutter/services.dart';

final class GatewayRelayPlatformService {
  static const MethodChannel _channel = MethodChannel('locallink/gateway_relay');

  Future<void> configureCallGateway({required String callId, required String gatewayId, required String sessionId, String role = 'internet_gateway_egress'}) =>
      _channel.invokeMethod('configure_call_gateway', {
        'call_id': callId,
        'gateway_id': gatewayId,
        'session_id': sessionId,
        'route_role': role,
      });

  Future<void> clearCallGateway({required String callId}) =>
      _channel.invokeMethod('clear_call_gateway', {'call_id': callId});

  Future<bool> forwardToMesh({required String destinationId, required String sessionId, required String packet}) async {
    return (await _channel.invokeMethod<bool>('forward_to_mesh', {
      'destination_id': destinationId,
      'session_id': sessionId,
      'packet': packet,
    })) == true;
  }

  Future<bool> forwardSignalToMesh({required String destinationId, required String sessionId, required Map<String, dynamic> message}) async {
    return (await _channel.invokeMethod<bool>('forward_signal_to_mesh', {
      'destination_id': destinationId,
      'session_id': sessionId,
      'message': message,
    })) == true;
  }

  Future<bool> deliverGatewayPacket({required String packet}) async {
    return (await _channel.invokeMethod<bool>('deliver_gateway_packet', {'packet': packet})) == true;
  }

  Future<Map<String, dynamic>> routeSnapshot({required String destinationId}) async {
    final raw = await _channel.invokeMethod<Map<dynamic, dynamic>>('gateway_route_snapshot', {
      'destination_id': destinationId,
    }) ?? const {};
    return Map<String, dynamic>.from(raw);
  }

  Future<Map<String, dynamic>> deviceCapabilities() async {
    final raw = await _channel.invokeMethod<Map<dynamic, dynamic>>('gateway_device_capabilities') ?? const {};
    return Map<String, dynamic>.from(raw);
  }
}
