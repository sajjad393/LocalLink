import 'gateway_models.dart';
class GatewayRouteSelector {
  List<GatewayAdvertisement> rankAdvertisements(Iterable<GatewayAdvertisement> ads) {
    final list = ads.where((a) => a.gatewayCapable && a.gatewayAvailable && a.internetAvailable && a.meshAvailable && a.availableSlots > 0 && (a.availableUpstreamKbps > 0 || a.upstreamKbps > 0) && a.budgetRemainingBytes > 0).toList();
    list.sort((a,b) => _score(b).compareTo(_score(a)));
    return list;
  }
  double score({required GatewayAdvertisement gateway, required GatewayRoute route, required double healthScore}) {
    final latency = gateway.latencyMs ?? route.latencyMs ?? 1000;
    final load = gateway.maxGatewaySessions <= 0 ? 1.0 : gateway.currentGatewaySessions / gateway.maxGatewaySessions;
    final loss = (gateway.packetLossPercent / 100).clamp(0.0, 1.0).toDouble();
    final availableKbps = gateway.availableUpstreamKbps > 0 ? gateway.availableUpstreamKbps : gateway.upstreamKbps;
    final bandwidth = (availableKbps.clamp(0, 100000) / 10000).clamp(0.0, 1.0).toDouble();
    final budget = gateway.budgetLimitBytes <= 0 ? 1.0 : (gateway.budgetRemainingBytes / gateway.budgetLimitBytes).clamp(0.0, 1.0).toDouble();
    final lat = 1.0 - (latency / 1000).clamp(0.0, 1.0).toDouble();
    final hops = 1.0 - (route.hopCount / 8).clamp(0.0, 1.0).toDouble();
    return healthScore * .35 + bandwidth * .20 + budget * .15 + (1-loss) * .10 + (1-load) * .10 + lat * .07 + hops * .03;
  }
  double _score(GatewayAdvertisement g) {
    final health=(g.healthScore.clamp(0,100)/100).toDouble(); final available=(g.availableUpstreamKbps > 0 ? g.availableUpstreamKbps : g.upstreamKbps); final bw=(available/10000).clamp(0,1).toDouble(); final budget=g.budgetLimitBytes<=0?1.0:(g.budgetRemainingBytes/g.budgetLimitBytes).clamp(0,1).toDouble();
    final loss=1-(g.packetLossPercent/100).clamp(0,1).toDouble(); final load=1-(g.currentGatewaySessions/(g.maxGatewaySessions<=0?1:g.maxGatewaySessions)).clamp(0,1).toDouble(); final lat=1-((g.latencyMs??1000)/1000).clamp(0,1).toDouble();
    return health*.35+bw*.20+budget*.15+loss*.10+load*.10+lat*.07+.03;
  }
}
