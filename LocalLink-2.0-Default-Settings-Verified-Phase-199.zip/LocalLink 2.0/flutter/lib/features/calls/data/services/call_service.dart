/// Backwards-compatible name retained for callers that still import the old
/// service path. The actual implementation is the unified CallSessionManager.
export 'call_session_manager.dart';
typedef CallService = CallSessionManager;
