import 'dart:async';
import 'dart:math';
import 'dart:convert';

import 'package:flutter/foundation.dart';

import 'package:locallink/core/models/call.dart';
import 'package:locallink/core/models/call_quality.dart';
import 'package:locallink/core/models/device.dart';
import 'package:locallink/core/services/local_store.dart';
import 'package:locallink/core/services/locallink_api.dart';
import 'package:locallink/core/services/websocket_service.dart';
import 'package:locallink/core/services/identity_crypto_service.dart';
import 'package:locallink/features/calls/data/models/call_session.dart';
import 'package:locallink/features/calls/data/models/call_notification_action.dart';
import 'package:locallink/features/calls/data/platform/call_audio_platform_service.dart';
import 'package:locallink/features/calls/data/platform/call_media_platform_service.dart';
import 'package:locallink/features/calls/data/gateway/internet_gateway_service.dart';
import 'package:locallink/features/calls/data/services/call_notification_platform_service.dart';
import 'package:locallink/features/calls/data/services/call_ringtone_service.dart';
import 'package:locallink/features/calls/data/repositories/call_repository.dart';
import 'package:locallink/features/calls/data/transport/call_transport.dart';
import 'package:locallink/features/calls/data/transport/call_transport_factory.dart';
import 'package:locallink/features/calls/data/transport/call_transport_mode.dart';
import 'package:locallink/features/calls/data/transport/call_transport_selection_policy.dart';
import 'package:locallink/features/calls/data/transport/network_preference.dart';
import 'package:locallink/features/calls/domain/call_gateway.dart';
import 'package:locallink/features/connectivity/domain/peer_transport_contract.dart';

final class CallSessionManager implements CallGateway {
  final LocalStore store;
  final LocalLinkApi api;
  final WebSocketService socket;
  final PeerTransportContract directTransport;
  final CallRepositoryContract repository;
  final CallAudioPlatformService audioPlatform;
  final CallRingtoneService ringtone;
  final CallNotificationPlatformService notificationPlatform;
  final CallMediaPlatformService mediaPlatform;
  final IdentityCryptoService crypto;
  final InternetGatewayService gatewayService;

  final _sessionController = StreamController<CallSession?>.broadcast();
  final _historyController = StreamController<List<CallRecord>>.broadcast();
  StreamSubscription<Map<String, dynamic>>? _socketSub;
  StreamSubscription<bool>? _socketStateSub;
  StreamSubscription<Map<String, dynamic>>? _nativeSub;
  StreamSubscription<Map<String, dynamic>>? _gatewaySub;
  StreamSubscription<CallNotificationAction>? _notificationActionSub;
  Timer? _ringTimer;
  Timer? _statsTimer;
  Timer? _heartbeatTimer;
  Timer? _meshRouteRecoveryTimer;
  Timer? _transportSwitchTimer;
  CallSession? _session;
  CallTransport? _transport;
  late final CallTransportFactory transportFactory;
  bool _disposed = false;
  int _recoveryAttempts = 0;
  int _meshRouteRecoveryAttempts = 0;
  int _presentationRevision = 0;
  bool _appInForeground = true;
  bool _switchingTransport = false;
  bool _gatewayFailoverInProgress = false;
  CallTransportMode _preferredMode = CallTransportMode.auto;

  Stream<CallSession?> get sessionStream => _sessionController.stream;
  Stream<List<CallRecord>> get historyStream => _historyController.stream;
  CallSession? get session => _session;
  String? get selfDeviceId => store.deviceId;
  CallTransportMode get preferredMode => _preferredMode;
  set preferredMode(CallTransportMode value) => _preferredMode = value;
  CallTransport? get activeTransport => _transport;

  CallSessionManager(
    this.store,
    this.api,
    this.socket,
    this.directTransport, {
    required this.repository,
    required this.audioPlatform,
    required this.ringtone,
    required this.notificationPlatform,
    required this.mediaPlatform,
    required this.crypto,
    required this.gatewayService,
  }) {
    transportFactory = CallTransportFactory(
      mesh: directTransport,
      media: mediaPlatform,
      crypto: crypto,
      audio: audioPlatform,
      sendSignal: _sendSignal,
      onState: _onTransportState,
      gatewayService: gatewayService,
      gatewayRelayPlatform: gatewayService.relayPlatform,
    );
  }

  void start() {
    if (_disposed) return;
    _notificationActionSub ??= notificationPlatform.actions.listen((action) => unawaited(_handleNotificationAction(action)));
    _socketSub ??= socket.messages.listen(_handleSignal);
    _socketStateSub ??= socket.connectionState.listen(_handleSocketState);
    _nativeSub ??= transportFactory.nativeMesh.events.listen(_handleNativeTransportEvent);
    _gatewaySub ??= gatewayService.events.listen(_handleGatewayEvent);
    unawaited(_synchronizeIncomingPresentation());
    unawaited(syncHistory());
  }

  void onAppLifecycleState(AppLifecycleState state) {
    if (_disposed) return;
    _appInForeground = state == AppLifecycleState.resumed;
    final session = _session;
    if (session != null && session.direction == CallDirection.incoming && session.state == CallState.ringing) {
      if (_appInForeground) {
        unawaited(notificationPlatform.cancelIncoming());
      } else {
        unawaited(notificationPlatform.showIncoming(callId: session.id, callerId: session.peerId, callerName: session.peerName));
      }
    }
    if (state == AppLifecycleState.resumed) {
      if (_session?.transportMode == CallTransportMode.webRtc) unawaited(_ensureSocket().catchError((_) {}));
      if (_session != null && !_session!.isFinished) {
        _sendHeartbeat();
        _startStatsTimer();
      }
    }
  }

  Future<void> syncHistory() async {
    final local = await repository.syncHistory();
    if (!_historyController.isClosed) _historyController.add(local);
  }

  Future<void> startCall(Device device) async {
    if (await store.isBlockedPeer(device.id)) throw Exception('This user is blocked');
    if (_session != null && !_session!.isFinished) throw Exception('Another call is already active');
    if (store.deviceId == null || store.deviceToken == null) throw Exception('LocalLink is not configured');

    final id = _newCallId();
    final now = DateTime.now();
    final localRouteAvailable = await _hasLocalRouteTo(device.id);
    var directInternetAvailable = socket.isConnected && device.serverConnected && device.internetAvailable;
    final shouldEvaluateInternet = _preferredMode == CallTransportMode.webRtc ||
        store.networkPreference == NetworkPreference.internetPreferred ||
        store.networkPreference == NetworkPreference.internetOnly ||
        _preferredMode == CallTransportMode.auto;
    if (!directInternetAvailable && shouldEvaluateInternet) {
      try { await _ensureSocket(); } catch (_) {}
      directInternetAvailable = socket.isConnected && device.serverConnected && device.internetAvailable;
    }

    GatewayRoute? gatewayRoute;
    GatewaySession? gatewaySession;
    var gatewayAvailable = false;
    if (!localRouteAvailable && store.allowThisDeviceAsInternetGateway && store.networkPreference != NetworkPreference.internetOnly && !directInternetAvailable &&
        (_preferredMode == CallTransportMode.auto || _preferredMode == CallTransportMode.internetGateway)) {
      gatewayRoute = await gatewayService.resolveRoute(device.id);
      if (gatewayRoute != null && gatewayRoute!.isValid) {
        final ad = gatewayService.registry[gatewayRoute!.gatewayId];
        gatewayAvailable = ad != null && ad.state == GatewayNodeState.available && gatewayRoute!.isValid;
        if (gatewayAvailable) {
          gatewaySession = await gatewayService.createSession(destinationId: device.id, route: gatewayRoute!);
        }
      }
    }

    final mode = CallTransportSelectionPolicy.select(
      preferredMode: _preferredMode,
      networkPreference: store.networkPreference,
      localRouteAvailable: localRouteAvailable,
      directInternetAvailable: directInternetAvailable,
      gatewayRouteAvailable: gatewayAvailable,
      gatewayAuthorized: gatewaySession != null,
      gatewayCapacityAvailable: gatewayAvailable,
      internetGatewayEnabled: store.allowThisDeviceAsInternetGateway,
    );
    if (mode == CallTransportMode.webRtc) await _ensureSocket();
    final session = CallSession(
      id: id,
      peerId: device.id,
      peerName: device.name,
      direction: CallDirection.outgoing,
      state: CallState.ringing,
      startedAt: now,
      speakerOn: true,
      directMode: mode == CallTransportMode.offlineMesh,
      transportMode: mode,
      supportedMediaCodecs: await _supportedMediaCodecs(),
      gatewayId: gatewaySession?.gatewayId,
      gatewaySessionId: gatewaySession?.sessionId,
      gatewayHopCount: gatewayRoute?.hopCount,
      gatewayLatencyMs: gatewayRoute?.latencyMs,
    );
    _setSession(session);
    await _persistSession();
    _startRingTimer(outgoing: true);
    _startHeartbeatTimer();
    await _sendSignal({
      'type': 'call_invite',
      'call_id': id,
      'recipient_id': device.id,
      'sender_id': store.deviceId,
      'created_at': now.toUtc().toIso8601String(),
      'transport_mode': mode.wireName,
      'mesh_call': mode == CallTransportMode.offlineMesh,
      'direct': mode == CallTransportMode.offlineMesh,
      'supported_media_codecs': session.supportedMediaCodecs,
      if (gatewaySession != null) 'gateway_id': gatewaySession.gatewayId,
      if (gatewaySession != null) 'gateway_session_id': gatewaySession.sessionId,
      if (gatewaySession != null) 'gateway_expires_at': gatewaySession.expiresAt.toUtc().toIso8601String(),
      if (gatewaySession != null) 'gateway_signing_public_key': gatewaySession.gatewaySigningPublicKey,
      if (gatewayRoute != null) 'gateway_hop_count': gatewayRoute.hopCount,
      if (gatewayRoute?.latencyMs != null) 'gateway_latency_ms': gatewayRoute!.latencyMs,
    });
  }

  Future<void> acceptIncoming() async {
    final session = _session;
    if (session == null || session.direction != CallDirection.incoming || session.state != CallState.ringing) return;
    if (await store.isBlockedPeer(session.peerId)) {
      await rejectIncoming(reason: 'blocked');
      return;
    }
    if (session.transportMode == CallTransportMode.webRtc) await _ensureSocket();
    try {
      _cancelCallTimers();
      final selectedCodec = await _negotiateCodec(session.supportedMediaCodecs);
      _setSession(session.copyWith(state: CallState.connecting, mediaCodec: selectedCodec));
      await _persistSession();
      _transport = transportFactory.resolve(requested: session.transportMode, session: _session!);
      await _sendSignal({
        'type': 'call_accept',
        'call_id': session.id,
        'recipient_id': session.peerId,
        'selected_media_codec': selectedCodec,
      });
      await _transport!.start(_session!);
      // For native mesh the call is fully established by call_accept; WebRTC
      // waits for the offer from the caller.
      if (session.transportMode == CallTransportMode.offlineMesh || session.transportMode == CallTransportMode.internetGateway) {
        await _markConnected();
      }
    } catch (e) {
      await _fail('microphone_unavailable');
      rethrow;
    }
  }

  Future<void> rejectIncoming({String reason = 'rejected'}) async {
    final session = _session;
    if (session == null || session.direction != CallDirection.incoming || session.isFinished) return;
    _cancelCallTimers();
    await _sendSignal({'type': 'call_reject', 'call_id': session.id, 'recipient_id': session.peerId, 'reason': reason});
    await _finishLocal(CallState.rejected, reason, notifyServer: false);
  }

  Future<void> endCall({String reason = 'hangup'}) async {
    final session = _session;
    if (session == null || session.isFinished) return;
    _cancelCallTimers();
    _meshRouteRecoveryTimer?.cancel();
    _transportSwitchTimer?.cancel();
    _setSession(session.copyWith(state: CallState.ending, reason: reason));
    await _sendSignal({'type': 'call_end', 'call_id': session.id, 'recipient_id': session.peerId, 'reason': reason});
    await _finishLocal(CallState.ended, reason, notifyServer: false);
  }

  Future<void> switchTransport(CallTransportMode target) async {
    final original = _session;
    if (original == null || original.isFinished || _transport == null || _switchingTransport) return;
    if (target == CallTransportMode.offlineMesh && (store.networkPreference == NetworkPreference.internetOnly || !await _hasLocalRouteTo(original.peerId))) {
      throw StateError(store.networkPreference == NetworkPreference.internetOnly ? 'Internet-only calling is enabled' : 'offline mesh transport is unavailable for this peer');
    }
    if (target == CallTransportMode.webRtc) await _ensureSocket();
    if (target == CallTransportMode.internetGateway && !store.allowThisDeviceAsInternetGateway) throw StateError('Internet gateway calling is disabled');

    CallSession nextTargetSession = original;
    if (target == CallTransportMode.internetGateway) {
      final currentGateway = original.gatewayId;
      final route = await gatewayService.resolveRoute(original.peerId, excludedGatewayIds: currentGateway == null ? const {} : {currentGateway});
      if (route == null || !route.isValid) throw StateError('no alternate Internet gateway can reach this peer');
      final gatewaySession = await gatewayService.createSession(destinationId: original.peerId, route: route);
      nextTargetSession = original.copyWith(
        gatewayId: gatewaySession.gatewayId,
        gatewaySessionId: gatewaySession.sessionId,
        gatewayHopCount: route.hopCount,
        gatewayLatencyMs: route.latencyMs,
      );
    }
    final gatewayChanged = target == CallTransportMode.internetGateway &&
        (original.gatewayId != nextTargetSession.gatewayId || original.gatewaySessionId != nextTargetSession.gatewaySessionId);
    if (target == original.transportMode && !gatewayChanged) return;

    _switchingTransport = true;
    _transportSwitchTimer?.cancel();
    _transportSwitchTimer = Timer(const Duration(seconds: 12), () {
      _switchingTransport = false;
      final current = _session;
      if (current != null && !current.isFinished && current.state == CallState.reconnecting) {
        _setSession(current.copyWith(state: CallState.connected, quality: CallQuality.good));
      }
    });
    _setSession(nextTargetSession.copyWith(state: CallState.reconnecting, quality: CallQuality.reconnecting, transportMode: target, directMode: target == CallTransportMode.offlineMesh));
    await _persistSession();
    await _sendSignal({
      'type': 'call_transport_switch_request',
      'call_id': original.id,
      'recipient_id': original.peerId,
      'transport_mode': target.wireName,
      'supported_media_codecs': original.supportedMediaCodecs,
      if (target == CallTransportMode.internetGateway) ...{
        'gateway_id': nextTargetSession.gatewayId,
        'gateway_session_id': nextTargetSession.gatewaySessionId,
        'gateway_hop_count': nextTargetSession.gatewayHopCount,
        'gateway_latency_ms': nextTargetSession.gatewayLatencyMs,
      },
    });
  }

  Future<void> toggleMute() async {
    final session = _session;
    final transport = _transport;
    if (session == null || transport == null) return;
    final muted = !session.muted;
    await transport.setMuted(session, muted);
    _setSession(session.copyWith(muted: muted));
  }

  Future<void> toggleVideo() async {
    final session = _session;
    final transport = _transport;
    if (session == null || transport == null || !transport.supportsVideo) return;
    final enabled = !session.videoEnabled;
    if (enabled && session.localVideoTextureId == null) {
      final video = await transport.startVideo(session);
      _setSession(session.copyWith(
        videoEnabled: true,
        localVideoTextureId: (video['local_texture_id'] as num?)?.toInt(),
        remoteVideoTextureId: (video['remote_texture_id'] as num?)?.toInt(),
      ));
      return;
    }
    await transport.setVideoEnabled(session, enabled);
    _setSession(session.copyWith(videoEnabled: enabled));
  }

  Future<void> switchCamera() async {
    final session = _session;
    final transport = _transport;
    if (session == null || transport == null || !transport.supportsVideo || !session.videoEnabled) return;
    await transport.switchCamera(session);
  }

  Future<void> toggleSpeaker() async {
    final session = _session;
    if (session == null) return;
    final next = !session.speakerOn;
    try {
      await audioPlatform.setSpeakerphoneOn(next);
      _setSession(session.copyWith(speakerOn: next));
    } catch (_) {}
  }

  Future<List<CallRecord>> history() => repository.history();

  Future<void> dispose() async {
    if (_disposed) return;
    _disposed = true;
    _cancelCallTimers();
    await _socketSub?.cancel();
    await _socketStateSub?.cancel();
    await _nativeSub?.cancel();
    await _gatewaySub?.cancel();
    await _notificationActionSub?.cancel();
    _socketSub = null;
    _socketStateSub = null;
    _nativeSub = null;
    _gatewaySub = null;
    _notificationActionSub = null;
    _presentationRevision++;
    await ringtone.stop();
    await notificationPlatform.cancelIncoming();
    if (_transport != null && _session != null) {
      try { await _transport!.stop(_session!); } catch (_) {}
    }
    _transport = null;
    await transportFactory.dispose();
    await _historyController.close();
    await _sessionController.close();
  }

  Future<bool> _hasLocalRouteTo(String peerId) async {
    if (!directTransport.isStarted) return false;
    try {
      final topology = await directTransport.topology();
      final now = DateTime.now().millisecondsSinceEpoch;

      final peersRaw = topology['peers'] ?? topology['mesh_peers'];
      if (peersRaw is List) {
        for (final raw in peersRaw.whereType<Map>()) {
          final peer = Map<String, dynamic>.from(raw);
          final id = (peer['node_id'] ?? peer['peer_id'])?.toString().trim();
          final state = peer['state']?.toString().trim().toUpperCase();
          if (id == peerId && (state == null || state.isEmpty || state == 'CONNECTED' || state == 'DISCOVERED')) {
            return true;
          }
        }
      }

      final routesRaw = topology['routes'];
      if (routesRaw is List) {
        for (final raw in routesRaw.whereType<Map>()) {
          final route = Map<String, dynamic>.from(raw);
          final destination = (route['destination'] ?? route['destination_node_id'] ?? route['destination_id'])?.toString().trim();
          final state = route['state']?.toString().trim().toUpperCase();
          final expiresAt = (route['expires_at'] as num?)?.toInt();
          final active = state == null || state.isEmpty || state == 'ACTIVE';
          final notExpired = expiresAt == null || expiresAt > now;
          if (destination == peerId && active && notExpired) return true;
        }
      }
    } catch (_) {
      // A topology read failure is treated as no local route so AUTO can
      // safely fall back to Internet/WebRTC when available.
    }
    return false;
  }

  Future<void> _ensureSocket() async {
    if (socket.isConnected) return;
    await socket.connect(api.wsUrl, headers: api.wsHeaders);
    if (!socket.isConnected) throw Exception('LocalLink server connection is unavailable');
  }

  void _handleSignal(Map<String, dynamic> msg) {
    if (_disposed) return;
    switch (msg['type']?.toString()) {
      case 'call_invite': unawaited(_handleInvite(msg)); return;
      case 'call_invite_ack': _handleInviteAck(msg); return;
      case 'call_accept': unawaited(_handleAccept(msg)); return;
      case 'call_reject': unawaited(_handleReject(msg)); return;
      case 'call_busy': unawaited(_handleReject({...msg, 'reason': msg['reason']?.toString().isNotEmpty == true ? msg['reason'] : 'busy'})); return;
      case 'call_end': unawaited(_handleEnd(msg)); return;
      case 'call_state': unawaited(_handleState(msg)); return;
      case 'call_transport_switch_request': unawaited(_handleTransportSwitchRequest(msg)); return;
      case 'call_transport_switch_accept': unawaited(_handleTransportSwitchAccept(msg)); return;
      case 'call_transport_switch_reject': unawaited(_handleTransportSwitchReject(msg)); return;
      case 'call_offer': case 'call_answer': case 'call_candidate': case 'call_recover':
        unawaited(_handleWebRtcSignal(msg)); return;
      case 'call_heartbeat_ack': _handleHeartbeatAck(msg); return;
      case 'error':
        final id = msg['call_id']?.toString();
        if (id != null && id.isNotEmpty && _session?.id == id) unawaited(_fail(msg['error']?.toString() ?? 'call_error'));
        return;
    }
  }

  Future<void> _handleInvite(Map<String, dynamic> msg) async {
    final callId = msg['call_id']?.toString().trim() ?? '';
    final peerId = msg['sender_id']?.toString().trim() ?? '';
    final recipientId = msg['recipient_id']?.toString().trim() ?? '';
    final selfId = store.deviceId?.trim() ?? '';
    if (callId.isEmpty || peerId.isEmpty || selfId.isEmpty || recipientId != selfId || peerId == selfId) return;
    final createdAt = DateTime.tryParse(msg['created_at']?.toString() ?? '')?.toLocal();
    if (createdAt == null) return;
    final age = DateTime.now().difference(createdAt);
    if (age > const Duration(minutes: 2) || age < const Duration(seconds: -30)) {
      unawaited(_sendSignal({'type': 'call_reject', 'call_id': callId, 'recipient_id': peerId, 'reason': 'stale_invite'}));
      return;
    }
    if (await store.isBlockedPeer(peerId)) {
      unawaited(_sendSignal({'type': 'call_reject', 'call_id': callId, 'recipient_id': peerId, 'reason': 'blocked'}));
      return;
    }
    final existing = _session;
    if (existing != null && !existing.isFinished) {
      if (existing.id == callId && existing.peerId == peerId && existing.direction == CallDirection.incoming && existing.state == CallState.ringing) return;
      unawaited(_sendSignal({'type': 'call_busy', 'call_id': callId, 'recipient_id': peerId, 'reason': 'busy', 'transport_mode': msg['transport_mode']}));
      return;
    }
    final name = await repository.loadDeviceNames().then((names) => names[peerId] ?? peerId);
    final advertised = (msg['supported_media_codecs'] is List)
        ? (msg['supported_media_codecs'] as List).map((e) => e.toString().trim().toLowerCase()).where((e) => e.isNotEmpty).toSet().toList()
        : const <String>['pcm_s16le'];
    final modeName = msg['transport_mode']?.toString().trim().toLowerCase();
    final hasGateway = modeName == CallTransportMode.internetGateway.wireName &&
        (msg['gateway_id']?.toString().trim().isNotEmpty ?? false) &&
        (msg['gateway_session_id']?.toString().trim().isNotEmpty ?? false);
    final mode = hasGateway
        ? CallTransportMode.internetGateway
        : (msg['direct'] == true || msg['mesh_call'] == true || modeName == CallTransportMode.offlineMesh.wireName)
            ? CallTransportMode.offlineMesh
            : CallTransportMode.webRtc;
    final gatewayId = msg['gateway_id']?.toString().trim();
    final gatewaySessionId = msg['gateway_session_id']?.toString().trim();
    if (mode == CallTransportMode.offlineMesh && store.networkPreference == NetworkPreference.internetOnly) {
      unawaited(_sendSignal({'type': 'call_reject', 'call_id': callId, 'recipient_id': peerId, 'reason': 'internet_only'}));
      return;
    }
    _setSession(CallSession(
      id: callId,
      peerId: peerId,
      peerName: name,
      direction: CallDirection.incoming,
      state: CallState.ringing,
      startedAt: createdAt,
      speakerOn: true,
      directMode: mode == CallTransportMode.offlineMesh,
      transportMode: mode,
      supportedMediaCodecs: advertised,
      gatewayId: gatewayId?.isNotEmpty == true ? gatewayId : null,
      gatewaySessionId: gatewaySessionId?.isNotEmpty == true ? gatewaySessionId : null,
      gatewayHopCount: int.tryParse(msg['gateway_hop_count']?.toString() ?? ''),
      gatewayLatencyMs: int.tryParse(msg['gateway_latency_ms']?.toString() ?? ''),
    ));
    await _persistSession();
    _startRingTimer(outgoing: false);
  }

  Future<void> _handleGatewayEvent(Map<String, dynamic> event) async {
    if (_disposed) return;
    final type = event['type']?.toString() ?? '';
    if (type == 'gateway_call_signal') {
      final signal = event['signal'] is Map
          ? Map<String, dynamic>.from(event['signal'] as Map)
          : null;
      if (signal == null || signal['type']?.toString().isEmpty != false) return;
      if (event['gateway_id'] != null) signal['gateway_id'] = event['gateway_id'];
      if (event['gateway_session_id'] != null) signal['gateway_session_id'] = event['gateway_session_id'];
      unawaited(_handleSignal(signal));
      return;
    }
    if (type == 'gateway_session_closed' || type == 'gateway_error') {
      final session = _session;
      if (session == null || session.isFinished || session.transportMode != CallTransportMode.internetGateway) return;
      final sameCall = event['call_id']?.toString() == session.id;
      final sameGatewaySession = event['gateway_session_id']?.toString() == session.gatewaySessionId;
      if (!sameCall && !sameGatewaySession) return;
      _setSession(session.copyWith(state: CallState.reconnecting, quality: CallQuality.reconnecting));
      unawaited(_persistSession());
      if (!_gatewayFailoverInProgress) unawaited(_attemptGatewayFailover());
      return;
    }
  }

  Future<void> _handleNotificationAction(CallNotificationAction action) async {
    final session = _session;
    if (session == null || session.isFinished || session.direction != CallDirection.incoming || session.state != CallState.ringing || session.id != action.callId || session.peerId != action.callerId) return;
    if (await store.isBlockedPeer(session.peerId)) { await rejectIncoming(reason: 'blocked'); return; }
    try {
      switch (action.type) {
        case CallNotificationActionType.accept: await acceptIncoming();
        case CallNotificationActionType.reject: await rejectIncoming();
      }
    } catch (_) {}
  }

  bool _signalTargetsThisSession(Map<String, dynamic> msg, CallSession session, {bool requireRemoteSender = false}) {
    final selfId = store.deviceId;
    if (selfId == null || selfId.isEmpty) return false;
    if (msg['call_id']?.toString() != session.id) return false;
    final sender = msg['sender_id']?.toString().trim() ?? '';
    final recipient = msg['recipient_id']?.toString().trim() ?? '';
    if (sender.isEmpty || recipient.isEmpty) return false;
    if (requireRemoteSender) return sender == session.peerId && recipient == selfId;
    return (sender == selfId && recipient == session.peerId) || (sender == session.peerId && recipient == selfId);
  }

  Future<void> _handleAccept(Map<String, dynamic> msg) async {
    final session = _session;
    if (session == null || session.direction != CallDirection.outgoing || !_signalTargetsThisSession(msg, session, requireRemoteSender: true)) return;
    try {
      _ringTimer?.cancel();
      final selectedCodec = msg['selected_media_codec']?.toString().trim().toLowerCase();
      if (_transport == null) {
        final current = (selectedCodec == 'opus' || selectedCodec == 'pcm_s16le') ? session.copyWith(mediaCodec: selectedCodec) : session;
        _setSession(current);
        _transport = transportFactory.resolve(requested: current.transportMode, session: current);
        await _transport!.start(current);
      }
      if (session.transportMode == CallTransportMode.webRtc) {
        _setSession(session.copyWith(state: CallState.connecting));
        await _persistSession();
        await _transport!.sendOffer(_session!);
      } else {
        await _markConnected();
      }
    } catch (_) {
      await _fail('media_setup_failed');
    }
  }

  Future<void> _handleReject(Map<String, dynamic> msg) async {
    final session = _session;
    if (session == null || !_signalTargetsThisSession(msg, session, requireRemoteSender: true)) return;
    await _finishLocal(CallState.rejected, msg['reason']?.toString().isNotEmpty == true ? msg['reason'].toString() : 'rejected', notifyServer: false);
  }

  Future<void> _handleEnd(Map<String, dynamic> msg) async {
    final session = _session;
    if (session == null || !_signalTargetsThisSession(msg, session, requireRemoteSender: true)) return;
    final reason = msg['reason']?.toString();
    await _finishLocal(CallState.ended, reason?.isNotEmpty == true ? reason! : 'ended', notifyServer: false);
  }

  Future<void> _handleNativeTransportEvent(Map<String, dynamic> event) async {
    final type = event['type']?.toString() ?? '';
    final session = _session;
    if (session != null && !session.isFinished && session.transportMode == CallTransportMode.offlineMesh) {
      final destination = event['destination_id']?.toString() ?? event['mesh_destination_id']?.toString() ?? '';
      final callId = event['call_id']?.toString();
      final eventTargets = destination == session.peerId && (callId == null || callId.isEmpty || callId == session.id);
      if (eventTargets && (type == 'route_invalidated' || type == 'route_removed' || type == 'call_media_route_degraded')) {
        _meshRouteRecoveryAttempts++;
        _meshRouteRecoveryTimer?.cancel();
        _setSession(session.copyWith(
          state: CallState.reconnecting,
          quality: CallQuality.reconnecting,
          recoveryAttempts: _meshRouteRecoveryAttempts,
          mediaNextHopId: event['next_hop_id']?.toString(),
          mediaHopCount: (event['hop_count'] as num?)?.toInt(),
        ));
        _meshRouteRecoveryTimer = Timer(const Duration(seconds: 10), () {
          final current = _session;
          if (current == null || current.isFinished || current.id != session.id || current.transportMode != CallTransportMode.offlineMesh) return;
          _setSession(current.copyWith(quality: CallQuality.reconnecting));
        });
      } else if (eventTargets && type == 'route_recovered') {
        _meshRouteRecoveryTimer?.cancel();
        _meshRouteRecoveryAttempts = 0;
        _setSession(session.copyWith(state: CallState.connected, quality: CallQuality.good, recoveryAttempts: 0, mediaNextHopId: event['next_hop_id']?.toString(), mediaHopCount: (event['hop_count'] as num?)?.toInt()));
        unawaited(_persistSession());
      } else if (eventTargets && type == 'call_media_route_changed') {
        _setSession(session.copyWith(
          mediaNextHopId: event['next_hop_id']?.toString(),
          mediaHopCount: (event['hop_count'] as num?)?.toInt(),
          quality: session.state == CallState.reconnecting ? CallQuality.good : session.quality,
          state: session.state == CallState.reconnecting ? CallState.connected : session.state,
        ));
      }
    }
    if (type != 'message') return;
    final raw = event['payload']?.toString();
    if (raw == null || raw.isEmpty) return;
    try {
      final msg = jsonDecode(raw);
      if (msg is Map<String, dynamic> && (msg['type']?.toString().startsWith('call_') ?? false)) {
        final withDefaults = Map<String, dynamic>.from(msg);
        withDefaults['direct'] = true;
        withDefaults['mesh_call'] = true;
        withDefaults['sender_id'] ??= event['sender_id'];
        unawaited(_handleSignal(withDefaults));
      }
    } catch (_) {}
  }

  Future<void> _handleWebRtcSignal(Map<String, dynamic> msg) async {
    final session = _session;
    final transport = _transport;
    if (session == null || transport == null || session.transportMode != CallTransportMode.webRtc) return;
    if (!_signalTargetsThisSession(msg, session, requireRemoteSender: true)) return;
    try {
      await transport.handleSignal(session, msg);
    } catch (_) {
      await _fail('webrtc_signaling_failed');
    }
  }

  Future<void> _handleTransportSwitchRequest(Map<String, dynamic> msg) async {
    final session = _session;
    if (session == null || session.isFinished || !_signalTargetsThisSession(msg, session, requireRemoteSender: true)) return;
    final modeName = msg['transport_mode']?.toString().trim().toLowerCase();
    final target = switch (modeName) {
      'offline_mesh' => CallTransportMode.offlineMesh,
      'webrtc' => CallTransportMode.webRtc,
      'internet_gateway' => CallTransportMode.internetGateway,
      _ => null,
    };
    if (target == null) return;
    final requestedGatewayId = msg['gateway_id']?.toString().trim();
    final requestedGatewaySessionId = msg['gateway_session_id']?.toString().trim();
    final gatewayChanged = target == CallTransportMode.internetGateway &&
        requestedGatewayId?.isNotEmpty == true && requestedGatewaySessionId?.isNotEmpty == true &&
        (requestedGatewayId != session.gatewayId || requestedGatewaySessionId != session.gatewaySessionId);
    if (target == session.transportMode && !gatewayChanged) return;
    if (target == CallTransportMode.offlineMesh && (store.networkPreference == NetworkPreference.internetOnly || !await _hasLocalRouteTo(session.peerId))) {
      await _sendSignal({'type': 'call_transport_switch_reject', 'call_id': session.id, 'recipient_id': session.peerId, 'transport_mode': target.wireName, 'reason': store.networkPreference == NetworkPreference.internetOnly ? 'internet_only' : 'offline_mesh_unavailable'});
      return;
    }
    if (target == CallTransportMode.webRtc) {
      try { await _ensureSocket(); } catch (_) {
        await _sendSignal({'type': 'call_transport_switch_reject', 'call_id': session.id, 'recipient_id': session.peerId, 'transport_mode': target.wireName, 'reason': 'webrtc_signaling_unavailable'});
        return;
      }
    }
    if (target == CallTransportMode.internetGateway) {
      if (!store.allowThisDeviceAsInternetGateway || requestedGatewayId == null || requestedGatewayId.isEmpty || requestedGatewaySessionId == null || requestedGatewaySessionId.isEmpty) {
        await _sendSignal({'type': 'call_transport_switch_reject', 'call_id': session.id, 'recipient_id': session.peerId, 'transport_mode': target.wireName, 'reason': 'internet_gateway_unavailable'});
        return;
      }
      // The requesting endpoint/gateway has already performed destination-route validation.
      // A LAN-only callee may not have a cached Internet-gateway advertisement, so failover/rebind
      // must not depend on a local advertisement cache hit.
    }
    final remoteCodecs = (msg['supported_media_codecs'] is List)
        ? (msg['supported_media_codecs'] as List).map((e) => e.toString().trim().toLowerCase()).toList()
        : const <String>['pcm_s16le'];
    final selectedCodec = target == CallTransportMode.offlineMesh ? await _negotiateCodec(remoteCodecs) : 'auto';
    if (gatewayChanged) {
      final expiresAt = DateTime.now().toUtc().add(const Duration(minutes: 5));
      gatewayService.attachRemoteSession(
        sessionId: requestedGatewaySessionId!,
        gatewayId: requestedGatewayId!,
        callerId: session.direction == CallDirection.incoming ? session.peerId : (store.deviceId ?? ''),
        destinationId: session.direction == CallDirection.incoming ? (store.deviceId ?? '') : session.peerId,
        expiresAt: expiresAt,
        gatewaySigningPublicKey: msg['gateway_signing_public_key']?.toString() ?? '',
      );
      _setSession(session.copyWith(
        transportMode: target,
        directMode: false,
        gatewayId: requestedGatewayId,
        gatewaySessionId: requestedGatewaySessionId,
        gatewayHopCount: int.tryParse(msg['gateway_hop_count']?.toString() ?? ''),
        gatewayLatencyMs: int.tryParse(msg['gateway_latency_ms']?.toString() ?? ''),
        state: CallState.reconnecting,
        quality: CallQuality.reconnecting,
      ));
    }
    await _sendSignal({
      'type': 'call_transport_switch_accept',
      'call_id': session.id,
      'recipient_id': session.peerId,
      'transport_mode': target.wireName,
      'selected_media_codec': selectedCodec,
      if (target == CallTransportMode.internetGateway) ...{
        'gateway_id': _session?.gatewayId,
        'gateway_session_id': _session?.gatewaySessionId,
        'gateway_hop_count': _session?.gatewayHopCount,
        'gateway_latency_ms': _session?.gatewayLatencyMs,
      },
    });
    await _switchActiveTransport(target, selectedCodec: selectedCodec, forceReconfigure: gatewayChanged);
  }

  Future<void> _handleTransportSwitchAccept(Map<String, dynamic> msg) async {
    final session = _session;
    if (session == null || session.isFinished || !_signalTargetsThisSession(msg, session, requireRemoteSender: true)) return;
    final modeName = msg['transport_mode']?.toString().trim().toLowerCase();
    final target = switch (modeName) {
      'offline_mesh' => CallTransportMode.offlineMesh,
      'webrtc' => CallTransportMode.webRtc,
      'internet_gateway' => CallTransportMode.internetGateway,
      _ => null,
    };
    if (target == null) return;
    var next = session;
    var forceReconfigure = false;
    if (target == CallTransportMode.internetGateway) {
      final gatewayId = msg['gateway_id']?.toString().trim();
      final gatewaySessionId = msg['gateway_session_id']?.toString().trim();
      if (gatewayId == null || gatewayId.isEmpty || gatewaySessionId == null || gatewaySessionId.isEmpty) return;
      forceReconfigure = gatewayId != session.gatewayId || gatewaySessionId != session.gatewaySessionId;
      next = session.copyWith(
        gatewayId: gatewayId,
        gatewaySessionId: gatewaySessionId,
        gatewayHopCount: int.tryParse(msg['gateway_hop_count']?.toString() ?? ''),
        gatewayLatencyMs: int.tryParse(msg['gateway_latency_ms']?.toString() ?? ''),
      );
      _setSession(next);
    }
    final selectedCodec = msg['selected_media_codec']?.toString().trim().toLowerCase();
    await _switchActiveTransport(target, selectedCodec: selectedCodec, forceReconfigure: forceReconfigure);
  }

  Future<void> _handleTransportSwitchReject(Map<String, dynamic> msg) async {
    final session = _session;
    if (session == null || session.isFinished || !_signalTargetsThisSession(msg, session, requireRemoteSender: true)) return;
    _transportSwitchTimer?.cancel();
    _switchingTransport = false;
    _setSession(session.copyWith(state: CallState.connected, quality: CallQuality.fair, reason: msg['reason']?.toString() ?? 'transport_switch_rejected'));
    await _persistSession();
  }

  Future<void> _switchActiveTransport(CallTransportMode target, {String? selectedCodec, bool forceReconfigure = false}) async {
    final currentSession = _session;
    final oldTransport = _transport;
    if (currentSession == null || currentSession.isFinished || oldTransport == null) return;
    if (target == CallTransportMode.offlineMesh && (store.networkPreference == NetworkPreference.internetOnly || !await _hasLocalRouteTo(currentSession.peerId))) throw StateError(store.networkPreference == NetworkPreference.internetOnly ? 'Internet-only calling is enabled' : 'offline mesh transport is unavailable for this peer');
    if (target == CallTransportMode.webRtc) await _ensureSocket();
    if (oldTransport.mode == target && !forceReconfigure) return;
    _transportSwitchTimer?.cancel();
    final mediaCodec = target == CallTransportMode.offlineMesh && (selectedCodec == 'opus' || selectedCodec == 'pcm_s16le') ? selectedCodec! : (target == CallTransportMode.webRtc ? 'auto' : currentSession.mediaCodec);
    final nextSession = currentSession.copyWith(
      state: CallState.reconnecting,
      transportMode: target,
      directMode: target == CallTransportMode.offlineMesh,
      mediaCodec: mediaCodec,
      quality: CallQuality.reconnecting,
    );
    _setSession(nextSession);
    try {
      await oldTransport.stop(currentSession);
      final next = transportFactory.resolve(requested: target, session: nextSession);
      _transport = next;
      await next.start(nextSession);
      _switchingTransport = false;
      if (target == CallTransportMode.webRtc && nextSession.direction == CallDirection.outgoing) {
        _setSession(_session!.copyWith(state: CallState.connecting));
        await next.sendOffer(_session!);
      } else if (target == CallTransportMode.offlineMesh || target == CallTransportMode.internetGateway) {
        await _markConnected();
      }
      await _persistSession();
    } catch (_) {
      _switchingTransport = false;
      await _fail('transport_switch_failed');
    }
  }

  Future<void> _handleInviteAck(Map<String, dynamic> msg) async {
    final session = _session;
    if (session == null || session.id != msg['call_id']?.toString() || session.direction != CallDirection.outgoing || msg['sender_id']?.toString() != store.deviceId || msg['recipient_id']?.toString() != session.peerId) return;
    if (msg['status']?.toString() != 'ringing') return;
    _setSession(session.copyWith(state: CallState.ringing));
  }

  Future<void> _handleState(Map<String, dynamic> msg) async {
    final session = _session;
    if (session == null || session.id != msg['call_id']?.toString() || !_signalTargetsThisSession(msg, session)) return;
    final status = msg['status']?.toString() ?? '';
    final reason = msg['reason']?.toString() ?? '';
    if (status == 'connected') {
      if (session.direction == CallDirection.outgoing && session.state != CallState.connected) {
        if (_transport == null) {
          _transport = transportFactory.resolve(requested: session.transportMode, session: session);
          await _transport!.start(session);
        }
        if (session.transportMode == CallTransportMode.webRtc) {
          _setSession(session.copyWith(state: CallState.connecting));
          await _persistSession();
          await _transport!.sendOffer(_session!);
        } else {
          await _markConnected();
        }
      } else if (session.direction == CallDirection.incoming && session.state != CallState.connected) {
        if (session.transportMode == CallTransportMode.webRtc) return;
        await _markConnected();
      }
      return;
    }
    if (status == 'reconnecting') {
      _setSession(session.copyWith(state: CallState.reconnecting, quality: CallQuality.reconnecting));
      return;
    }
    if (status == 'rejected') { await _finishLocal(CallState.rejected, reason.isEmpty ? 'rejected' : reason, notifyServer: false); return; }
    if (status == 'missed') { await _finishLocal(CallState.missed, reason.isEmpty ? 'missed' : reason, notifyServer: false); return; }
    if (status == 'canceled') { await _finishLocal(CallState.canceled, reason.isEmpty ? 'canceled' : reason, notifyServer: false); return; }
    if (status == 'failed') { await _finishLocal(CallState.failed, reason.isEmpty ? 'failed' : reason, notifyServer: false); return; }
    if (status == 'ended') await _finishLocal(CallState.ended, reason.isEmpty ? 'ended' : reason, notifyServer: false);
  }

  Future<void> _sendSignal(Map<String, dynamic> msg) async {
    final recipient = msg['recipient_id']?.toString();
    if (recipient == null || recipient.isEmpty) return;
    final sessionMode = _session?.transportMode;
    final explicitMode = msg['transport_mode']?.toString().toLowerCase();
    final useMesh = sessionMode == CallTransportMode.offlineMesh || msg['direct'] == true || msg['mesh_call'] == true || explicitMode == CallTransportMode.offlineMesh.wireName;
    if (useMesh) {
      await transportFactory.nativeMesh.sendControl(recipientId: recipient, payload: {
        ...msg,
        'sender_id': store.deviceId,
        'direct': true,
        'mesh_call': true,
        'transport_mode': CallTransportMode.offlineMesh.wireName,
      });
      return;
    }
    final gatewayMode = sessionMode == CallTransportMode.internetGateway ||
        (msg['gateway_session_id']?.toString().trim().isNotEmpty == true && msg['gateway_id']?.toString().trim().isNotEmpty == true);
    if (gatewayMode) {
      final active = _session;
      final gatewayId = active?.gatewayId ?? msg['gateway_id']?.toString().trim() ?? '';
      final gatewaySessionId = active?.gatewaySessionId ?? msg['gateway_session_id']?.toString().trim() ?? '';
      final destination = active?.peerId ?? recipient;
      var gatewaySession = gatewayService.sessionForId(gatewaySessionId);
      if (gatewaySession == null && gatewayId.isNotEmpty && gatewaySessionId.isNotEmpty) {
        final expiresAt = DateTime.tryParse(msg['gateway_expires_at']?.toString() ?? '')?.toUtc() ?? DateTime.now().toUtc().add(const Duration(minutes: 5));
        gatewayService.attachRemoteSession(
          sessionId: gatewaySessionId,
          gatewayId: gatewayId,
          callerId: active?.direction == CallDirection.incoming ? active!.peerId : (store.deviceId ?? ''),
          destinationId: active?.direction == CallDirection.incoming ? (store.deviceId ?? '') : destination,
          expiresAt: expiresAt,
          gatewaySigningPublicKey: msg['gateway_signing_public_key']?.toString() ?? '',
        );
        gatewaySession = gatewayService.sessionForId(gatewaySessionId);
      }
      if (gatewaySession == null) throw StateError('gateway call session is unavailable');
      final signal = CallSessionSignal(
        type: msg['type']?.toString() ?? '',
        callId: msg['call_id']?.toString() ?? _session!.id,
        senderId: store.deviceId ?? '',
        recipientId: recipient,
        reason: msg['reason']?.toString() ?? '',
        transportMode: msg['transport_mode']?.toString() ?? _session!.transportMode.wireName,
        selectedMediaCodec: msg['selected_media_codec']?.toString() ?? '',
        supportedMediaCodecs: msg['supported_media_codecs'] is List ? (msg['supported_media_codecs'] as List).map((e) => e.toString()).toList() : const [],
      );
      await gatewayService.sendCallSignal(signal: signal, session: gatewaySession);
      return;
    }
    await _ensureSocket();
    socket.send({...msg, 'sender_id': store.deviceId});
  }

  void _handleSocketState(bool connected) {
    final session = _session;
    if (session == null || session.isFinished) return;
    if (session.transportMode == CallTransportMode.internetGateway) return;
    _setSession(session.copyWith(signalingConnected: connected));
    if (connected) {
      unawaited(syncHistory());
      _sendHeartbeat();
    }
  }

  Future<void> _fallbackFromLostMesh(CallSession active, String? reason) async {
    if (_gatewayFailoverInProgress || _switchingTransport || _session?.id != active.id) return;
    final localStillAvailable = await _hasLocalRouteTo(active.peerId);
    if (localStillAvailable) {
      await _fail(reason ?? 'mesh_route_failed');
      return;
    }
    try {
      await _ensureSocket();
      final remote = _session;
      if (remote != null && !remote.isFinished && socket.isConnected && remote.peerId == active.peerId) {
        await switchTransport(CallTransportMode.webRtc);
        return;
      }
    } catch (_) {}
    if (store.allowThisDeviceAsInternetGateway) {
      try {
        await switchTransport(CallTransportMode.internetGateway);
        return;
      } catch (_) {}
    }
    await _fail(reason ?? 'no_fallback_route');
  }

  void _onTransportState(CallSession session, String state, String? reason) {
    if (_session?.id != session.id || _disposed) return;
    switch (state) {
      case 'connected': unawaited(_markConnected()); break;
      case 'reconnecting':
        _setSession(_session!.copyWith(state: CallState.reconnecting, quality: CallQuality.reconnecting, reason: reason ?? _session!.reason));
        unawaited(_persistSession());
        break;
      case 'failed':
        final active = _session;
        if (active != null && active.transportMode == CallTransportMode.internetGateway && !_gatewayFailoverInProgress) {
          unawaited(_attemptGatewayFailover());
        } else if (active != null &&
            active.transportMode == CallTransportMode.webRtc &&
            _preferredMode == CallTransportMode.auto &&
            store.networkPreference != NetworkPreference.internetOnly &&
            !_switchingTransport) {
          unawaited(_hasLocalRouteTo(active.peerId).then((available) {
            if (available) {
              return switchTransport(CallTransportMode.offlineMesh);
            }
            return _fail(reason ?? 'transport_failed');
          }).catchError((_) => _fail(reason ?? 'transport_failed')));
        } else if (active != null &&
            active.transportMode == CallTransportMode.offlineMesh &&
            _preferredMode == CallTransportMode.auto &&
            store.networkPreference != NetworkPreference.internetOnly &&
            !_switchingTransport) {
          unawaited(_fallbackFromLostMesh(active, reason));
        } else {
          unawaited(_fail(reason ?? 'transport_failed'));
        }
        break;
    }
  }

  Future<void> _markConnected() async {
    final session = _session;
    if (session == null || session.isFinished) return;
    _ringTimer?.cancel();
    _recoveryAttempts = 0;
    _setSession(session.copyWith(state: CallState.connected, answeredAt: session.answeredAt ?? DateTime.now(), quality: CallQuality.excellent, recoveryAttempts: 0));
    await _persistSession();
    _startHeartbeatTimer();
    _startStatsTimer();
  }

  Future<void> _attemptGatewayFailover() async {
    if (_gatewayFailoverInProgress || _disposed) return;
    final session = _session;
    if (session == null || session.isFinished || session.transportMode != CallTransportMode.internetGateway) return;
    _gatewayFailoverInProgress = true;
    try {
      final oldGateway = session.gatewayId;
      final route = await gatewayService.resolveRoute(session.peerId, excludedGatewayIds: oldGateway == null ? const {} : {oldGateway});
      if (route == null || !route.isValid) {
        await _fail('gateway_unavailable');
        return;
      }
      final newGatewaySession = await gatewayService.createSession(destinationId: session.peerId, route: route);
      final next = session.copyWith(
        gatewayId: newGatewaySession.gatewayId,
        gatewaySessionId: newGatewaySession.sessionId,
        gatewayHopCount: route.hopCount,
        gatewayLatencyMs: route.latencyMs,
        state: CallState.reconnecting,
        quality: CallQuality.reconnecting,
      );
      _setSession(next);
      await _persistSession();
      await _sendSignal({
        'type': 'call_transport_switch_request',
        'call_id': session.id,
        'recipient_id': session.peerId,
        'transport_mode': CallTransportMode.internetGateway.wireName,
        'supported_media_codecs': session.supportedMediaCodecs,
        'gateway_id': newGatewaySession.gatewayId,
        'gateway_session_id': newGatewaySession.sessionId,
        'gateway_expires_at': newGatewaySession.expiresAt.toUtc().toIso8601String(),
        'gateway_signing_public_key': newGatewaySession.gatewaySigningPublicKey,
        'gateway_hop_count': route.hopCount,
        'gateway_latency_ms': route.latencyMs,
      });
    } catch (_) {
      await _fail('gateway_failover_failed');
    } finally {
      _gatewayFailoverInProgress = false;
    }
  }

  Future<void> _fail(String reason) async {
    final session = _session;
    if (session == null || session.isFinished) return;
    unawaited(_sendSignal({'type': 'call_end', 'call_id': session.id, 'recipient_id': session.peerId, 'reason': 'failed'}));
    await _finishLocal(CallState.failed, reason, notifyServer: false);
  }

  Future<void> _finishLocal(CallState state, String reason, {required bool notifyServer}) async {
    final session = _session;
    if (session == null) return;
    _cancelCallTimers();
    _transportSwitchTimer?.cancel();
    _switchingTransport = false;
    final endedAt = DateTime.now();
    final next = session.copyWith(state: state, endedAt: endedAt, reason: reason);
    _setSession(next);
    await _persistSession();
    try { if (_transport != null) await _transport!.stop(session); } catch (_) {}
    _transport = null;
    if (notifyServer) unawaited(_sendSignal({'type': 'call_end', 'call_id': session.id, 'recipient_id': session.peerId, 'reason': reason}));
    unawaited(syncHistory());
  }

  Future<void> _collectStats() async {
    final session = _session;
    final transport = _transport;
    if (session == null || session.isFinished || transport == null) return;
    try {
      final stats = await transport.stats(session);
      final loss = (stats['packet_loss_percent'] as num?)?.toDouble();
      final quality = _qualityFor(
        stats['connection_state']?.toString() ?? (session.transportMode == CallTransportMode.offlineMesh ? 'mesh' : 'unknown'),
        stats['ice_connection_state']?.toString() ?? (session.transportMode == CallTransportMode.offlineMesh ? 'mesh' : 'unknown'),
        loss,
        (stats['rtt_ms'] as num?)?.toDouble(),
        (stats['jitter_ms'] as num?)?.toDouble(),
      );
      final sample = CallQualitySample(
        callId: session.id,
        sampledAt: DateTime.now(),
        connectionState: stats['connection_state']?.toString() ?? stats['transport']?.toString() ?? 'unknown',
        iceConnectionState: stats['ice_connection_state']?.toString() ?? stats['transport']?.toString() ?? 'unknown',
        rttMs: (stats['rtt_ms'] as num?)?.toDouble(),
        jitterMs: (stats['jitter_ms'] as num?)?.toDouble(),
        packetsLost: _asInt(stats['packets_lost'] ?? stats['lost_packets']),
        packetsReceived: _asInt(stats['packets_received'] ?? stats['received_packets']),
        packetLossPercent: loss,
        quality: quality.name,
      );
      await store.saveCallQualitySample(sample);
      final latest = _session;
      if (latest != null && latest.id == session.id && !latest.isFinished) _setSession(latest.copyWith(quality: quality, qualitySample: sample));
    } catch (_) {}
  }

  CallQuality _qualityFor(String connection, String ice, double? loss, double? rtt, double? jitter) {
    if (connection.toLowerCase().contains('disconnected') || connection.toLowerCase().contains('failed') || ice.toLowerCase().contains('disconnected') || ice.toLowerCase().contains('failed')) return CallQuality.reconnecting;
    final l = loss ?? 0;
    final rr = rtt ?? 0;
    final j = jitter ?? 0;
    if (l >= 5 || rr >= 300 || j >= 30) return CallQuality.poor;
    if (l >= 2 || rr >= 200 || j >= 15) return CallQuality.fair;
    if (l >= 1 || rr >= 120 || j >= 8) return CallQuality.good;
    if (loss == null && rtt == null && jitter == null) return CallQuality.unknown;
    return CallQuality.excellent;
  }

  int _asInt(Object? value) => int.tryParse(value?.toString() ?? '') ?? 0;

  void _startHeartbeatTimer() {
    _heartbeatTimer?.cancel();
    if (_session == null || _session!.isFinished) return;
    _heartbeatTimer = Timer.periodic(const Duration(seconds: 15), (_) => _sendHeartbeat());
  }

  void _sendHeartbeat() {
    final session = _session;
    if (session == null || session.isFinished) return;
    if (session.transportMode == CallTransportMode.internetGateway) {
      unawaited(_sendSignal({'type': 'call_heartbeat', 'call_id': session.id, 'recipient_id': session.peerId}));
      return;
    }
    if (session.transportMode != CallTransportMode.offlineMesh && !socket.isConnected) return;
    unawaited(_sendSignal({'type': 'call_heartbeat', 'call_id': session.id, 'recipient_id': session.peerId}));
  }

  void _handleHeartbeatAck(Map<String, dynamic> msg) {
    final session = _session;
    if (session == null || session.id != msg['call_id']?.toString()) return;
    if (!session.signalingConnected) _setSession(session.copyWith(signalingConnected: true));
  }

  void _startStatsTimer() {
    _statsTimer?.cancel();
    final session = _session;
    if (session == null || session.isFinished) return;
    _statsTimer = Timer.periodic(const Duration(seconds: 5), (_) => unawaited(_collectStats()));
    unawaited(_collectStats());
  }

  void _cancelCallTimers() {
    _ringTimer?.cancel();
    _statsTimer?.cancel();
    _heartbeatTimer?.cancel();
    _meshRouteRecoveryTimer?.cancel();
    _ringTimer = null;
    _statsTimer = null;
    _heartbeatTimer = null;
    _meshRouteRecoveryTimer = null;
  }

  Future<void> _persistSession() async {
    final session = _session;
    final self = store.deviceId;
    if (session == null || self == null) return;
    await store.saveCall(session.toRecord(self));
  }

  void _setSession(CallSession? session) {
    final previous = _session;
    _session = session;
    if (!_sessionController.isClosed) _sessionController.add(session);
    final wasRinging = previous != null && previous.direction == CallDirection.incoming && previous.state == CallState.ringing;
    final isRinging = session != null && session.direction == CallDirection.incoming && session.state == CallState.ringing;
    if (isRinging && (!wasRinging || previous?.id != session.id)) {
      final revision = ++_presentationRevision;
      unawaited(_presentIncomingCall(session, revision));
    } else if (!isRinging && (wasRinging || session == null)) {
      final revision = ++_presentationRevision;
      unawaited(_clearIncomingPresentation(revision));
    }
  }

  Future<void> _presentIncomingCall(CallSession session, int revision) async {
    if (_disposed || revision != _presentationRevision) return;
    try { await ringtone.start(session.id); } catch (_) {}
    if (_disposed || revision != _presentationRevision) return;
    try {
      if (_appInForeground) await notificationPlatform.cancelIncoming();
      else await notificationPlatform.showIncoming(callId: session.id, callerId: session.peerId, callerName: session.peerName);
    } catch (_) {}
  }

  Future<void> _clearIncomingPresentation(int revision) async {
    if (revision != _presentationRevision) return;
    await ringtone.stop();
    if (revision != _presentationRevision) return;
    await notificationPlatform.cancelIncoming();
  }

  Future<void> _synchronizeIncomingPresentation() async {
    final session = _session;
    final revision = ++_presentationRevision;
    if (session != null && session.direction == CallDirection.incoming && session.state == CallState.ringing) await _presentIncomingCall(session, revision);
    else await _clearIncomingPresentation(revision);
  }

  void _startRingTimer({required bool outgoing}) {
    _ringTimer?.cancel();
    _statsTimer?.cancel();
    _heartbeatTimer?.cancel();
    _ringTimer = Timer(Duration(seconds: outgoing ? 35 : 30), () {
      final session = _session;
      if (session == null || session.isFinished || session.state != CallState.ringing) return;
      if (outgoing) {
        unawaited(endCall(reason: 'timeout'));
      } else {
        unawaited(_sendSignal({'type': 'call_end', 'call_id': session.id, 'recipient_id': session.peerId, 'reason': 'missed'}));
        unawaited(_finishLocal(CallState.missed, 'missed', notifyServer: false));
      }
    });
  }

  Future<List<String>> _supportedMediaCodecs() async {
    final codecs = await mediaPlatform.supportedCodecs();
    final normalized = codecs.map((e) => e.trim().toLowerCase()).where((e) => e == 'opus' || e == 'pcm_s16le').toSet().toList();
    return normalized.isEmpty ? const ['pcm_s16le'] : normalized;
  }

  Future<String> _negotiateCodec(List<String> remoteCodecs) async {
    final local = await _supportedMediaCodecs();
    if (remoteCodecs.contains('opus') && local.contains('opus')) return 'opus';
    return 'pcm_s16le';
  }

  String _newCallId() {
    final random = Random.secure();
    final bytes = List<int>.generate(16, (_) => random.nextInt(256));
    return 'call-${bytes.map((b) => b.toRadixString(16).padLeft(2, '0')).join()}';
  }
}
