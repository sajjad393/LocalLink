import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:locallink/core/models/profile.dart';
import 'package:locallink/core/services/identity_crypto_service.dart';
import 'package:locallink/core/services/local_store.dart';
import 'package:locallink/core/services/locallink_api.dart';
import 'package:locallink/features/account/bloc/account_bloc.dart';
import 'package:locallink/features/account/domain/account_repository_contract.dart';
import 'package:locallink/features/account/domain/identity_repository_contract.dart';
import 'package:locallink/features/account/presentation/screens/devices_screen.dart';
import 'package:locallink/features/directory/domain/directory_models.dart';
import 'package:locallink/features/directory/domain/directory_repository_contract.dart';
import 'package:locallink/features/directory/presentation/my_qr_screen.dart';
import 'package:locallink/features/directory/presentation/privacy_security_screen.dart';
import 'package:locallink/features/recovery/domain/account_restoration_repository_contract.dart';
import 'package:locallink/features/transfer/domain/account_transfer_repository_contract.dart';
import 'package:locallink/features/transfer/presentation/screens/account_transfer_screen.dart';
import 'package:locallink/features/calls/data/transport/network_preference.dart';

class ProfileScreen extends StatefulWidget {
  final AccountRepositoryContract accountRepository;
  final LocalLinkApi api;
  final LocalStore store;
  final bool onboarding;
  final AccountTransferRepositoryContract transferRepository;
  final IdentityCryptoService? crypto;
  final IdentityRepositoryContract? identityRepository;
  final AccountRestorationRepositoryContract? restoreService;
  final DirectoryRepositoryContract? directoryRepository;

  const ProfileScreen({
    super.key,
    required this.accountRepository,
    required this.api,
    required this.store,
    this.onboarding = false,
    required this.transferRepository,
    this.crypto,
    this.identityRepository,
    this.restoreService,
    this.directoryRepository,
  });

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  late final AccountBloc bloc;
  final name = TextEditingController();
  final username = TextEditingController();
  final phone = TextEditingController();
  final picker = ImagePicker();
  XFile? image;
  LocalProfile? profile;
  bool byPhone = true;
  bool byName = true;
  bool sync = true;
  String visibility = 'contacts';

  @override
  void initState() {
    super.initState();
    bloc = AccountBloc(widget.accountRepository);
    bloc.load().then((_) {
      if (!mounted) return;
      final value = bloc.profile;
      if (value == null) return;
      setState(() {
        profile = value;
        name.text = value.displayName;
        username.text = value.username;
        phone.text = value.phoneNumber;
        byPhone = value.discoverableByPhone;
        byName = value.discoverableByName;
        sync = value.directorySyncEnabled;
        visibility = value.phoneVisibility;
      });
    });
  }

  Future<void> save() async {
    try {
      final synced = await bloc.saveProfile(
        displayName: name.text,
        username: username.text,
        phoneNumber: phone.text,
        phoneVisibility: visibility,
        discoverableByPhone: byPhone,
        discoverableByName: byName,
        directorySyncEnabled: sync,
        avatarFile: image == null ? null : File(image!.path),
      );
      await widget.directoryRepository?.publishOwnProfile();
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            synced ? 'Profile saved' : 'Saved locally; will sync when available',
          ),
        ),
      );
      if (widget.onboarding) Navigator.pop(context);
    } catch (error) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(error.toString().replaceFirst('Exception: ', ''))),
      );
    }
  }

  Future<void> _pickImage() async {
    final value = await picker.pickImage(
      source: ImageSource.gallery,
      maxWidth: 1024,
      maxHeight: 1024,
      imageQuality: 82,
    );
    if (value != null && mounted) setState(() => image = value);
  }

  Future<void> _showRecovery() async {
    final status = await widget.accountRepository.recoveryCodeStatus();
    if (!mounted) return;
    await showDialog<void>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Recovery code'),
        content: Text(
          status.configured
              ? 'A recovery code is configured. Generate a new one to replace it.'
              : 'No recovery code is configured.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Close'),
          ),
          FilledButton(
            onPressed: () async {
              Navigator.pop(context);
              try {
                final code = await widget.accountRepository.rotateRecoveryCode();
                if (!mounted) return;
                await showDialog<void>(
                  context: context,
                  builder: (_) => AlertDialog(
                    title: const Text('New recovery code'),
                    content: SelectableText(code),
                    actions: [
                      FilledButton(
                        onPressed: () => Navigator.pop(context),
                        child: const Text('Done'),
                      ),
                    ],
                  ),
                );
              } catch (error) {
                if (!mounted) return;
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(content: Text(error.toString().replaceFirst('Exception: ', ''))),
                );
              }
            },
            child: Text(status.configured ? 'Replace code' : 'Generate code'),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    bloc.close();
    name.dispose();
    username.dispose();
    phone.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final value = bloc.profile ?? profile;
    return Scaffold(
      appBar: AppBar(title: const Text('Profile')),
      body: ListView(
        padding: const EdgeInsets.all(18),
        children: [
          Center(
            child: Stack(
              alignment: Alignment.bottomRight,
              children: [
                CircleAvatar(
                  radius: 52,
                  child: Text(
                    (value?.displayName.isNotEmpty == true
                            ? value!.displayName[0]
                            : '?')
                        .toUpperCase(),
                    style: const TextStyle(fontSize: 34),
                  ),
                ),
                FloatingActionButton.small(
                  heroTag: 'profile-photo',
                  onPressed: _pickImage,
                  child: const Icon(Icons.camera_alt_outlined),
                ),
              ],
            ),
          ),
          const SizedBox(height: 22),
          Text('Edit Profile', style: Theme.of(context).textTheme.titleLarge),
          const SizedBox(height: 8),
          TextField(
            controller: name,
            decoration: const InputDecoration(labelText: 'Display name'),
          ),
          TextField(
            controller: username,
            decoration: const InputDecoration(
              labelText: 'Username',
              prefixText: '@',
            ),
          ),
          TextField(
            controller: phone,
            keyboardType: TextInputType.phone,
            decoration: const InputDecoration(labelText: 'Phone number'),
          ),
          const SizedBox(height: 14),
          FilledButton(onPressed: save, child: const Text('Save profile')),
          if (!widget.onboarding) ...[
            const SizedBox(height: 10),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              child: FilledButton.icon(
                onPressed: widget.crypto == null || value == null
                    ? null
                    : () => Navigator.push<void>(
                          context,
                          MaterialPageRoute(
                            builder: (_) => MyQrScreen(
                              profile: DirectoryProfile(
                                userId: value.userId,
                                deviceId: widget.store.deviceId ?? value.deviceId,
                                username: value.username,
                                displayName: value.displayName,
                                profileVersion: value.profileVersion,
                                updatedAt: value.updatedAt,
                                phoneVisibility: value.phoneVisibility,
                                discoverableByPhone: value.discoverableByPhone,
                                discoverableByName: value.discoverableByName,
                                directorySyncEnabled: value.directorySyncEnabled,
                                source: 'local',
                              ),
                              crypto: widget.crypto!,
                              repository: widget.directoryRepository,
                            ),
                          ),
                        ),
                icon: const Icon(Icons.qr_code_2),
                label: const Text('My QR Code'),
              ),
            ),
            Card(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const ListTile(
                    leading: Icon(Icons.public_outlined),
                    title: Text('Network Preference'),
                    subtitle: Text('Choose which connection type LocalLink should prefer for calls.'),
                  ),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
                    child: DropdownButtonFormField<NetworkPreference>(
                      value: widget.store.networkPreference,
                      decoration: const InputDecoration(labelText: 'Network Preference'),
                      items: NetworkPreference.values
                          .map((option) => DropdownMenuItem<NetworkPreference>(
                                value: option,
                                child: Text(option.label),
                              ))
                          .toList(),
                      onChanged: (value) async {
                        if (value == null) return;
                        try {
                          await widget.store.setNetworkPreference(value);
                          if (mounted) setState(() {});
                        } catch (error) {
                          if (!mounted) return;
                          ScaffoldMessenger.of(context).showSnackBar(
                            SnackBar(content: Text(error.toString().replaceFirst('Exception: ', ''))),
                          );
                        }
                      },
                    ),
                  ),
                  Padding(
                    padding: const EdgeInsets.fromLTRB(16, 4, 16, 12),
                    child: Text(
                      widget.store.networkPreference.description,
                      style: Theme.of(context).textTheme.bodySmall,
                    ),
                  ),
                ],
              ),
            ),
            Card(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const ListTile(
                    leading: Icon(Icons.alt_route_outlined),
                    title: Text('Internet Gateway'),
                    subtitle: Text('Share this device's Internet connection through authenticated, end-to-end encrypted LocalLink traffic.'),
                  ),
                  SwitchListTile(
                    secondary: const Icon(Icons.router_outlined),
                    title: const Text('Allow This Device as Internet Gateway'),
                    subtitle: const Text('Allow other LocalLink devices to use this phone as an Internet gateway. Turning this off does not disable local mesh.'),
                    value: widget.store.allowThisDeviceAsInternetGateway,
                    onChanged: (value) async {
                      await widget.store.setAllowThisDeviceAsInternetGateway(value);
                      if (mounted) setState(() {});
                    },
                  ),
                  ListTile(
                    leading: const Icon(Icons.autorenew_outlined),
                    title: const Text('Gateway service is automatic'),
                    subtitle: Text(
                      'Gateway status is controlled by Internet availability, mesh reachability, bandwidth, battery, capacity and data budget.',
                    ),
                  ),
                  ListTile(
                    leading: const Icon(Icons.speed_outlined),
                    title: const Text('Maximum simultaneous gateway calls'),
                    subtitle: Text('${widget.store.maxInternetGatewaySessions} active call${widget.store.maxInternetGatewaySessions == 1 ? '' : 's'}'),
                    trailing: DropdownButton<int>(
                      value: widget.store.maxInternetGatewaySessions,
                      onChanged: (value) async {
                        if (value == null) return;
                        await widget.store.setMaxInternetGatewaySessions(value);
                        if (mounted) setState(() {});
                      },
                      items: List.generate(8, (index) => index + 1)
                          .map((value) => DropdownMenuItem<int>(value: value, child: Text('$value')))
                          .toList(),
                    ),
                  ),
                ],
              ),
            ),
            Card(
              child: ListTile(
                leading: const Icon(Icons.security_outlined),
                title: const Text('Privacy & Security'),
                subtitle: const Text('Phone visibility, discoverability and directory sync'),
                trailing: const Icon(Icons.chevron_right),
                onTap: () => Navigator.push<void>(
                  context,
                  MaterialPageRoute(
                    builder: (_) => PrivacySecurityScreen(
                      accountRepository: widget.accountRepository,
                      directoryRepository: widget.directoryRepository,
                    ),
                  ),
                ),
              ),
            ),
            Card(
              child: ListTile(
                leading: const Icon(Icons.devices_outlined),
                title: const Text('My Devices'),
                subtitle: const Text('View and manage signed-in phones'),
                trailing: const Icon(Icons.chevron_right),
                onTap: widget.identityRepository == null ||
                        widget.restoreService == null ||
                        widget.crypto == null
                    ? null
                    : () => Navigator.push<void>(
                          context,
                          MaterialPageRoute(
                            builder: (_) => DevicesScreen(
                              accountRepository: widget.accountRepository,
                              identityRepository: widget.identityRepository!,
                              api: widget.api,
                              store: widget.store,
                              crypto: widget.crypto!,
                              restoreService: widget.restoreService!,
                            ),
                          ),
                        ),
              ),
            ),
            Card(
              child: ListTile(
                leading: const Icon(Icons.sync_lock_outlined),
                title: const Text('Account Recovery'),
                subtitle: const Text('Manage your recovery code'),
                trailing: const Icon(Icons.chevron_right),
                onTap: _showRecovery,
              ),
            ),
            OutlinedButton.icon(
              onPressed: () => Navigator.push<void>(
                context,
                MaterialPageRoute(
                  builder: (_) => AccountTransferScreen(
                    repository: widget.transferRepository,
                  ),
                ),
              ),
              icon: const Icon(Icons.phone_android),
              label: const Text('Transfer account to another phone'),
            ),
          ],
        ],
      ),
    );
  }
}
