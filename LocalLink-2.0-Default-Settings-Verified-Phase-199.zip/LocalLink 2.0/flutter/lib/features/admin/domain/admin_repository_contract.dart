abstract interface class AdminRepositoryContract {
  Future<Map<String,dynamic>> summary();
  Future<Map<String,dynamic>> runtimeDiagnostics();
  Future<List<Map<String,dynamic>>> devices();
  Future<List<Map<String,dynamic>>> groups();
  Future<List<Map<String,dynamic>>> calls();
  Future<List<Map<String,dynamic>>> logs();
  Future<List<Map<String,dynamic>>> recoveryRequests();
  Future<void> rename(String id,String name);
  Future<void> revoke(String id);
  Future<Map<String,dynamic>> backup();
  Future<Map<String,dynamic>> approveRecovery(String id);
  Future<Map<String,dynamic>> reissueRecovery(String id);
  Future<void> rejectRecovery(String id,String reason);
}
