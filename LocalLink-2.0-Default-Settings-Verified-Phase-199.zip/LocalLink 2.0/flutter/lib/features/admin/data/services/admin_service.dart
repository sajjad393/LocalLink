import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:locallink/core/network/api_http_client.dart';
import 'package:locallink/core/services/locallink_api.dart';

class AdminService {
  final LocalLinkApi api;
  /// Short-lived admin session token returned by POST /api/v1/admin/login.
  final String token;
  final ApiHttpClient httpClient;

  AdminService(this.api, this.token, {ApiHttpClient? httpClient})
      : httpClient = httpClient ?? ApiHttpClient();

  Map<String,String> get _headers => {'Authorization': 'Bearer $token', 'Accept': 'application/json'};
  Future<dynamic> _get(String path) async {
    final r=await httpClient.get(Uri.parse('${api.baseUrl}$path'),headers:_headers).timeout(const Duration(seconds:8));
    if(r.statusCode!=200) throw Exception(_error(r)); return jsonDecode(r.body);
  }
  Future<dynamic> _post(String path) async {
    final r=await httpClient.post(Uri.parse('${api.baseUrl}$path'),headers:_headers).timeout(const Duration(seconds:10));
    if(r.statusCode!=200) throw Exception(_error(r)); return jsonDecode(r.body);
  }
  String _error(http.Response r){try{return (jsonDecode(r.body) as Map)['error']?.toString()??'Admin request failed (${r.statusCode})';}catch(_){return 'Admin request failed (${r.statusCode})';}}
  Future<Map<String,dynamic>> login(String username, String password) async {
    final r=await httpClient.post(Uri.parse('${api.baseUrl}/api/v1/admin/login'),headers:{'Accept':'application/json','Content-Type':'application/json'},body:jsonEncode({'username':username,'password':password})).timeout(const Duration(seconds:10));
    if(r.statusCode!=200) throw Exception(_error(r));
    return Map<String,dynamic>.from(jsonDecode(r.body) as Map);
  }

  Future<Map<String,dynamic>> summary()=>_get('/api/v1/admin/summary').then((e)=>Map<String,dynamic>.from(e as Map));
  Future<Map<String,dynamic>> runtimeDiagnostics()=>_get('/api/v1/admin/runtime-diagnostics').then((e)=>Map<String,dynamic>.from(e as Map));
  Future<List<Map<String,dynamic>>> _paged(String path, String key) async {
    final out=<Map<String,dynamic>>[]; String? cursor;
    for(var i=0;i<10000;i++){
      final query = <String,String>{'limit':'200'}; if(cursor!=null) query['cursor']=cursor;
      final r=await httpClient.get(Uri.parse('${api.baseUrl}$path').replace(queryParameters: query),headers:_headers).timeout(const Duration(seconds:8));
      if(r.statusCode!=200) throw Exception(_error(r));
      final page=Map<String,dynamic>.from(jsonDecode(r.body) as Map);
      final rows=page[key] as List? ?? const []; out.addAll(rows.map((x)=>Map<String,dynamic>.from(x as Map)));
      if(page['has_more']!=true) return out;
      final next=page['next_cursor']?.toString(); if(next==null||next.isEmpty||next==cursor) throw StateError('non-progressing admin pagination cursor'); cursor=next;
    }
    throw StateError('admin pagination exceeded safety limit');
  }
  Future<List<Map<String,dynamic>>> devices()=>_paged('/api/v1/admin/devices','devices');
  Future<List<Map<String,dynamic>>> groups()=>_paged('/api/v1/admin/groups','groups');
  Future<List<Map<String,dynamic>>> calls()=>_paged('/api/v1/admin/calls','calls');
  Future<List<Map<String,dynamic>>> logs()=>_paged('/api/v1/admin/logs','logs');
  Future<void> rename(String id,String name)=>_post('/api/v1/admin/device/rename?id=${Uri.encodeQueryComponent(id)}&name=${Uri.encodeQueryComponent(name)}').then((_){ });
  Future<void> revoke(String id)=>_post('/api/v1/admin/device/revoke?id=${Uri.encodeQueryComponent(id)}').then((_){ });
  Future<Map<String,dynamic>> backup()=>_post('/api/v1/admin/backup').then((e)=>Map<String,dynamic>.from(e as Map));
  Future<List<Map<String,dynamic>>> recoveryRequests()=>_paged('/api/v1/admin/recovery-requests','recovery_requests');
  Future<Map<String,dynamic>> approveRecovery(String id)=>_post('/api/v1/admin/recovery-requests/approve?id=${Uri.encodeQueryComponent(id)}').then((e)=>Map<String,dynamic>.from(e as Map));
  Future<Map<String,dynamic>> reissueRecovery(String id)=>_post('/api/v1/admin/recovery-requests/reissue?id=${Uri.encodeQueryComponent(id)}').then((e)=>Map<String,dynamic>.from(e as Map));
  Future<void> rejectRecovery(String id,String reason)=>_post('/api/v1/admin/recovery-requests/reject?id=${Uri.encodeQueryComponent(id)}&reason=${Uri.encodeQueryComponent(reason)}').then((_){ });
}
