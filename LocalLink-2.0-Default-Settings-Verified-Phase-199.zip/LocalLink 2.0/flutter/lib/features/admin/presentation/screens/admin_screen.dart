import 'package:flutter/material.dart';
import 'package:locallink/core/widgets/local_link_bloc_builder.dart';
import 'package:locallink/features/admin/domain/admin_repository_contract.dart';
import 'package:locallink/features/admin/bloc/admin_bloc.dart';

class AdminScreen extends StatefulWidget {
  final AdminRepositoryContract repository;
  const AdminScreen({super.key, required this.repository});
  @override
  State<AdminScreen> createState() => _AdminScreenState();
}

class _AdminScreenState extends State<AdminScreen> {
  late final AdminBloc _controller = AdminBloc(widget.repository);

  @override
  void initState() {
    super.initState();
    _controller.load();
  }

  @override
  void dispose() {
    _controller.close();
    super.dispose();
  }

  Future<void> _rename(Map<String, dynamic> device) async {
    final c = TextEditingController(text: device['name']?.toString());
    final name = await showDialog<String>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Rename device'),
        content: TextField(controller: c, autofocus: true, maxLength: 64),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(context, c.text.trim()), child: const Text('Save')),
        ],
      ),
    );
    c.dispose();
    if (name == null || name.isEmpty) return;
    await _controller.rename(device['id'].toString(), name);
  }

  Future<void> _revoke(Map<String, dynamic> device) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Revoke device?'),
        content: Text('This will sign out ${device['name'] ?? 'this device'} and block its future authentication.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(context, true), child: const Text('Revoke')),
        ],
      ),
    );
    if (ok == true) await _controller.revoke(device['id'].toString());
  }

  Future<void> _recoveryAction(Map<String, dynamic> request, {bool reissue = false}) async {
    final result = await _controller.approve(request['id'].toString(), reissue: reissue);
    if (result == null || !mounted) return;
    final code = result['recovery_credential']?.toString() ?? '';
    await showDialog<void>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(reissue ? 'Recovery code reissued' : 'Recovery approved'),
        content: SelectableText(
          code.isEmpty
              ? 'No recovery code was returned.'
              : 'Give this one-time recovery code to the user:\n\n$code\n\nIt expires at ${result['expires_at'] ?? ''}.',
        ),
        actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Done'))],
      ),
    );
    await _controller.load();
  }

  Future<void> _reject(Map<String, dynamic> request) async {
    final c = TextEditingController();
    final reason = await showDialog<String>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Reject recovery request'),
        content: TextField(controller: c, maxLength: 256, decoration: const InputDecoration(labelText: 'Reason (optional)')),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(context, c.text.trim()), child: const Text('Reject')),
        ],
      ),
    );
    c.dispose();
    if (reason == null) return;
    await _controller.reject(request['id'].toString(), reason);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('LocalLink Admin'),
        actions: [
          IconButton(onPressed: _controller.loading ? null : _controller.load, icon: const Icon(Icons.refresh)),
          IconButton(
            onPressed: () async {
              final backup = await _controller.backup();
              if (mounted && backup != null) {
                ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Backup created: ${backup['file']}')));
              }
            },
            icon: const Icon(Icons.backup),
          ),
        ],
      ),
      body: LocalLinkBlocBuilder(
        bloc: _controller,
        builder: (context, state) {
          if (_controller.loading) return const Center(child: CircularProgressIndicator());
          if (_controller.error != null && _controller.summaryData == null) {
            return Center(child: Padding(padding: const EdgeInsets.all(24), child: Text(_controller.error!)));
          }
          final summary = _controller.summaryData;
          return RefreshIndicator(
            onRefresh: _controller.load,
            child: ListView(
              padding: const EdgeInsets.all(16),
              children: [
                if (_controller.error != null)
                  Card(child: ListTile(leading: const Icon(Icons.error_outline), title: Text(_controller.error!))),
                Card(
                  child: ListTile(
                    leading: const Icon(Icons.lock_outline),
                    title: const Text('Private conversation content'),
                    subtitle: const Text(
                      'Administrator access to private message content is disabled by policy. The admin console exposes operational metadata, counts, devices, calls, recovery, and audit events only.',
                    ),
                  ),
                ),
                if (summary != null)
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      _card('Devices', summary['devices']),
                      _card('Online', summary['online_devices']),
                      _card('Messages', summary['messages']),
                      _card('Groups', summary['groups']),
                      _card('Files', summary['files']),
                      _card('Storage', _size(summary['file_storage_bytes'])),
                      _card('Active calls', summary['active_calls']),
                    ],
                  ),
                _section('Runtime diagnostics'),
                if (_controller.runtimeDiagnosticsData != null)
                  Card(
                    child: ListTile(
                      leading: const Icon(Icons.monitor_heart_outlined),
                      title: Text('Uptime ${_controller.runtimeDiagnosticsData!['uptime_seconds'] ?? 0}s'),
                      subtitle: Text(
                        'Requests ${_controller.runtimeDiagnosticsData!['requests'] ?? 0} • active ${_controller.runtimeDiagnosticsData!['active_requests'] ?? 0} • 2xx ${_controller.runtimeDiagnosticsData!['successes'] ?? 0} • 4xx ${_controller.runtimeDiagnosticsData!['client_errors'] ?? 0} • 5xx ${_controller.runtimeDiagnosticsData!['server_errors'] ?? 0} • panics ${_controller.runtimeDiagnosticsData!['recovered_panics'] ?? 0}',
                      ),
                    ),
                  )
                else
                  const Card(child: ListTile(leading: Icon(Icons.info_outline), title: Text('Runtime diagnostics unavailable'))),
                _section('Devices'),
                ..._controller.devices.map(
                  (device) => Card(
                    child: ListTile(
                      leading: CircleAvatar(child: Icon(device['online'] == true ? Icons.wifi : Icons.wifi_off)),
                      title: Text(device['name']?.toString() ?? ''),
                      subtitle: Text('${device['platform'] ?? 'android'} • ${device['id'] ?? ''} • ${device['status'] ?? 'active'}'),
                      trailing: PopupMenuButton<String>(
                        onSelected: (value) {
                          if (value == 'rename') _rename(device);
                          if (value == 'revoke' && device['status'] != 'revoked') _revoke(device);
                        },
                        itemBuilder: (_) => [
                          const PopupMenuItem(value: 'rename', child: Text('Rename')),
                          if (device['status'] != 'revoked') const PopupMenuItem(value: 'revoke', child: Text('Revoke')),
                        ],
                      ),
                    ),
                  ),
                ),
                _section('Recovery Requests'),
                if (_controller.recoveries.isEmpty)
                  const Padding(padding: EdgeInsets.symmetric(vertical: 10), child: Text('No recovery requests.'))
                else
                  ..._controller.recoveries.map(
                    (request) => Card(
                      child: ListTile(
                        title: Text('@${request['username'] ?? ''} → ${request['target_device_name'] ?? 'New device'}'),
                        subtitle: Text('${request['status']} • ${request['target_device_id'] ?? ''}\nExpires: ${request['expires_at'] ?? ''}'),
                        isThreeLine: true,
                        trailing: PopupMenuButton<String>(
                          onSelected: (value) {
                            if (value == 'approve') _recoveryAction(request);
                            if (value == 'reissue') _recoveryAction(request, reissue: true);
                            if (value == 'reject') _reject(request);
                          },
                          itemBuilder: (_) => [
                            if (request['status'] == 'pending') ...const [
                              PopupMenuItem(value: 'approve', child: Text('Approve + issue code')),
                              PopupMenuItem(value: 'reject', child: Text('Reject')),
                            ],
                            if (request['status'] == 'approved') const PopupMenuItem(value: 'reissue', child: Text('Reissue code')),
                          ],
                        ),
                      ),
                    ),
                  ),
                _section('Groups'),
                ..._controller.groups.map(
                  (group) => ListTile(
                    leading: const Icon(Icons.group),
                    title: Text(group['name']?.toString() ?? ''),
                    subtitle: Text('${group['members']} members • owner ${group['owner_id']}'),
                  ),
                ),
                _section('Recent calls'),
                ..._controller.calls.take(20).map(
                  (call) => ListTile(
                    leading: const Icon(Icons.call),
                    title: Text('${call['caller_id']} → ${call['callee_id']}'),
                    subtitle: Text('${call['status']} • ${call['duration_seconds']}s'),
                  ),
                ),
                _section('Audit log'),
                ..._controller.logs.take(30).map(
                  (log) => ListTile(
                    leading: const Icon(Icons.security),
                    title: Text(log['action']?.toString() ?? ''),
                    subtitle: Text('${log['target_id'] ?? ''} ${log['detail'] ?? ''}\n${log['created_at'] ?? ''}'),
                  ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _section(String text) => Padding(
        padding: const EdgeInsets.fromLTRB(0, 20, 0, 8),
        child: Text(text, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
      );
  Widget _card(String title, dynamic value) => SizedBox(
        width: 155,
        child: Card(
          child: Padding(
            padding: const EdgeInsets.all(14),
            child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Text(title),
              const SizedBox(height: 6),
              Text('$value', style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
            ]),
          ),
        ),
      );
  String _size(dynamic n) {
    final x = (n as num?)?.toDouble() ?? 0;
    if (x < 1024) return '${x.toStringAsFixed(0)} B';
    if (x < 1048576) return '${(x / 1024).toStringAsFixed(1)} KB';
    if (x < 1073741824) return '${(x / 1048576).toStringAsFixed(1)} MB';
    return '${(x / 1073741824).toStringAsFixed(1)} GB';
  }
}
