/// Snapshot of local IPv4 interfaces used to detect network changes.
class NetworkSnapshot {
  final List<String> interfaceNames;
  final List<String> ipv4Addresses;

  const NetworkSnapshot({
    required this.interfaceNames,
    required this.ipv4Addresses,
  });

  const NetworkSnapshot.empty()
      : interfaceNames = const [],
        ipv4Addresses = const [];

  String get fingerprint =>
      [...interfaceNames, '|', ...ipv4Addresses].join('|');

  bool sameNetworkAs(NetworkSnapshot other) => fingerprint == other.fingerprint;
}
