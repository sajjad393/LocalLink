String cleanBlocError(Object error) => error.toString().replaceFirst('Exception: ', '').trim();
