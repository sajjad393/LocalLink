import 'package:flutter/foundation.dart';

enum AsyncStatus { idle, loading, success, failure }

@immutable
class AsyncState<T> {
  final AsyncStatus status;
  final T? data;
  final String? error;

  const AsyncState({this.status = AsyncStatus.idle, this.data, this.error});

  bool get isLoading => status == AsyncStatus.loading;
  bool get hasError => status == AsyncStatus.failure && error != null;

  AsyncState<T> copyWith({AsyncStatus? status, T? data, String? error, bool clearError = false}) {
    return AsyncState<T>(
      status: status ?? this.status,
      data: data ?? this.data,
      error: clearError ? null : (error ?? this.error),
    );
  }
}
