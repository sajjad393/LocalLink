import 'package:flutter/foundation.dart';

/// Central client-side security policy for network endpoints and sensitive UI flows.
///
/// Development builds may use plaintext HTTP for isolated LAN bring-up. Release
/// builds reject plaintext unless the caller explicitly opts in with
/// `--dart-define=LOCLINK_ALLOW_INSECURE_HTTP=true`.
class SecurityPolicy {
  const SecurityPolicy._();

  static const bool _allowInsecureHttpOverride = const bool.fromEnvironment(
    'LOCLINK_ALLOW_INSECURE_HTTP',
    defaultValue: false,
  );

  static bool get allowInsecureHttp => kDebugMode || _allowInsecureHttpOverride;

  static const int maxServerAddressLength = 255;

  static Uri normalizeServerUri(String value) {
    final raw = value.trim();
    if (raw.isEmpty || raw.length > maxServerAddressLength) {
      throw const FormatException('Server address is required');
    }

    final candidate = RegExp(r'^https?://', caseSensitive: false).hasMatch(raw)
        ? raw
        : 'http://$raw';
    final uri = Uri.tryParse(candidate);
    if (uri == null ||
        (uri.scheme != 'http' && uri.scheme != 'https') ||
        uri.host.isEmpty ||
        uri.userInfo.isNotEmpty ||
        uri.hasQuery ||
        uri.hasFragment ||
        (uri.path.isNotEmpty && uri.path != '/')) {
      throw const FormatException(
        'Server address must be an HTTP/HTTPS host, for example 192.168.1.20:8080',
      );
    }
    if (uri.hasPort && (uri.port < 1 || uri.port > 65535)) {
      throw const FormatException('Server port must be between 1 and 65535');
    }
    if (uri.scheme == 'http' && !allowInsecureHttp) {
      throw const FormatException(
        'Plain HTTP is disabled in release builds. Configure HTTPS or explicitly allow insecure HTTP for development.',
      );
    }
    final normalized = Uri(
      scheme: uri.scheme.toLowerCase(),
      host: uri.host,
      port: uri.hasPort ? uri.port : null,
    );
    return normalized;
  }

  static String normalizeServerAddress(String value) =>
      normalizeServerUri(value).toString().replaceFirst(RegExp(r'/$'), '');

  static bool isSensitiveHeader(String name) {
    final lower = name.toLowerCase();
    return lower == 'authorization' ||
        lower == 'x-device-token' ||
        lower == 'x-admin-token' ||
        lower == 'x-recovery-secret';
  }
}
