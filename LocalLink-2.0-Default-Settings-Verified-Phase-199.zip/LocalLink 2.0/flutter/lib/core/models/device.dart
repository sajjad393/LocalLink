enum DeviceNetworkStatus {
  disconnected,
  serverInternet,
  serverNoInternet,
  wifiDirect,
  unknown,
}

DeviceNetworkStatus deviceNetworkStatusFromString(String? value) {
  switch (value) {
    case 'green': return DeviceNetworkStatus.serverInternet;
    case 'yellow': return DeviceNetworkStatus.serverNoInternet;
    case 'orange': return DeviceNetworkStatus.wifiDirect;
    case 'unknown': return DeviceNetworkStatus.unknown;
    default: return DeviceNetworkStatus.disconnected;
  }
}

extension DeviceNetworkStatusX on DeviceNetworkStatus {
  String get apiValue => switch (this) {
    DeviceNetworkStatus.serverInternet => 'green',
    DeviceNetworkStatus.serverNoInternet => 'yellow',
    DeviceNetworkStatus.wifiDirect => 'orange',
    DeviceNetworkStatus.disconnected => 'red',
    DeviceNetworkStatus.unknown => 'gray',
  };

  String get label => switch (this) {
    DeviceNetworkStatus.serverInternet => 'Server + Internet',
    DeviceNetworkStatus.serverNoInternet => 'Server connected · No Internet',
    DeviceNetworkStatus.wifiDirect => 'Wi-Fi Direct',
    DeviceNetworkStatus.disconnected => 'Server disconnected',
    DeviceNetworkStatus.unknown => 'Status unknown / stale',
  };
}

class Device {
  final String id;
  final String name;
  final String platform;
  final String createdAt;
  final String lastSeenAt;
  final DeviceNetworkStatus networkStatus;
  final bool serverConnected;
  final bool internetAvailable;
  final bool wifiDirectConnected;
  final String statusUpdatedAt;
  final String status;
  final String revokedAt;
  final String identityFingerprint;
  final bool current;
  final bool lanAvailable;
  final bool meshAvailable;
  final bool gatewayCapable;
  final bool gatewayAvailable;
  final String gatewayVersion;
  final int maxGatewaySessions;
  final int currentGatewaySessions;
  final String lastCapabilityUpdate;

  const Device({
    required this.id,
    required this.name,
    required this.platform,
    required this.createdAt,
    required this.lastSeenAt,
    this.networkStatus = DeviceNetworkStatus.disconnected,
    this.serverConnected = false,
    this.internetAvailable = false,
    this.wifiDirectConnected = false,
    this.statusUpdatedAt = '',
    this.status = 'active',
    this.revokedAt = '',
    this.identityFingerprint = '',
    this.current = false,
    this.lanAvailable = false,
    this.meshAvailable = false,
    this.gatewayCapable = false,
    this.gatewayAvailable = false,
    this.gatewayVersion = '',
    this.maxGatewaySessions = 0,
    this.currentGatewaySessions = 0,
    this.lastCapabilityUpdate = '',
  });

  factory Device.fromJson(Map<String, dynamic> json) => Device(
        id: json['id'] as String,
        name: json['name'] as String? ?? 'Unknown device',
        platform: json['platform'] as String? ?? 'android',
        createdAt: json['created_at'] as String? ?? '',
        lastSeenAt: json['last_seen_at'] as String? ?? '',
        networkStatus: deviceNetworkStatusFromString(json['network_status'] as String?),
        serverConnected: json['server_connected'] == true,
        internetAvailable: json['internet_available'] == true,
        wifiDirectConnected: json['wifi_direct_connected'] == true,
        statusUpdatedAt: json['status_updated_at'] as String? ?? '',
        status: json['status'] as String? ?? 'active',
        revokedAt: json['revoked_at'] as String? ?? '',
        identityFingerprint: json['identity_fingerprint'] as String? ?? '',
        current: json['current'] == true,
        lanAvailable: json['lan_available'] == true,
        meshAvailable: json['mesh_available'] == true,
        gatewayCapable: json['gateway_capable'] == true,
        gatewayAvailable: json['gateway_available'] == true,
        gatewayVersion: json['gateway_version']?.toString() ?? '',
        maxGatewaySessions: int.tryParse(json['max_gateway_sessions']?.toString() ?? '') ?? 0,
        currentGatewaySessions: int.tryParse(json['current_gateway_sessions']?.toString() ?? '') ?? 0,
        lastCapabilityUpdate: json['last_capability_update']?.toString() ?? '',
      );

  Device copyWithPresence({
    DeviceNetworkStatus? networkStatus,
    bool? serverConnected,
    bool? internetAvailable,
    bool? wifiDirectConnected,
    String? statusUpdatedAt,
    bool? lanAvailable,
    bool? meshAvailable,
    bool? gatewayCapable,
    bool? gatewayAvailable,
    String? gatewayVersion,
    int? maxGatewaySessions,
    int? currentGatewaySessions,
    String? lastCapabilityUpdate,
  }) => Device(
        id: id, name: name, platform: platform, createdAt: createdAt, lastSeenAt: lastSeenAt,
        networkStatus: networkStatus ?? this.networkStatus,
        serverConnected: serverConnected ?? this.serverConnected,
        internetAvailable: internetAvailable ?? this.internetAvailable,
        wifiDirectConnected: wifiDirectConnected ?? this.wifiDirectConnected,
        statusUpdatedAt: statusUpdatedAt ?? this.statusUpdatedAt,
        status: status,
        revokedAt: revokedAt,
        identityFingerprint: identityFingerprint,
        current: current,
        lanAvailable: lanAvailable ?? this.lanAvailable,
        meshAvailable: meshAvailable ?? this.meshAvailable,
        gatewayCapable: gatewayCapable ?? this.gatewayCapable,
        gatewayAvailable: gatewayAvailable ?? this.gatewayAvailable,
        gatewayVersion: gatewayVersion ?? this.gatewayVersion,
        maxGatewaySessions: maxGatewaySessions ?? this.maxGatewaySessions,
        currentGatewaySessions: currentGatewaySessions ?? this.currentGatewaySessions,
        lastCapabilityUpdate: lastCapabilityUpdate ?? this.lastCapabilityUpdate,
      );
}
