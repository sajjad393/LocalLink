/// Centralized names for top-level application routes.
///
/// Feature screens may continue to use typed routes while the application
/// shell owns the top-level navigation contract.
abstract final class AppRoutes {
  static const welcome = '/';
  static const home = '/home';
}
