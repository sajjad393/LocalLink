/// Base exception used by application/core layers.
class AppException implements Exception {
  final String message;
  final Object? cause;
  final StackTrace? stackTrace;
  final String? code;

  const AppException(
    this.message, {
    this.cause,
    this.stackTrace,
    this.code,
  });

  @override
  String toString() => message;
}

class NetworkException extends AppException {
  const NetworkException(super.message, {super.cause, super.stackTrace, super.code});
}

class StorageException extends AppException {
  const StorageException(super.message, {super.cause, super.stackTrace, super.code});
}

class SecurityException extends AppException {
  const SecurityException(super.message, {super.cause, super.stackTrace, super.code});
}

class ValidationException extends AppException {
  const ValidationException(super.message, {super.cause, super.stackTrace, super.code});
}
