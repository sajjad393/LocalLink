import 'package:locallink/core/config/app_config.dart';
import 'package:locallink/core/network/api_http_client.dart';
import 'package:locallink/core/security/secure_storage_service.dart';
import 'package:locallink/core/services/identity_crypto_service.dart';
import 'package:locallink/core/services/local_store.dart';
import 'package:locallink/core/services/locallink_api.dart';
import 'package:locallink/core/services/websocket_service.dart';
import 'package:locallink/features/authentication/data/repositories/authentication_repository.dart';
import 'package:locallink/features/account/data/repositories/account_repository.dart';
import 'package:locallink/features/account/data/repositories/identity_repository.dart';
import 'package:locallink/features/calls/data/platform/call_audio_platform_service.dart';
import 'package:locallink/features/calls/data/platform/call_ringtone_platform_service.dart';
import 'package:locallink/features/calls/data/services/call_notification_platform_service.dart';
import 'package:locallink/features/calls/data/services/call_ringtone_service.dart';
import 'package:locallink/features/calls/data/platform/call_media_platform_service.dart';
import 'package:locallink/features/calls/data/repositories/call_repository.dart';
import 'package:locallink/features/calls/data/services/call_session_manager.dart';
import 'package:locallink/features/calls/bloc/call_bloc.dart';
import 'package:locallink/features/calls/data/gateway/gateway_registry.dart';
import 'package:locallink/features/calls/data/gateway/gateway_relay_platform_service.dart';
import 'package:locallink/features/calls/data/gateway/internet_gateway_service.dart';
import 'package:locallink/features/calls/data/gateway/gateway_budget_manager.dart';
import 'package:locallink/features/calls/data/gateway/gateway_bandwidth_manager.dart';
import 'package:locallink/features/calls/data/gateway/gateway_traffic_scheduler.dart';
import 'package:locallink/features/calls/data/gateway/gateway_route_selector.dart';
import 'package:locallink/features/calls/data/gateway/gateway_health_monitor.dart';
import 'package:locallink/features/calls/data/gateway/gateway_runtime.dart';
import 'package:locallink/features/connectivity/data/repositories/connectivity_repository.dart';
import 'package:locallink/features/connectivity/domain/connectivity_repository_contract.dart';
import 'package:locallink/features/connectivity/domain/mesh_repository_contract.dart';
import 'package:locallink/features/connectivity/domain/peer_transport_contract.dart';
import 'package:locallink/features/connectivity/bloc/connectivity_bloc.dart';
import 'package:locallink/features/calls/bloc/gateway_bloc.dart';
import 'package:locallink/features/connectivity/bloc/mesh_bloc.dart';
import 'package:locallink/features/connectivity/data/services/presence_service.dart';
import 'package:locallink/features/connectivity/data/repositories/mesh_repository.dart';
import 'package:locallink/features/connectivity/data/services/wifi_direct_service.dart';
import 'package:locallink/features/connectivity/data/services/wifi_direct_transport_service.dart';
import 'package:locallink/features/files/data/repositories/file_transfer_repository.dart';
import 'package:locallink/features/files/data/services/file_transfer_service.dart';
import 'package:locallink/features/files/domain/file_transfer_repository_contract.dart';
import 'package:locallink/features/groups/data/services/group_messaging_service.dart';
import 'package:locallink/features/groups/data/services/group_crypto_service.dart';
import 'package:locallink/features/messaging/data/repositories/messaging_repository.dart';
import 'package:locallink/features/groups/data/repositories/group_messaging_repository.dart';
import 'package:locallink/features/groups/data/repositories/group_repository.dart';
import 'package:locallink/features/messaging/data/services/reliable_messaging_service.dart';
import 'package:locallink/features/recovery/data/repositories/recovery_repository.dart';
import 'package:locallink/features/recovery/domain/recovery_repository_contract.dart';
import 'package:locallink/features/recovery/data/services/account_restoration_service.dart';
import 'package:locallink/features/recovery/data/repositories/account_restoration_repository.dart';
import 'package:locallink/features/recovery/domain/account_restoration_repository_contract.dart';
import 'package:locallink/features/transfer/data/repositories/account_transfer_repository.dart';
import 'package:locallink/features/home/data/repositories/home_repository.dart';
import 'package:locallink/features/directory/data/repositories/directory_repository.dart';
import 'package:locallink/features/directory/domain/directory_repository_contract.dart';
import 'package:locallink/features/home/domain/home_repository_contract.dart';
import 'package:locallink/core/notifications/local_link_notification_service.dart';

/// Owns the long-lived application services used by the Flutter client.
///
/// Keeping construction and lifecycle of shared services outside screens makes
/// each feature screen responsible for presentation rather than composition.
class AppDependencies {
  final AppConfig config;
  final SecureStorageService secureStorage;
  final ApiHttpClient httpClient;

  AppDependencies({
    AppConfig? config,
    SecureStorageService? secureStorage,
    ApiHttpClient? httpClient,
  })  : config = config ?? const AppConfig(),
        secureStorage = secureStorage ?? const SecureStorageService(),
        httpClient = httpClient ?? ApiHttpClient(),
        store = LocalStore(secureStorage: secureStorage ?? const SecureStorageService()),
        socket = WebSocketService(),
        directTransport = WifiDirectTransportService(),
        wifiDirect = WifiDirectService(),
        crypto = IdentityCryptoService(secureStorage: secureStorage ?? const SecureStorageService()) {
    api = LocalLinkApi(store, socket, httpClient: this.httpClient);
    connectivityRepository = ConnectivityRepository(
      socket: socket,
      wifiDirect: wifiDirect,
      directTransport: directTransport,
      httpClient: this.httpClient,
    );
    connectivity = ConnectivityBloc(repository: connectivityRepository);
    meshRepository = MeshRepository(transport: directTransport);
    mesh = MeshBloc(repository: meshRepository);
    authentication = AuthenticationRepository(api: api, store: store, connectivity: connectivityRepository);
    recoveryRepository = RecoveryRepository(api: api, store: store, crypto: crypto, connectivity: connectivityRepository);
    groupCrypto = GroupCryptoService(store: store, api: api, crypto: crypto, secureStorage: secureStorage);
    final restorationService = AccountRestorationService(store, api, crypto, groupCrypto);
    restoreService = AccountRestorationRepository(service: restorationService);
    transferRepository = AccountTransferRepository(api: api, store: store, crypto: crypto, connectivity: connectivityRepository);
    account = AccountRepository(api: api, store: store);
    identity = IdentityRepository(api: api, store: store, crypto: crypto);
    final fileTransferService = FileTransferService(store, connectivity: connectivityRepository, crypto: crypto, groupCrypto: groupCrypto);
    files = FileTransferRepository(service: fileTransferService);
    groupMessagingService = GroupMessagingService(store, api, socket, files, groupCrypto);
    groupRepository = GroupRepository(api: api, store: store, crypto: groupCrypto);
    homeRepository = HomeRepository(api: api, store: store, socket: socket, directTransport: directTransport, groups: groupRepository);
    adminRepositoryFactory = DefaultAdminRepositoryFactory(api: api, httpClient: this.httpClient);
    groupMessagingRepository = GroupMessagingRepository(service: groupMessagingService);
    callAudioPlatform = CallAudioPlatformService();
    callRingtonePlatform = CallRingtonePlatformService();
    callNotificationPlatform = CallNotificationPlatformService();
    callRingtone = CallRingtoneService(platform: callRingtonePlatform);
    callMediaPlatform = CallMediaPlatformService();
    gatewayRegistry = GatewayRegistry(crypto: crypto);
    gatewayRelayPlatform = GatewayRelayPlatformService();
    gatewayBudgetManager = GatewayBudgetManager(store: store);
    gatewayBandwidthManager = GatewayBandwidthManager();
    gatewayTrafficScheduler = GatewayTrafficScheduler();
    gatewayRouteSelector = GatewayRouteSelector();
    gatewayHealthMonitor = GatewayHealthMonitor();
    internetGatewayService = InternetGatewayService(store: store, socket: socket, directTransport: directTransport, crypto: crypto, registry: gatewayRegistry, relayPlatform: gatewayRelayPlatform, budget: gatewayBudgetManager, bandwidth: gatewayBandwidthManager, trafficScheduler: gatewayTrafficScheduler, routeSelector: gatewayRouteSelector, healthMonitor: gatewayHealthMonitor);
    gatewayAutoManager = GatewayAutoManager(service: internetGatewayService, bandwidth: gatewayBandwidthManager, budget: gatewayBudgetManager);
    callRepository = CallRepository(store: store, api: api, socket: socket);
    callService = CallSessionManager(
      store,
      api,
      socket,
      directTransport,
      repository: callRepository,
      audioPlatform: callAudioPlatform,
      ringtone: callRingtone,
      notificationPlatform: callNotificationPlatform,
      mediaPlatform: callMediaPlatform,
      crypto: crypto,
      gatewayService: internetGatewayService,
    );
    calls = CallBloc(service: callService, repository: callRepository);
    gateway = GatewayBloc(service: internetGatewayService);
    messaging = ReliableMessagingService(
      store,
      api,
      socket,
      files,
      connectivityRepository,
      directTransport,
      crypto,
      groupCrypto,
    );
    messagingRepository = MessagingRepository(store: store, service: messaging);
    notifications = LocalLinkNotificationService(
      store: store,
      messaging: messagingRepository,
      groups: groupMessagingRepository,
      calls: calls,
    );
    presence = PresenceService(store, socket, wifiDirect, directTransport, httpClient: this.httpClient, crypto: crypto);
    directoryRepository = DirectoryRepository(store: store, api: api, transport: directTransport, crypto: crypto);
  }

  final LocalStore store;
  final WebSocketService socket;
  final PeerTransportContract directTransport;
  final WifiDirectService wifiDirect;
  final IdentityCryptoService crypto;
  late final GroupCryptoService groupCrypto;

  late final LocalLinkApi api;
  late final ConnectivityRepositoryContract connectivityRepository;
  late final ConnectivityBloc connectivity;
  late final MeshRepositoryContract meshRepository;
  late final MeshBloc mesh;
  late final AuthenticationRepositoryContract authentication;
  late final RecoveryRepositoryContract recoveryRepository;
  late final AccountRestorationRepositoryContract restoreService;
  late final AccountTransferRepositoryContract transferRepository;
  late final AccountRepositoryContract account;
  late final IdentityRepositoryContract identity;
  late final FileTransferRepositoryContract files;
  late final GroupMessagingService groupMessagingService;
  late final GroupRepositoryContract groupRepository;
  late final GroupMessagingRepositoryContract groupMessagingRepository;
  late final CallAudioPlatformService callAudioPlatform;
  late final CallRingtonePlatformService callRingtonePlatform;
  late final CallNotificationPlatformService callNotificationPlatform;
  late final CallRingtoneService callRingtone;
  late final CallMediaPlatformService callMediaPlatform;
  late final CallRepositoryContract callRepository;
  late final CallSessionManager callService;
  late final GatewayRegistry gatewayRegistry;
  late final GatewayRelayPlatformService gatewayRelayPlatform;
  late final InternetGatewayService internetGatewayService;
  late final GatewayBudgetManager gatewayBudgetManager;
  late final GatewayBandwidthManager gatewayBandwidthManager;
  late final GatewayTrafficScheduler gatewayTrafficScheduler;
  late final GatewayRouteSelector gatewayRouteSelector;
  late final GatewayHealthMonitor gatewayHealthMonitor;
  late final GatewayAutoManager gatewayAutoManager;
  late final HomeRepositoryContract homeRepository;
  late final AdminRepositoryFactory adminRepositoryFactory;
  late final CallBloc calls;
  late final GatewayBloc gateway;
  late final ReliableMessagingService messaging;
  late final MessagingRepositoryContract messagingRepository;
  late final LocalLinkNotificationService notifications;
  late final PresenceService presence;
  late final DirectoryRepositoryContract directoryRepository;

  Future<void> initializeConfiguredServices() async {
    await crypto.init(store.deviceId!);
    await connectivity.start();
    await mesh.start();
    await directoryRepository.start();
    messaging.start();
    groupMessagingService.start();
    await internetGatewayService.start();
    await gatewayAutoManager.start();
    gateway.start();
    calls.start();
    await notifications.start();
    presence.start();
  }


  Future<void> dispose() async {
    await connectivity.close();
    await mesh.close();
    await directoryRepository.dispose();
    await messaging.dispose();
    await groupMessagingService.dispose();
    await notifications.dispose();
    await calls.close();
    await gateway.close();
    await gatewayAutoManager.dispose();
    await internetGatewayService.dispose();
    await callNotificationPlatform.dispose();
    await callRingtone.dispose();
    await presence.dispose();
    await directTransport.stop();
    socket.dispose();
    httpClient.close();
    await store.close();
  }
}
