# LocalLink Call Architecture Roadmap — Phases 68–96

Source of truth: the current LocalLink source tree. A phase is not marked complete solely because files exist; validation status below distinguishes source implementation from unavailable Flutter/Android/device execution.

## Phase 68 — Call Architecture Audit
**Objective:** Reconcile the current call implementation before refactoring.
**Tasks:** Inspect Flutter, Android, backend, MeshRouter, CallBloc, CallService, call media, WebRTC, crypto, networking, notifications, tests, and dependencies; identify duplicate call stacks; preserve existing work.
**Validation:** Source tree inspected; newer Phase-70/runtime ZIP baseline selected over older monolithic voice-notes archive; call-architecture audit script passes.
**Status:** [x] Completed and source reconciled.

## Phase 69 — Unified Call Transport Interface
**Objective:** Put native mesh and WebRTC behind one transport contract.
**Tasks:** Add CallTransport; define lifecycle, signaling, media, stats, mute, video, and shutdown operations.
**Validation:** Contract exists and both implementations conform; static audit passes.
**Status:** [~] Completed in code — Flutter analyzer/test execution requires Flutter SDK.

## Phase 70 — Unified Call Session Manager
**Objective:** Make CallSessionManager the single owner of call-session state.
**Tasks:** Centralize session lifecycle, state, history, notifications, timers, signaling policy, and transport selection; retain CallService compatibility alias.
**Validation:** No RTCPeerConnection/WebRTC types in CallSessionManager; app dependency points to CallSessionManager.
**Status:** [~] Completed in code — Flutter analyzer/test execution requires Flutter SDK.

## Phase 71 — Transport Factory / Selection
**Objective:** Select one transport per active call.
**Tasks:** Add AUTO/OFFLINE_MESH/WEBRTC; select based on local mesh availability and transport preference; reject unavailable explicit modes.
**Validation:** Factory resolves exactly one implementation; source audit passes.
**Status:** [~] Completed in code — runtime transport-selection tests pending.

## Phase 72 — Native Mesh Call Transport
**Objective:** Make NativeMeshTransport the primary offline call media/control path.
**Tasks:** Integrate CallSessionManager with NativeMeshCallTransport; keep MeshRouter central; start/stop native media through one adapter.
**Validation:** Native mesh transport implements CallTransport and starts call media from the unified manager.
**Status:** [~] Completed in code — physical call validation required.

## Phase 73 — Mesh Call Signaling
**Objective:** Move offline call control into the mesh.
**Tasks:** Support invite, accept, reject, busy, end, route request/update/failure signaling; route call control through MeshRouter rather than WebSocket.
**Validation:** Manager routes mesh-mode signals through NativeMeshCallTransport; native transport forwards call control events.
**Status:** [~] Completed in code — LAN/Wi-Fi Direct validation required.

## Phase 74 — Unified Call Packet Protocol
**Objective:** Define and validate compact call-media metadata.
**Tasks:** callId, senderId, recipientId, sequence, timestamp, codec, sample rate, frame duration, TTL, encrypted payload; strict parsing and bounds.
**Validation:** CallMediaPacket validates required fields, lengths, ranges, codec, and TTL; native receiver performs equivalent checks.
**Status:** [~] Completed in code — Dart/native runtime tests pending.

## Phase 75 — Native Audio Engine
**Objective:** Harden native microphone/speaker lifecycle.
**Tasks:** AudioRecord capture, AudioTrack playback, start/stop/mute, audio focus, resource cleanup, audio routing separation from WebRTC.
**Validation:** Native service uses AudioRecord/AudioTrack and audio-focus lifecycle; audio platform adapter has no flutter_webrtc import.
**Status:** [~] Completed in code — Android device validation required.

## Phase 76 — Opus Integration
**Objective:** Use Opus for efficient voice media when supported.
**Tasks:** Capability detection; mono 16 kHz, 20 ms framing; approximately 24 kbps target; PCM fallback through explicit capability negotiation when Opus is unavailable.
**Validation:** CallOpusCodec capability gate exists; codec negotiation is shared with the call session; unexpected post-negotiation Opus initialization failure fails closed rather than changing codec unilaterally.
**Status:** [~] Completed in code — hardware codec compatibility/voice-quality validation required.

## Phase 77 — Encrypted Call Media
**Objective:** Protect call audio end-to-end.
**Tasks:** Call-specific derived key; AES-GCM media protection; metadata-bound AAD; authentication and replay protection; opaque relay handling.
**Validation:** Receiver validates identity metadata before decryption; AAD includes endpoints, call, sequence, timestamp, codec, sample rate, and frame duration; bounded replay cache.
**Status:** [~] Completed in code — security and two-device validation required.

## Phase 78 — MeshRouter Media Integration
**Objective:** Keep media routing inside MeshRouter and independent from audio.
**Tasks:** call_media packet routing, TTL, duplicate protection, route lookup/failure, opaque relay forwarding; no raw audio in messaging packets.
**Validation:** Native capture sends call_media via sendRoutedPayload; route and packet machinery remain in MeshRouter.
**Status:** [~] Completed in code — multi-device routing validation required.

## Phase 79 — Multi-Hop Voice
**Objective:** Support A→B, A→B→C, A→B→C→D.
**Tasks:** Signal and media over one-hop through multi-hop paths; relay encrypted media without decryption; preserve endpoint-only media keys.
**Validation:** Source supports routing path/hop metadata and call-media forwarding; physical multi-hop remains pending.
**Status:** [~] Completed in code — A→B→C→D hardware test required.

## Phase 80 — Jitter Buffer
**Objective:** Reduce audible artifacts from packet arrival variance.
**Tasks:** Bounded receive queue, packet reordering, wait window, late-frame dropping, jitter measurement, initial sequence priming.
**Validation:** Native media has bounded priority queue, 60 ms starting buffer, sequence tracking, and jitter statistics.
**Status:** [~] Completed in code — physical tuning/measurement required.

## Phase 81 — Packet Loss & Opus Recovery
**Objective:** Handle missing/late packets without excessive latency.
**Tasks:** Loss accounting, bounded buffering, avoid per-packet retransmission, Opus decode path with safe failure handling.
**Validation:** Lost/dropped counters exist; no voice-packet retransmission loop; decoder failures do not crash the call.
**Status:** [~] Completed in code — packet-loss audio-quality validation required.

## Phase 82 — Congestion Control
**Objective:** Protect real-time call media under mesh load.
**Tasks:** Bounded call jitter queue, ephemeral call-media transport behavior, latency/jitter/loss measurement, prevent unbounded relay pressure.
**Validation:** Call-media queue is bounded and stats expose loss/jitter; existing mesh resource limits remain in force.
**Status:** [~] Completed in code — load/traffic prioritization measurements required.

## Phase 83 — Route Failure Recovery
**Objective:** Recover an active call after relay/path failure.
**Tasks:** Detect failed next hop; discover alternate route; update path; resume media; cleanly fail when no route exists.
**Validation:** Existing MeshRouter route recovery events are consumed by CallSessionManager; call state enters reconnecting and returns after route recovery.
**Status:** [~] Completed in code — live relay-failure test required.

## Phase 84 — Relay/Forwarding Optimization
**Objective:** Keep encrypted call forwarding lightweight.
**Tasks:** Avoid plaintext at relays; avoid unnecessary decode/encode; bounded queues; call-specific relay metadata only.
**Validation:** Relay path operates on MeshPacket payloads; endpoint-native CallMediaSession is the only audio decoder/encoder.
**Status:** [~] Completed in code — profiling on real devices required.

## Phase 85 — WebRTC Transport Isolation
**Objective:** Preserve WebRTC without coupling it to the offline mesh stack.
**Tasks:** Isolate flutter_webrtc import, peer connection, ICE, SDP, recovery, and WebRTC signaling in WebRTCCallTransport.
**Validation:** flutter_webrtc import occurs only in WebRTC transport; CallSessionManager contains no WebRTC types.
**Status:** [~] Completed in code — Flutter build validation required.

## Phase 86 — WebRTC Internet Calling
**Objective:** Retain Internet-capable WebRTC calling.
**Tasks:** Preserve offer/answer, ICE candidate exchange, recovery, audio, disconnect handling, and signaling through WebSocket infrastructure.
**Validation:** Existing WebRTC transport contains these handlers; physical Internet/WebRTC acceptance remains pending.
**Status:** [~] Completed in code — physical WebRTC acceptance required.

## Phase 87 — Transport Switching
**Objective:** Make mesh↔WebRTC switching explicit and recoverable.
**Tasks:** Add request/accept/reject signaling; negotiate mode and codec; stop old transport; initialize new transport; require renegotiation for WebRTC.
**Validation:** Flutter manager handles switch request/accept/reject; backend authorizes/forwards switch messages; WebRTC switch initiator sends a new offer.
**Status:** [~] Completed in code — live transition testing required.

## Phase 88 — Call State Machine Hardening
**Objective:** Enforce consistent call state transitions.
**Tasks:** Ringing, connecting, connected, reconnecting, ending, terminal states; timeout, duplicates, remote disappearance, route failure, lifecycle handling.
**Validation:** Session manager centralizes transitions and timer cleanup; transport failures map to reconnect/fail paths.
**Status:** [~] Completed in code — Flutter state-machine tests required.

## Phase 89 — Android Call Lifecycle
**Objective:** Preserve incoming-call presentation and native audio lifecycle.
**Tasks:** Ringtone, lock-screen notification, answer/reject actions, call notification channel, background service, audio focus/routing, cleanup.
**Validation:** Existing notification services remain wired; native transport is foreground-capable and call audio now requests/releases focus.
**Status:** [~] Completed in code — Android lock-screen/background/Bluetooth testing required.

## Phase 90 — Security Audit
**Objective:** Verify call confidentiality, authenticity, and replay resistance.
**Tasks:** E2E media key derivation; AES-GCM integrity; metadata binding; peer identity; TTL/sequence/replay checks; no sensitive audio logs.
**Validation:** Static call-architecture audit passes; code-level checks present; external/device security review remains pending.
**Status:** [~] Completed in code — security review/device validation required.

## Phase 91 — Performance Testing
**Objective:** Measure CPU, memory, battery, bandwidth, latency, jitter, and relay capacity.
**Tasks:** 1–4 hop tests; Opus encode/decode cost; queue pressure; end-to-end latency.
**Validation:** Source exposes sent/received/lost/dropped/jitter/queued metrics; executable device profiling unavailable here.
**Status:** [~] Code instrumentation complete — device performance tests pending.

## Phase 92 — Failure Testing
**Objective:** Validate behavior under disconnects, loss, latency, process death, and route changes.
**Tasks:** Wi-Fi/LAN/Wi-Fi Direct interruption; relay disappearance; Internet transitions; background/lock; duplicate/reordered/corrupted packets.
**Validation:** Source paths contain recovery/cleanup and bounded validation; physical failure matrix unavailable here.
**Status:** [~] Code paths covered — physical failure matrix pending.

## Phase 93 — Flutter Integration Audit
**Objective:** Ensure UI/BLoC is transport-agnostic.
**Tasks:** CallBloc → CallGateway only; no direct WebRTC/MeshRouter media control from UI; common state/actions.
**Validation:** CallGateway owns actions; CallSessionManager implements it; only WebRTC transport imports flutter_webrtc.
**Status:** [~] Completed in code — Flutter analyzer/tests required.

## Phase 94 — Backend/WebSocket Separation
**Objective:** Keep backend optional for offline mesh calls while preserving WebRTC signaling.
**Tasks:** Mesh mode must route call control/media locally; WebRTC may use backend signaling; backend must not be required by native mesh media.
**Validation:** Offline `_sendSignal` routes through native mesh; backend transport-switch/WebRTC handlers remain separate; cached backend discovery/ws tests pass, httpapi full run blocked by unavailable external modules.
**Status:** [~] Completed in code — full backend httpapi test execution pending.

## Phase 95 — Final Architecture Cleanup
**Objective:** Remove duplicate/dead call implementation without deleting required functionality.
**Tasks:** Retain one session manager, one transport contract, native mesh transport, isolated WebRTC transport; remove obsolete direct call ownership; preserve compatibility alias.
**Validation:** `call_service.dart` is alias-only; WebRTC references are isolated; architecture audit passes.
**Status:** [~] Completed in code — final Flutter/Android build validation required.

## Phase 96 — Full LocalLink Call Validation / Final Audit
**Objective:** Re-read this tracker against source, run available validation, and record remaining integration work honestly.
**Tasks:** Search TODO/FIXME, search duplicate call implementations, run static audits, backend tests, Flutter analysis/tests, Android build, multi-hop, notifications, encryption, route recovery, WebRTC.
**Validation:** Call architecture static audit PASS; Phase 66 chaos 10/10 PASS; Phase 67 property 9/9 PASS; Phase 68 load/chaos 6/6 PASS; notification/runtime static audits PASS; cached Go tests PASS; Flutter/Android/device gates recorded as unavailable rather than claimed as pass.
**Status:** [~] Code audit completed — Flutter SDK, Android/Gradle toolchain, and physical-device validation required.

## Environment Validation Gates

- Flutter SDK: unavailable in current environment.
- Dart analyzer/tests: blocked until Flutter SDK is installed.
- Android SDK/Gradle integration toolchain: unavailable in current environment.
- ADB/physical devices: unavailable in current environment.
- Go: available; `go test ./internal/discovery ./internal/ws` passes.
- Full `backend/internal/httpapi` test execution: blocked because `github.com/google/uuid` and `modernc.org/sqlite` are not locally available and external module download is blocked.


## Phase 97 — Local-First Call Policy + Internet Fallback
**Objective:** Make AUTO prefer a usable local LAN/mesh/Wi-Fi Direct route and use WebRTC only when no local route exists; expose an Internet-only override in Profile Settings.
**Tasks:** Add persistent `Use Internet Only` setting (default OFF); add centralized transport-selection policy; inspect the specific peer's topology before choosing native mesh; fall back to WebRTC when no local route exists and WebRTC signaling is available; block local transport when Internet-only is enabled; preserve one unified CallSessionManager/CallTransport architecture; add policy tests.
**Validation:** Source policy tests added; local route detection is peer-specific; Profile toggle persists in LocalStore; no duplicate call stack; Flutter analyzer/tests/build and physical-device validation are still required because those toolchains/devices are unavailable here.
**Status:** [~] Completed in code — Flutter SDK/Android toolchain and physical-device validation required.

---

## Phase 98 — Gateway Architecture Definition
**Objective:** Define Internet Gateway Node as an optional authenticated packet bridge while preserving LAN/Wi-Fi Direct and WebRTC.
**Tasks:** Roles DIRECT_LOCAL, DIRECT_WEBRTC, INTERNET_GATEWAY; states; no Raspberry Pi; no MeshRouter/WebRTC replacement; no media decryption.
**Validation:** Static architecture audit; runtime topology test required.
**Status:** [~] Completed in code — runtime validation required.

## Phase 99 — Gateway Capability Model
**Objective:** Advertise real Internet/LAN/Wi-Fi Direct/mesh/gateway capability and capacity.
**Tasks:** Capability fields, version, max/current sessions, available slots and timestamps; selection based on reachability.
**Validation:** Capability round-trip/policy test.
**Status:** [~] Completed in code — physical connectivity validation required.

## Phase 100 — Gateway Identity
**Objective:** Bind gateway capability to stable node identity and signing identity.
**Tasks:** Reuse node/device keys; advertise identity and signing keys; prevent identity mismatch.
**Validation:** Signature/key-pinning test.
**Status:** [~] Completed in code — live identity validation required.

## Phase 101 — Gateway Authentication
**Objective:** Authenticate gateway sessions with identity, nonce, freshness, signature and expiration.
**Tasks:** Gateway session create/accept; Ed25519; replay protection; expiry; reject invalid identities.
**Validation:** Positive/negative handshake tests.
**Status:** [~] Completed in code — runtime security testing required.

## Phase 102 — Gateway Discovery
**Objective:** Discover gateways dynamically across backend and LocalLink discovery paths.
**Tasks:** Signed advertisements; propagation; no hard-coded gateway.
**Validation:** Advertisement propagation/expiry test.
**Status:** [~] Completed in code — live topology validation required.

## Phase 103 — Gateway Registry
**Objective:** Track trusted gateways, routes, load, reachability and expiry.
**Tasks:** GatewayRegistry; key pinning; stale state; route cache.
**Validation:** Registry/expiry tests.
**Status:** [~] Completed in code — Flutter test execution required.

## Phase 104 — Gateway Route Discovery
**Objective:** Verify gateway-to-callee reachability before selection.
**Tasks:** ROUTE_QUERY/RESPONSE; native MeshRouter snapshot; signed route responses.
**Validation:** A→Internet→B→Mesh→C and unreachable cases.
**Status:** [~] Completed in code — multi-device validation required.

## Phase 105 — Gateway-Aware Routing Table
**Objective:** Carry gateway metadata without replacing MeshRouter.
**Tasks:** Gateway ID, hops, latency, route expiry and transport metadata.
**Validation:** Static schema/integration checks.
**Status:** [~] Completed in code — native route-table validation required.

## Phase 106 — Gateway Path Selection
**Objective:** Centralize local/WebRTC/gateway/unavailable selection.
**Tasks:** Local first; direct WebRTC only with direct peer reachability; gateway only after verified route/auth/capacity.
**Validation:** Policy tests.
**Status:** [~] Completed in code — Flutter analyzer/tests required.

## Phase 107 — Internet Gateway Transport
**Objective:** Implement InternetGatewayCallTransport behind CallTransport.
**Tasks:** Authenticated session; encrypted packet tunnel; health monitoring; clean shutdown.
**Validation:** Factory and transport lifecycle tests.
**Status:** [~] Completed in code — physical call validation required.

## Phase 108 — Gateway Tunnel Protocol
**Objective:** Define gateway control and packet envelope over secure Internet transport.
**Tasks:** HELLO/AUTH/SESSION_CREATE/ACCEPT/CALL_PACKET/CLOSE/PING/PONG/ERROR; bounded payloads.
**Validation:** Message compatibility/malformed-message tests.
**Status:** [~] Completed in code — integration test required.

## Phase 109 — Encrypted Call Media Forwarding
**Objective:** Preserve end-to-end media encryption through gateway.
**Tasks:** Forward opaque encrypted MeshPacket payloads; no gateway audio/video decode/encode.
**Validation:** Static media-path audit and ciphertext forwarding test.
**Status:** [~] Completed in code — device privacy validation required.

## Phase 110 — Mesh Integration
**Objective:** Inject gateway packets into existing MeshRouter path.
**Tasks:** Gateway envelope to/from native mesh; multi-hop B→D→E→C.
**Validation:** 2–4 hop physical tests.
**Status:** [~] Completed in code — physical mesh validation required.

## Phase 111 — Call Signaling Through Gateway
**Objective:** Route call setup and lifecycle controls through gateway.
**Tasks:** Invite/accept/reject/busy/end; route/session authorization.
**Validation:** Gateway signaling test matrix.
**Status:** [~] Completed in code — live signaling validation required.

## Phase 112 — Gateway Capacity and Load Management
**Objective:** Prevent gateway overload.
**Tasks:** Advertise and enforce max/current/available sessions; preserve local mesh when not gateway-capable.
**Validation:** Capacity exhaustion test.
**Status:** [~] Completed in code — device capacity validation required.

## Phase 113 — Gateway Selection
**Objective:** Choose dynamically among multiple gateways.
**Tasks:** Reachability, route age, hop count, latency and load; no hard-coding.
**Validation:** Two-gateway selection test.
**Status:** [~] Completed in code — real topology validation required.

## Phase 114 — Failover and Recovery
**Objective:** Rebind active call to another validated gateway without replacing the call session.
**Tasks:** Detect loss; resolve alternate; rebind session/route; fail cleanly when none.
**Validation:** Gateway loss/replacement tests.
**Status:** [~] Completed in code — physical failover required.

## Phase 115 — Gateway Security Hardening
**Objective:** Defend gateway control plane and relay against abuse.
**Tasks:** Rate limits; nonce replay cache; key pinning; TTL; bounds; audit hooks.
**Validation:** Adversarial static/runtime testing.
**Status:** [~] Completed in code — penetration testing required.

## Phase 116 — User Controls and Privacy
**Objective:** Expose gateway consent and bounded policy controls.
**Tasks:** Use gateway; allow device as gateway; Wi-Fi/charging limits; simultaneous-call limit.
**Validation:** Profile persistence/UI review.
**Status:** [~] Completed in code — Flutter UI validation required.

## Phase 117 — Admin / Audit / Diagnostics
**Objective:** Log gateway lifecycle/security metadata without private payloads.
**Tasks:** Registration, auth, session, route/failover/capacity/rejection events; no audio/message content.
**Validation:** Audit output review.
**Status:** [~] Completed in code — backend integration test required.

## Phase 118 — BLoC Integration
**Objective:** Expose gateway discovery/auth/route/session state via GatewayBloc.
**Tasks:** Required events/states; service subscription; transport logic stays out of UI.
**Validation:** Flutter compile/unit tests.
**Status:** [~] Completed in code — Flutter analyzer/tests required.

## Phase 119 — CallSessionManager Integration
**Objective:** Keep one call manager and one transport policy.
**Tasks:** Gateway networking isolated; gateway failover implemented as transport rebind.
**Validation:** Architecture/lifecycle tests.
**Status:** [~] Completed in code — Flutter analyzer/tests required.

## Phase 120 — Backend / Signaling Integration
**Objective:** Use backend for gateway discovery/session signaling while excluding media decoding.
**Tasks:** Signed advertisements, route queries, session auth, opaque packet relay, gateway transport switch signaling.
**Validation:** Go tests and static media-path audit.
**Status:** [~] Completed in code — full httpapi tests blocked by missing cached modules.

## Phase 121 — Offline Gateway Operation
**Objective:** Disable gateway function when Internet is unavailable without damaging offline mesh.
**Tasks:** Gateway availability follows Internet; LAN/Wi-Fi Direct mesh remains independent.
**Validation:** Internet-loss/local-mesh transition test.
**Status:** [~] Completed in code — physical network transition required.

## Phase 122 — Automatic Transport Fallback
**Objective:** Implement exact local/WebRTC/gateway/unavailable fallback matrix.
**Tasks:** Local first; direct WebRTC when peer Internet is directly reachable; gateway otherwise; gateway failover.
**Validation:** Policy/failover tests.
**Status:** [~] Completed in code — Flutter/device tests required.

## Phase 123 — Notifications / UI
**Objective:** Present meaningful gateway connection states.
**Tasks:** Gateway-specific connecting/recovery text; gateway ID/hops in quality details; avoid misleading repeated WebRTC status.
**Validation:** UI interaction/state tests.
**Status:** [~] Completed in code — Flutter/device validation required.

## Phase 124 — Gateway Testing Matrix
**Objective:** Validate basic, multi-hop, multi-gateway and failure topologies.
**Tasks:** A→B→C, A→B→C→D, dual gateway, gateway Internet loss, no gateway.
**Validation:** Automated/static plus physical matrix.
**Status:** [~] Code coverage prepared — physical matrix pending.

## Phase 125 — Security Testing
**Objective:** Run adversarial gateway tests.
**Tasks:** Fake gateway, fake node, replay, mutation, invalid route, flooding, session exhaustion.
**Validation:** Reject, audit, no-crash expectations.
**Status:** [~] Static defenses implemented — runtime adversarial testing required.

## Phase 126 — Performance Testing
**Objective:** Measure gateway call setup and relay overhead.
**Tasks:** Latency, packet loss, jitter, CPU, RAM, battery, bandwidth; compare transports.
**Validation:** 1–4 hop benchmark.
**Status:** [~] Instrumentation present — device benchmark pending.

## Phase 127 — Real Device Acceptance
**Objective:** Validate full gateway calling on 2–4 Android devices.
**Tasks:** Voice/background/lock/network change/gateway restart/replacement plus local-mesh preservation.
**Validation:** Physical acceptance gate; no false pass.
**Status:** [~] Code complete — physical Android acceptance required.



# LocalLink 2.0 — Internet Gateway Automatic Runtime Roadmap (Phases 128–170)

Phase status rules: `[x]` source implementation and static validation are complete; `[~]` source implementation exists but executable/device validation remains; `[!]` blocked by unavailable environment/hardware. A phase is never marked `[x]` solely because a file exists.

## Phase 128 — Gateway Architecture Baseline
**Objective:** Reconcile the Phase-127 gateway foundation with the automatic, resource-aware design.  
**Tasks:** Preserve CallSessionManager/CallTransport; retain Native Mesh and direct WebRTC; make gateway a separate opaque tunnel adapter.  
**Validation:** Source architecture and gateway audit pass.  
**Status:** [x]

## Phase 129 — Independent Connectivity Detection
**Objective:** Separate actual Internet reachability from backend/WebSocket connectivity.  
**Tasks:** Use Android validated-network capability and expose Wi-Fi/metered/bandwidth state.  
**Validation:** Native capability implementation contains `NET_CAPABILITY_VALIDATED`; gateway no longer uses WebSocket as Internet state.  
**Status:** [x]

## Phase 130 — Remove Gateway Permission Dependency
**Objective:** Make acting as a gateway automatic rather than user-granted.  
**Tasks:** Remove runtime dependency on `allowInternetGateway`; remove the permission toggle from Profile; retain only backward-safe storage cleanup.  
**Validation:** No gateway runtime/presence references to the removed permission.  
**Status:** [x]

## Phase 131 — Gateway Eligibility Policy
**Objective:** Decide automatically when this device may provide gateway service.  
**Tasks:** Validate Internet, mesh, battery, power-save, metering, bandwidth, capacity and budget conditions.  
**Validation:** `GatewayEligibilityPolicy` source tests cover Internet and mesh gates.  
**Status:** [x]

## Phase 132 — Gateway Auto Manager
**Objective:** Continuously evaluate gateway readiness.  
**Tasks:** Add 5-second evaluation loop, runtime state transitions and automatic recovery.  
**Validation:** `GatewayAutoManager` wired into app initialization and emits runtime state.  
**Status:** [x]

## Phase 133 — Gateway Capability Model
**Objective:** Advertise complete resource capabilities.  
**Tasks:** Add upstream/downstream bandwidth, loss, health and budget fields.  
**Validation:** Model serialization/deserialization and canonical data include new fields.  
**Status:** [x]

## Phase 134 — Secure Gateway Advertisement
**Objective:** Prevent forged or stale gateway advertisements.  
**Tasks:** Keep signed canonical advertisements and version them to gateway protocol v2.  
**Validation:** Existing signature verification remains in registry/backend; new fields are signed.  
**Status:** [~] Static/source validation complete; runtime signature exchange pending.

## Phase 135 — Multi-Path Gateway Discovery
**Objective:** Discover gateways over backend and local mesh paths.  
**Tasks:** Broadcast gateway advertisements through the mesh and receive them through native transport events.  
**Validation:** Native `gateway_advertisement_received` path and service registry integration are present.  
**Status:** [x]

## Phase 136 — Gateway Registry
**Objective:** Maintain multiple gateways and expiry state.  
**Tasks:** Reuse GatewayRegistry and refresh signed advertisements.  
**Validation:** Registry remains source of candidates; stale advertisements are excluded.  
**Status:** [~] Source implementation present; live multi-gateway refresh pending.

## Phase 137 — Gateway Reachability Verification
**Objective:** Ensure selected gateways can reach the requested destination.  
**Tasks:** Query route reachability and verify route expiry/hop metadata.  
**Validation:** Route query/response paths remain signed and cached.  
**Status:** [~] Source path complete; multi-device reachability test pending.

## Phase 138 — Gateway Path Model
**Objective:** Represent gateway-to-destination path details.  
**Tasks:** Preserve next hop, hop count, latency, expiry and resolved time.  
**Validation:** GatewayRoute source model and snapshot conversion remain intact.  
**Status:** [x]

## Phase 139 — Gateway Bandwidth Manager
**Objective:** Track gateway link capacity and reservations.  
**Tasks:** Store per-session reservations and sent/received usage.  
**Validation:** Manager source includes bounded reservations and counters.  
**Status:** [x]

## Phase 140 — Gateway Data Budget Manager
**Objective:** Prevent unlimited mobile/Internet consumption.  
**Tasks:** Add persistent monthly byte budget, usage accounting and reset.  
**Validation:** Budget persists through LocalStore with periodic batched writes.  
**Status:** [x]

## Phase 141 — Gateway Session Usage
**Objective:** Track usage per gateway session.  
**Tasks:** Maintain sent, received and reserved bytes/rate.  
**Validation:** Session usage is keyed by gateway session ID and released on close/expiry.  
**Status:** [x]

## Phase 142 — Bandwidth Reservation Engine
**Objective:** Reserve enough upstream capacity before admitting gateway calls.  
**Tasks:** Reserve 64 Kbps baseline per active gateway call and reject when capacity is exhausted.  
**Validation:** Gateway session creation reserves capacity and releases it on failure/close.  
**Status:** [x]

## Phase 143 — Traffic Classification
**Objective:** Separate critical from bulk traffic.  
**Tasks:** Classify signaling, voice, video, message and bulk packets.  
**Validation:** Source tests cover signaling > voice > bulk classification.  
**Status:** [x]

## Phase 144 — Gateway Traffic Scheduler
**Objective:** Prioritize real-time gateway traffic.  
**Tasks:** Bounded queue and priority drain with signaling ahead of media/bulk.  
**Validation:** Scheduler source is bounded and serializes transmission.  
**Status:** [x]

## Phase 145 — Congestion Controller
**Objective:** Avoid unbounded gateway pressure.  
**Tasks:** Keep queue bounded and reject new work under saturation.  
**Validation:** Scheduler rejects work at configured queue capacity.  
**Status:** [~] Source control implemented; live congestion measurement pending.

## Phase 146 — Dynamic Gateway Route Selector
**Objective:** Select gateways by resource/health/path quality instead of latency alone.  
**Tasks:** Score health, bandwidth, budget, loss, session load, latency and hops.  
**Validation:** Resolver evaluates all usable gateways and returns the highest-scored valid route.  
**Status:** [x]

## Phase 147 — Multi-Gateway Load Balancing
**Objective:** Spread load across multiple eligible gateways.  
**Tasks:** Rank candidates, resolve multiple routes and score them with live health.  
**Validation:** Resolver collects multiple valid candidates before selecting.  
**Status:** [~] Source complete; multi-device live load balancing pending.

## Phase 148 — Real Internet Gateway Tunnel
**Objective:** Move gateway data off backend media relay.  
**Tasks:** Establish gateway↔destination WebRTC DataChannel and exchange only opaque packets.  
**Validation:** `GatewayTunnel` creates a DataChannel; backend tunnel signaling is separate from packet transport.  
**Status:** [~] Source implementation complete; NAT traversal and live tunnel test pending.

## Phase 149 — Backend Control Plane Separation
**Objective:** Keep backend as signaling/control rather than media server.  
**Tasks:** Authorize sessions, relay tunnel SDP/ICE signaling, reject gateway packet media relay.  
**Validation:** Backend `gateway_tunnel_signal` handler exists and `gateway_packet` is explicitly rejected.  
**Status:** [x]

## Phase 150 — E2E Gateway Forwarding
**Objective:** Preserve end-to-end encrypted call payloads through the gateway.  
**Tasks:** Gateway receives opaque call-media packets and forwards them without decoding.  
**Validation:** Gateway tunnel forwards serialized packet strings; no media key or codec handling is added to gateway code.  
**Status:** [x]

## Phase 151 — Packet Security & Replay Protection
**Objective:** Preserve integrity and replay controls across the gateway path.  
**Tasks:** Retain existing encrypted call-media validation; bound packet/tunnel signal sizes.  
**Validation:** Existing native media replay/destination/codec validation plus backend signal size checks remain present.  
**Status:** [~] Source defenses present; adversarial runtime testing pending.

## Phase 152 — Gateway Failover
**Objective:** Recover gateway sessions after gateway/path failure.  
**Tasks:** Use existing CallSessionManager transport rebind/failover with gateway exclusion and dynamic route selection.  
**Validation:** Existing gateway failover path remains under one CallSessionManager; live transition pending.  
**Status:** [~]

## Phase 153 — Gateway Health Monitor
**Objective:** Feed observed success/failure/loss/RTT into route choice.  
**Tasks:** Maintain per-gateway health score and update it from tunnel delivery.  
**Validation:** Health score is consumed by route scoring.  
**Status:** [x]

## Phase 154 — Automatic Advertisement Control
**Objective:** Advertise availability only when runtime policy permits service.  
**Tasks:** Bind advertisement state to automatic runtime state, resources, budget and mesh.  
**Validation:** `gatewayAvailable` is derived from runtime readiness and resource limits.  
**Status:** [x]

## Phase 155 — GatewayBloc Integration
**Objective:** Expose runtime/gateway state without moving networking into UI.  
**Tasks:** Add typed runtime state to GatewayBloc and consume service runtime events.  
**Validation:** `GatewayRuntimeChanged` is handled by the BLoC.  
**Status:** [x]

## Phase 156 — Gateway Runtime UI
**Objective:** Make automatic gateway operation understandable to the user.  
**Tasks:** Remove the act-as-gateway permission toggle; explain automatic conditions; retain user choice for using a gateway.  
**Validation:** Profile UI contains automatic-mode explanation and no permission switch.  
**Status:** [x]

## Phase 157 — Gateway Diagnostics
**Objective:** Surface runtime health and resource state for troubleshooting.  
**Tasks:** Emit runtime state, reason, bandwidth, sessions and budget metrics.  
**Validation:** Gateway service emits `gateway_runtime`; typed snapshot stores all diagnostic fields.  
**Status:** [x]

## Phase 158 — Call Transport Integration
**Objective:** Keep gateway calling under the existing CallTransport architecture.  
**Tasks:** Preserve InternetGatewayCallTransport, CallSessionManager and Native/WebRTC separation; route media through tunnel bridge.  
**Validation:** Call architecture audit passes.  
**Status:** [~] Source architecture validated; runtime call test pending.

## Phase 159 — Message/Data Integration
**Objective:** Reuse gateway QoS boundaries without making bulk data starve calls.  
**Tasks:** Keep message/bulk traffic behind the same scheduler classes for future gateway data paths.  
**Validation:** Classifier/scheduler hooks exist; full non-call gateway data integration remains pending.  
**Status:** [~]

## Phase 160 — Gateway Security Audit
**Objective:** Recheck gateway authentication, opaque forwarding and audit logging.  
**Tasks:** Verify signatures, session authentication, bounds, replay controls and no plaintext gateway media.  
**Validation:** Static gateway audit and backend relay rejection pass.  
**Status:** [x]

## Phase 161 — Automated Gateway Unit Tests
**Objective:** Add deterministic tests for policy, models, selection and QoS.  
**Tasks:** Add Flutter tests for eligibility, route scoring, traffic classification and advertisement metadata.  
**Validation:** Test source added; execution blocked by missing Flutter/Dart SDK.  
**Status:** [~]

## Phase 162 — Routing Tests
**Objective:** Validate gateway route resolution against the existing mesh router.  
**Tasks:** Cover mesh route query, route response, stale exclusion and multi-gateway scoring.  
**Validation:** Source paths and existing mesh test suites are present; full runtime execution pending.  
**Status:** [~]

## Phase 163 — QoS and Load Tests
**Objective:** Validate bandwidth reservation, queue bounds and gateway saturation behavior.  
**Tasks:** Measure concurrent calls, packet queueing and budget enforcement.  
**Validation:** Source controls exist; device load test pending.  
**Status:** [~]

## Phase 164 — Failure & Recovery Tests
**Objective:** Validate gateway loss, Internet loss, tunnel failure and route recovery.  
**Tasks:** Exercise automatic pause/recovery and CallSessionManager gateway failover.  
**Validation:** Recovery source paths exist; live failure matrix pending.  
**Status:** [~]

## Phase 165 — Flutter Validation
**Objective:** Run Flutter analyze/tests against the final tree.  
**Tasks:** `flutter pub get`, `flutter analyze`, `flutter test`.  
**Validation:** Flutter SDK is required.  
**Status:** [!] Flutter/Dart SDK unavailable in the current environment.

## Phase 166 — Android Build Validation
**Objective:** Build and validate Android integration.  
**Tasks:** Gradle debug/release build, manifest/service checks, native compilation.  
**Validation:** Android SDK/Gradle environment required.  
**Status:** [!] Android build toolchain unavailable in the current environment.

## Phase 167 — Physical Gateway Testing
**Objective:** Validate 2–4 physical Android gateways and mesh edges.  
**Tasks:** LAN/Wi-Fi Direct discovery, Internet loss, bandwidth limits, gateway replacement and background operation.  
**Validation:** Real Android devices are required.  
**Status:** [!] No ADB/physical devices available here.

## Phase 168 — Real Call Testing
**Objective:** Validate complete gateway voice/video calls and failover.  
**Tasks:** Local mesh A→B/C/D calls plus Internet gateway calls and transport transitions.  
**Validation:** Real devices and Internet-enabled networks are required.  
**Status:** [!] No physical devices/toolchain available here.

## Phase 169 — Final Gateway Architecture Audit
**Objective:** Verify no duplicate call stack and no backend media relay dependency.  
**Tasks:** Run gateway, call architecture and transport-policy static audits.  
**Validation:** All three audits pass.  
**Status:** [x]

## Phase 170 — Final Production Readiness Validation
**Objective:** Decide whether all source and runtime acceptance gates are satisfied.  
**Tasks:** Reconcile code status, executable validation, device acceptance and known blockers.  
**Validation:** Production readiness requires Phases 165–168 to pass, not merely source presence.  
**Status:** [~] Source implementation is substantially complete; production/device gates remain blocked.

# LocalLink 2.0 — Network Preference & Internet Gateway Controls Roadmap (Phases 171–199)

## Phase 171 — Network Preference Model
**Objective:** Replace the old Internet Only toggle with a central three-mode network preference model.
**Tasks:** Add `Local First`, `Internet Preferred`, and advanced strict `Internet Only`; keep transport choice centralized.
**Validation:** `NetworkPreference` exists and the selection policy consumes it.
**Status:** [~] Source implementation validated by transport-policy audit.

## Phase 172 — Persistent Network Preference
**Objective:** Persist the selected preference across restarts.
**Tasks:** Add `network_preference` storage; migrate legacy `use_internet_only`; default to Local First; safely handle invalid values.
**Validation:** LocalStore load/save path and migration are present.
**Status:** [~] Source implementation validated.

## Phase 173 — Local First Policy
**Objective:** Prefer local LAN, Wi-Fi Direct and MeshRouter routes before Internet.
**Tasks:** Preserve direct and multi-hop route resolution; fall back to WebRTC and then gateway when no local route exists.
**Validation:** Policy tests cover local route + Internet availability and gateway fallback.
**Status:** [~] Source implementation validated; physical LAN/Wi-Fi Direct/multi-hop test required.

## Phase 174 — Internet Preferred Policy
**Objective:** Prefer WebRTC when available, then fall back to local mesh when WebRTC is unavailable.
**Tasks:** Evaluate Internet availability even when a local route exists; avoid transport flapping.
**Validation:** Policy tests cover WebRTC-first and local fallback.
**Status:** [~] Source implementation validated; physical transition test required.

## Phase 175 — Advanced Internet Only
**Objective:** Preserve a strict Internet-only mode.
**Tasks:** WebRTC only; never LAN, Wi-Fi Direct, MeshRouter or gateway.
**Validation:** Policy rejects calls when WebRTC is unavailable.
**Status:** [~] Source policy validated; physical validation required.

## Phase 176 — Central Transport Decision Engine
**Objective:** Keep one deterministic decision point under CallTransport.
**Tasks:** Remove preference decisions from duplicated layers; preserve CallSessionManager + CallTransport + Native/WebRTC/Gateway architecture.
**Validation:** Call architecture and transport-policy audits pass.
**Status:** [~] Source architecture validated; Flutter runtime validation required.

## Phase 177 — Separate Gateway Sharing Control
**Objective:** Independently control whether this device can act as an Internet gateway.
**Tasks:** Add `Allow This Device as Internet Gateway`; default ON; persist separately from network preference.
**Validation:** LocalStore exposes independent persisted setting.
**Status:** [~] Source implementation validated.

## Phase 178 — Gateway Advertisement Permission Enforcement
**Objective:** Never advertise gateway capability when sharing is OFF.
**Tasks:** Remove hardcoded permission; suppress gateway advertisements when disabled; prevent gateway runtime service from acting as a gateway.
**Validation:** Source contains no hardcoded `final allowed = true`; service checks the persisted setting.
**Status:** [~] Source implementation validated.

## Phase 179 — Incoming Gateway Session Enforcement
**Objective:** Reject gateway service requests when sharing is OFF without disabling mesh.
**Tasks:** Reject gateway session creation; retain LAN/Wi-Fi Direct/MeshRouter operation.
**Validation:** Incoming gateway handler checks sharing state before admission.
**Status:** [~] Source implementation validated.

## Phase 180 — Gateway Capability Advertisement
**Objective:** Advertise realistic usable gateway capacity.
**Tasks:** Include available/reserved upstream/downstream capacity, sessions, health, budget and Internet/mesh state.
**Validation:** Gateway model canonical form and advertisement generation include capacity metadata.
**Status:** [~] Source implementation validated; real bandwidth measurement required.

## Phase 181 — Gateway Admission Control
**Objective:** Prevent gateway overload.
**Tasks:** Check Internet, sharing permission, mesh, budget, session slots and reserved bandwidth before accepting sessions.
**Validation:** Session creation reserves bandwidth and releases it on rejection/close.
**Status:** [~] Source implementation validated; load testing required.

## Phase 182 — Gateway Data Budget
**Objective:** Account for gateway traffic without affecting pure local mesh.
**Tasks:** Track gateway session bytes, aggregate usage, remaining budget and exhaustion.
**Validation:** Gateway forwarding consumes budget only on gateway-owned forwarding paths.
**Status:** [~] Source implementation validated; long-duration/device accounting required.

## Phase 183 — Gateway QoS
**Objective:** Protect real-time gateway traffic from bulk traffic.
**Tasks:** Maintain signaling/voice/video/message/bulk priorities and bounded queues.
**Validation:** Scheduler source tests and queue bounds exist.
**Status:** [~] Source implementation validated; physical saturation test required.

## Phase 184 — Dynamic Multi-Gateway Selection
**Objective:** Select among gateways using more than latency.
**Tasks:** Consider health, usable bandwidth, budget, packet loss, load, latency and route hops.
**Validation:** Gateway route selector consumes resource/health/path signals.
**Status:** [~] Source implementation validated; multi-device measurement required.

## Phase 185 — Gateway Failover
**Objective:** Recover an active session when its gateway fails.
**Tasks:** Exclude failed gateway, select replacement, rebind the existing call session without creating a second call.
**Validation:** Failover hooks and existing CallSessionManager integration remain present.
**Status:** [~] Source implementation validated; live gateway failure test required.

## Phase 186 — Internet Loss Recovery
**Objective:** Recover deterministically from Internet/WebRTC loss.
**Tasks:** Internet Preferred can fall back to local mesh; Local First can fall back to WebRTC/gateway; prevent flapping.
**Validation:** Source policy and transport recovery paths exist.
**Status:** [~] Source implementation validated; physical network-transition test required.

## Phase 187 — Gateway vs Pure Mesh Isolation
**Objective:** Gateway limits must never throttle pure local mesh.
**Tasks:** Keep gateway budget/QoS/bandwidth accounting scoped to gateway sessions.
**Validation:** Source audit and targeted test matrix cover direct and multi-hop mesh independently.
**Status:** [~] Source implementation validated; physical A→B→C→D isolation test required.

## Phase 188 — WebRTC Isolation Audit
**Objective:** Keep WebRTC independent from mesh routing internals.
**Tasks:** No WebRTC types in MeshRouter; no duplicate call manager; preserve one CallTransport architecture.
**Validation:** Call architecture audit passes.
**Status:** [~] Source audit passes.

## Phase 189 — E2E Security Audit
**Objective:** Preserve end-to-end encryption through gateways and backend.
**Tasks:** No gateway media decryption; no backend private payload exposure; preserve integrity/replay protections.
**Validation:** Gateway tunnel and backend relay rejection audits pass.
**Status:** [~] Source security validated; external/device security review required.

## Phase 190 — UI Redesign
**Objective:** Replace confusing network/gateway labels with clear controls.
**Tasks:** Add Network Preference selector; clearly label Local First, Internet Preferred and advanced Internet Only; add independent gateway-sharing toggle.
**Validation:** Profile UI contains the requested labels and descriptions.
**Status:** [~] Source UI validated.

## Phase 191 — Runtime Indicators
**Objective:** Show the active connection type clearly.
**Tasks:** Preserve/display local LAN, Wi-Fi Direct, mesh hop, WebRTC and gateway states; distinguish limited gateway state.
**Validation:** Call/gateway runtime state plumbing exists; UI/device verification remains required.
**Status:** [~] Source runtime indicators exist; Android UI validation required.

## Phase 192 — Settings Migration
**Objective:** Migrate existing installations without unexpectedly changing behavior.
**Tasks:** Map legacy Internet Only and gateway settings to the new persisted keys; keep legacy compatibility aliases internally.
**Validation:** LocalStore migration logic is present and defaults safely.
**Status:** [~] Source migration validated.

## Phase 193 — Unit Test Matrix
**Objective:** Cover all combinations of preference, local route, WebRTC and gateway availability.
**Tasks:** Add deterministic transport-policy tests for Local First, Internet Preferred, Internet Only and gateway fallback.
**Validation:** New and updated Flutter test sources contain the required matrix cases.
**Status:** [~] Tests added; Flutter execution blocked by missing SDK.

## Phase 194 — Gateway Sharing Matrix
**Objective:** Verify gateway sharing ON/OFF independently from mesh functionality.
**Tasks:** Cover Internet availability, mesh availability and sharing state combinations.
**Validation:** Static source audit confirms sharing is enforced by advertisement and session admission.
**Status:** [~] Source validated; physical matrix required.

## Phase 195 — Multi-Hop Validation
**Objective:** Validate direct and multi-hop LocalLink operation on Android.
**Tasks:** A→B, A→B→C, A→B→C→D over LAN/Wi-Fi Direct with all preference/gateway combinations.
**Validation:** Requires 2–4 physical Android devices.
**Status:** [!] Blocked — no ADB/physical Android devices available.

## Phase 196 — Android Persistence Validation
**Objective:** Confirm preferences survive process/application restart.
**Tasks:** Verify Network Preference and gateway sharing state across restart.
**Validation:** Requires Android runtime/device execution.
**Status:** [!] Blocked — Android/ADB environment unavailable.

## Phase 197 — Android Gateway Runtime Testing
**Objective:** Validate real low-bandwidth, metered, battery and capacity behavior.
**Tasks:** Test bandwidth limits, multiple sessions, budget exhaustion, Internet loss and gateway recovery.
**Validation:** Requires physical Android/network environments.
**Status:** [!] Blocked — physical runtime unavailable.

## Phase 198 — Final Security Validation
**Objective:** Validate gateway confidentiality/integrity protections.
**Tasks:** Verify no media decryption, replay rejection, expired-session rejection and disabled-gateway rejection.
**Validation:** Source audits pass; external/device security testing remains required.
**Status:** [~] Source-level validation complete; external security review required.

## Phase 199 — Final Architecture Audit
**Objective:** Finalize only after deterministic policy, mesh independence, gateway controls and security boundaries are verified.
**Tasks:** Run network-preference audit, call architecture audit and gateway audit; reconcile all device blockers.
**Validation:** Source audits pass; physical acceptance gates remain required before production readiness.
**Status:** [~] Source architecture validated; physical production gates remain blocked.
