#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SERVICE="$ROOT/flutter/android/app/src/main/kotlin/com/sajjad/locallink/LocalLinkTransportService.kt"
MAIN="$ROOT/flutter/android/app/src/main/kotlin/com/sajjad/locallink/MainActivity.kt"
POLICY="$ROOT/flutter/android/app/src/main/kotlin/com/sajjad/locallink/mesh/MeshTransportPolicy.kt"
TEST="$ROOT/flutter/android/app/src/test/kotlin/com/sajjad/locallink/mesh/MeshTransportPolicyTest.kt"

test -f "$SERVICE" && test -f "$MAIN" && test -f "$POLICY" && test -f "$TEST"
grep -Eq 'MeshTransportPolicy\.LAN_PORT|lanTransportPort' "$SERVICE"
grep -Eq 'MeshTransportPolicy\.WIFI_DIRECT_PORT|transportPort' "$SERVICE"
grep -Eq 'MeshTransportPolicy\.LAN_DISCOVERY_PORT|lanDiscoveryPort' "$SERVICE"
grep -q 'lanBroadcastAddresses' "$SERVICE"
grep -Eq 'MeshTransportPolicy\.LAN_ENDPOINT_RETENTION_MS|LAN_ENDPOINT_RETENTION_MS' "$SERVICE"
grep -Eq 'MeshTransportPolicy\.HEARTBEAT_TIMEOUT_MS|HEARTBEAT_TIMEOUT_MS' "$SERVICE"
grep -q 'shouldReplaceExistingTransport' "$POLICY"
grep -q 'MeshRouter' "$SERVICE"
grep -q 'MeshTransport' "$SERVICE"
grep -q 'LocalLinkTransportService.resume' "$MAIN"
# The Flutter layer may keep unrelated server-discovery/WebSocket clients.
# The mesh peer TCP sockets themselves must remain in LocalLinkTransportService.
MESH_DART="$(find "$ROOT/flutter/lib/features/connectivity/data" -type f -name '*.dart' ! -name 'discovery_service.dart' -print)"
if [ -n "$MESH_DART" ] && grep -nE 'RawDatagramSocket|ServerSocket|Socket\.connect' $MESH_DART >/dev/null 2>&1; then
  echo "ERROR: Flutter connectivity mesh layer contains raw peer socket ownership" >&2
  exit 1
fi

echo "MESH-3 static audit: PASS"
