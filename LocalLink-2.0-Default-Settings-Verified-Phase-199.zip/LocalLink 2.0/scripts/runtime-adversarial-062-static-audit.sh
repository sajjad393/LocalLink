#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SERVICE="$ROOT/flutter/android/app/src/main/kotlin/com/sajjad/locallink/LocalLinkTransportService.kt"
FILE_SERVICE="$ROOT/flutter/lib/features/files/data/services/file_transfer_service.dart"
DB_STORE="$ROOT/backend/internal/store/store.go"
HTTP_ATTACH="$ROOT/backend/internal/httpapi/attachments.go"
MESH="$ROOT/flutter/android/app/src/main/kotlin/com/sajjad/locallink/mesh"
HARNESS="$ROOT/flutter/android/app/src/test/kotlin/com/sajjad/locallink/mesh/MeshAdversarialIntegrationHarness.kt"
fail(){ echo "FAIL: $1" >&2; exit 1; }
pass(){ echo "PASS: $1"; }

[ -f "$HARNESS" ] || fail 'adversarial integration harness missing'
grep -q 'route-control-flood' "$HARNESS" || fail 'route flood scenario missing'
grep -q 'route-poisoning' "$HARNESS" || fail 'route poisoning scenario missing'
grep -q 'route-flapping' "$HARNESS" || fail 'route flapping scenario missing'
grep -q 'duplicate-cache-exhaustion' "$HARNESS" || fail 'duplicate cache scenario missing'
grep -q 'session-key-rotation' "$HARNESS" || fail 'session key rotation scenario missing'
grep -q 'multi-hop-resource-pressure' "$HARNESS" || fail 'multi-hop pressure scenario missing'

# Live media must fail rather than enter durable store-and-forward when degraded.
grep -q 'live_media_queued_unexpectedly' "$SERVICE" || fail 'live media queue safety gate missing'
grep -q 'MeshRouteResult.QUEUED' "$SERVICE" || fail 'route result queue handling missing'

# Route changes/failures must keep the routing engine in charge of next-hop selection.
grep -q 'onRouteFailure(destinationNodeId' "$SERVICE" || fail 'route failure callback missing'
grep -q 'routeRecovery.markPeerLost' "$SERVICE" || fail 'route recovery hook missing'

grep -q 'MeshTransportPolicy.LAN' "$SERVICE" || fail 'LAN transport missing'
grep -q 'WIFI_DIRECT' "$SERVICE" || fail 'Wi-Fi Direct transport missing'

grep -q 'startLanTransport' "$SERVICE" || fail 'LAN start/restart hook missing'
grep -q 'startOrStopTransportForConnection' "$SERVICE" || fail 'transport connection state hook missing'

# Resumable downloads use HTTP Range rather than restarting full payloads.
grep -q "request.headers\['Range'\]" "$FILE_SERVICE" || fail 'Flutter download Range resume missing'
grep -q 'Accept-Ranges' "$HTTP_ATTACH" || fail 'backend Range support missing'

# SQLite integrity/retry controls must remain in the release tree.
grep -q 'IntegrityReport' "$DB_STORE" || fail 'SQLite integrity diagnostic missing'
grep -q 'WithTxRetry' "$DB_STORE" || fail 'SQLite transaction retry missing'

grep -q 'MAX_SEEN_PACKETS' "$MESH/MeshLimits.kt" || fail 'bounded duplicate cache limit missing'
grep -q 'SEEN_RETENTION_MS' "$MESH/MeshLimits.kt" || fail 'duplicate cache retention missing'
pass 'PHASE 62 adversarial/integration static controls present'
