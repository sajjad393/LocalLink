#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
MESH="$ROOT/flutter/android/app/src/main/kotlin/com/sajjad/locallink/mesh"
SERVICE="$ROOT/flutter/android/app/src/main/kotlin/com/sajjad/locallink/LocalLinkTransportService.kt"
TRACKER="$MESH/MeshSeenPacketTracker.kt"
LIMITS="$MESH/MeshLimits.kt"
TEST="$ROOT/flutter/android/app/src/test/kotlin/com/sajjad/locallink/mesh/MeshSeenPacketTrackerTest.kt"
for f in "$TRACKER" "$LIMITS" "$SERVICE" "$TEST"; do test -f "$f"; done

grep -q 'sourceNodeId: String, packetId: String' "$TRACKER"
grep -Eq 'put\(key, (now|seenAt)\)' "$TRACKER"
grep -q 'onEvicted' "$TRACKER"
grep -q 'seenAt <= now' "$TRACKER"
grep -q 'const val SEEN_RETENTION_MS = MAX_PACKET_AGE_MS' "$LIMITS"
grep -q 'MAX_EPHEMERAL_SEEN_PACKETS' "$LIMITS"
grep -q 'EPHEMERAL_SEEN_RETENTION_MS' "$LIMITS"
grep -q 'validateForProcessing(packet, incomingPeerId = from)' "$SERVICE"
grep -q 'val tracker = if (ephemeral) seenEphemeralMeshPackets else seenMeshPackets' "$SERVICE"
grep -q 'deleteSeenMeshPacketRecord' "$SERVICE"
grep -q 'seenEphemeralMeshPackets.cleanup(now)' "$SERVICE"
grep -q 'legacy wire packets are now rejected' "$SERVICE"
grep -q 'val audio = decryptCallAudio(encrypted, current.keyBytes, aad) ?: return' "$SERVICE"
grep -q 'val replayKey = "${current.callId}' "$SERVICE"
grep -q 'if (transfer.received\[index\])' "$SERVICE"
! grep -Rqs 'restoreLegacy' "$MESH"
grep -q 'staleAndFutureRestoreEntriesAreRejected' "$TEST"
grep -q 'capacityEvictionNotifiesPersistenceLayer' "$TEST"
echo 'AUDIT-004 static audit: PASS'
