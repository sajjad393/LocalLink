#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
MESH="$ROOT/flutter/android/app/src/main/kotlin/com/sajjad/locallink/mesh"
TRANSPORT="$ROOT/flutter/android/app/src/main/kotlin/com/sajjad/locallink/LocalLinkTransportService.kt"

fail=0

grep -q 'packetId = packetId' "$MESH/MeshPacket.kt" || { echo "FAIL: forwarding must preserve packetId"; fail=1; }
grep -q 'sourceNodeId = sourceNodeId' "$MESH/MeshPacket.kt" || { echo "FAIL: forwarding must preserve sourceNodeId"; fail=1; }
grep -q 'MeshLimits.MAX_HOPS' "$MESH/MeshRouteTable.kt" || { echo "FAIL: route-table hop cap missing"; fail=1; }
grep -q 'MeshSeenPacketTracker' "$TRANSPORT" || { echo "FAIL: duplicate tracker not integrated"; fail=1; }
grep -q 'markSeen(source, id' "$TRANSPORT" || { echo "FAIL: duplicate tracker must use source+packet ID"; fail=1; }
grep -q 'packet.packetId != packetId' "$TRANSPORT" || { echo "FAIL: queue packet ID mismatch guard missing"; fail=1; }
grep -q 'MeshLimits.hasValidHopBudget' "$TRANSPORT" || { echo "FAIL: transport hop-budget guard missing"; fail=1; }

if [[ $fail -ne 0 ]]; then
  exit 1
fi

echo "MESH-2 static audit passed"
