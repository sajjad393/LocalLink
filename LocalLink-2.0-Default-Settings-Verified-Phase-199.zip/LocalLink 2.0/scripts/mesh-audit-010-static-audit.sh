#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SERVICE="$ROOT/flutter/android/app/src/main/kotlin/com/sajjad/locallink/LocalLinkTransportService.kt"
POLICY="$ROOT/flutter/android/app/src/main/kotlin/com/sajjad/locallink/mesh/MeshTransportPolicy.kt"
for f in "$SERVICE" "$POLICY"; do test -f "$f"; done
grep -q 'peerLinks' "$SERVICE"
grep -q 'activePeerConnection' "$SERVICE"
grep -q 'recomputeActivePeer' "$SERVICE"
grep -q 'allPhysicalPeerLinks' "$SERVICE"
grep -q 'peer_transport_fallback' "$SERVICE"
grep -q 'transportPriority' "$POLICY"
grep -q 'LAN' "$POLICY"
grep -q 'WIFI_DIRECT' "$POLICY"
echo 'AUDIT-010 static audit: PASS'
