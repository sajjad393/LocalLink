#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT="${LOCLINK_ACCEPTANCE_EVIDENCE_DIR:-$ROOT/scripts/phase64-evidence}"
EXPECTED="${LOCLINK_ACCEPTANCE_DEVICE_COUNT:-2}"
python3 "$ROOT/scripts/android_acceptance_gate.py" preflight --out "$OUT" --expected-devices "$EXPECTED"
