#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
grep -q 'X-File-Crypto-Version' "$ROOT/backend/internal/httpapi/attachments.go"
grep -q 'crypto_version' "$ROOT/backend/internal/httpapi/attachments.go"
grep -q 'storage_size' "$ROOT/backend/internal/store/store.go"
grep -q 'AttachmentCryptoService' "$ROOT/flutter/lib/features/files/data/services/file_transfer_service.dart"
grep -q 'uploadE2eForMessage' "$ROOT/flutter/lib/features/messaging/data/services/reliable_messaging_service.dart"
grep -q 'uploadE2eForGroupMessage' "$ROOT/flutter/lib/features/groups/data/services/group_messaging_service.dart"
! grep -Rni --include='*.go' 'imageInfo(finalPath)\|createThumbnail(finalPath' "$ROOT/backend/internal/httpapi/attachments.go" | grep 'uploadE2EFile' >/dev/null 2>&1 || { echo 'E2E upload must not use server-side plaintext image decode'; exit 1; }
for f in "$ROOT/flutter/lib/core/models/attachment.dart" "$ROOT/flutter/lib/core/services/local_store.dart" "$ROOT/flutter/lib/features/files/data/services/attachment_crypto_service.dart" "$ROOT/flutter/lib/features/files/data/services/file_transfer_service.dart"; do
  python3 - "$f" <<'PY2'
import sys
text=open(sys.argv[1],encoding='utf-8').read()
stack=[]; pairs={')':'(',']':'[','}':'{'}; quotes=None; esc=False
for i,ch in enumerate(text):
    if quotes:
        if esc: esc=False
        elif ch=='\\': esc=True
        elif ch==quotes: quotes=None
        continue
    if ch in "'\"": quotes=ch; continue
    if ch in '([{': stack.append(ch)
    elif ch in ')]}':
        if not stack or stack.pop()!=pairs[ch]: raise SystemExit(f'unbalanced {sys.argv[1]} at {i}')
if stack or quotes: raise SystemExit(f'unclosed syntax in {sys.argv[1]}')
PY2
done
echo 'AUDIT-016 static audit PASS'
