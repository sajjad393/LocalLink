#!/usr/bin/env bash
set -euo pipefail
root="$(cd "$(dirname "$0")/.." && pwd)"
cd "$root"
fail=0
check(){ if grep -qE "$2" "$1"; then echo "PASS — $3"; else echo "FAIL — $3"; fail=1; fi; }
check flutter/lib/features/calls/data/transport/network_preference.dart "localFirst" "NetworkPreference localFirst"
check flutter/lib/features/calls/data/transport/network_preference.dart "internetPreferred" "NetworkPreference internetPreferred"
check flutter/lib/features/calls/data/transport/network_preference.dart "internetOnly" "advanced Internet Only mode"
check flutter/lib/core/services/local_store.dart "network_preference" "persisted network preference"
check flutter/lib/core/services/local_store.dart "allow_this_device_as_internet_gateway" "persisted gateway sharing control"
check flutter/lib/features/calls/data/transport/call_transport_selection_policy.dart "NetworkPreference.internetPreferred" "Internet Preferred policy"
check flutter/lib/features/calls/data/transport/call_transport_selection_policy.dart "NetworkPreference.localFirst" "Local First policy"
check flutter/lib/features/calls/data/services/call_session_manager.dart "store.allowThisDeviceAsInternetGateway" "call manager gateway permission enforcement"
check flutter/lib/features/calls/data/gateway/internet_gateway_service.dart "store.allowThisDeviceAsInternetGateway" "gateway service permission enforcement"
if grep -q "final allowed = true" flutter/lib/features/calls/data/gateway/internet_gateway_service.dart; then echo "FAIL — hardcoded gateway permission remains"; fail=1; else echo "PASS — no hardcoded gateway permission"; fi
if grep -RInE "useInternetOnly|useInternetGateway|setUseInternetOnly|setUseInternetGateway" flutter/lib --exclude=local_store.dart >/tmp/legacy-gateway-controls.txt; then cat /tmp/legacy-gateway-controls.txt; echo "FAIL — legacy controls leak outside LocalStore compatibility layer"; fail=1; else echo "PASS — legacy controls isolated to LocalStore compatibility"; fi
if grep -q "available_upstream_kbps" flutter/lib/features/calls/data/gateway/gateway_models.dart && grep -q "reserved_upstream_kbps" flutter/lib/features/calls/data/gateway/gateway_models.dart; then echo "PASS — realistic gateway capacity metadata"; else echo "FAIL — capacity metadata missing"; fail=1; fi
if grep -q "Network Preference" flutter/lib/features/account/presentation/screens/profile_screen.dart && grep -q "Allow This Device as Internet Gateway" flutter/lib/features/account/presentation/screens/profile_screen.dart; then echo "PASS — UI labels updated"; else echo "FAIL — UI labels not updated"; fail=1; fi
exit "$fail"
