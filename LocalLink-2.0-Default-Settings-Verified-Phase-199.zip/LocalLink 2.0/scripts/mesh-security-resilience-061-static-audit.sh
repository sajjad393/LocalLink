#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
MESH="$ROOT/flutter/android/app/src/main/kotlin/com/sajjad/locallink/mesh"
SERVICE="$ROOT/flutter/android/app/src/main/kotlin/com/sajjad/locallink/LocalLinkTransportService.kt"
fail(){ echo "FAIL: $1" >&2; exit 1; }
pass(){ echo "PASS: $1"; }

grep -q 'MAX_ROUTE_TABLE_DESTINATIONS = 512' "$MESH/MeshLimits.kt" || fail 'route table destination bound missing'
grep -q 'MAX_ROUTES_PER_DESTINATION = 4' "$MESH/MeshLimits.kt" || fail 'per-destination route bound missing'
grep -q 'MAX_ROUTES_PER_NEXT_HOP = 64' "$MESH/MeshLimits.kt" || fail 'per-next-hop route quota missing'
grep -q 'MAX_ROUTE_ADVERTISEMENT_ROUTES = 128' "$MESH/MeshLimits.kt" || fail 'advertisement route bound missing'
grep -q 'MAX_ROUTE_ADVERTISEMENTS_PER_PEER = 30' "$MESH/MeshLimits.kt" || fail 'advertisement rate bound missing'
grep -q 'routeAdvertisementPolicy.evaluate' "$SERVICE" || fail 'route advertisement replay/rate admission missing'
grep -q 'MeshRouteAdvertisementAuthenticator.verify' "$SERVICE" || fail 'route control authentication missing'
grep -q 'route_withdrawal_rejected' "$SERVICE" || fail 'route withdrawal rejection missing'
grep -q 'routeStabilityPolicy.beforeChange' "$SERVICE" || fail 'route flap hold-down missing'
grep -q 'MAX_ROUTE_VERSION_FUTURE_SKEW_MS' "$SERVICE" || fail 'route version future-skew validation missing'
grep -q 'MAX_ROUTE_VERSION_ADVANCE_MS' "$SERVICE" || fail 'route version jump validation missing'
grep -q 'MeshTransportSessionKeyPolicy.currentEpoch' "$SERVICE" || fail 'rolling session key epoch missing'
grep -q 'put("key_epoch"' "$SERVICE" || fail 'session key epoch not carried on wire'
grep -q 'hopIdentityAad(self, peer.peerId, keyEpoch)' "$SERVICE" || fail 'key epoch not bound to AEAD AAD'
grep -q 'routeAdvertisementSequence' "$SERVICE" || fail 'route advertisement sequence missing'
grep -q 'routeAdvertisementSessionId' "$SERVICE" || fail 'route advertisement session missing'
pass 'PHASE 61 mesh security/resilience static controls present'
