#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TRACKER="$ROOT/flutter/android/app/src/main/kotlin/com/sajjad/locallink/mesh/MeshSeenPacketTracker.kt"
RECOVERY="$ROOT/flutter/android/app/src/main/kotlin/com/sajjad/locallink/mesh/MeshRouteRecoveryTracker.kt"
LIMITS="$ROOT/flutter/android/app/src/main/kotlin/com/sajjad/locallink/mesh/MeshLimits.kt"
HARNESS="$ROOT/flutter/android/app/src/test/kotlin/com/sajjad/locallink/mesh/MeshChaosResilienceHarness.kt"

for f in "$TRACKER" "$RECOVERY" "$LIMITS" "$HARNESS"; do test -f "$f"; done
grep -q 'cleanupIntervalMs' "$TRACKER"
grep -q 'TreeMap' "$TRACKER"
grep -q 'MAX_ROUTE_RECOVERY_DESTINATIONS' "$LIMITS"
grep -q 'affected.take(maxEntries)' "$RECOVERY"
grep -q '10/10 PASS' "$HARNESS"
! grep -q 'Thread.sleep' "$HARNESS"
! grep -R -q 'println' "$ROOT/flutter/android/app/src/main/kotlin/com/sajjad/locallink/mesh/MeshSeenPacketTracker.kt" "$ROOT/flutter/android/app/src/main/kotlin/com/sajjad/locallink/mesh/MeshRouteRecoveryTracker.kt"
echo 'PHASE 66 chaos/reliability static audit: PASS'
