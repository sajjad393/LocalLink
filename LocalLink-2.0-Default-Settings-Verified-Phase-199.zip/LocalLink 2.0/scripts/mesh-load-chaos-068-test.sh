#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
MESH="$ROOT/flutter/android/app/src/main/kotlin/com/sajjad/locallink/mesh"
DIRECT="$ROOT/flutter/android/app/src/main/kotlin/com/sajjad/locallink/DirectFileTransferPolicy.kt"
HARNESS="$ROOT/flutter/android/app/src/test/kotlin/com/sajjad/locallink/mesh/MeshLoadChaosHarness.kt"
OUT="$ROOT/.phase68-load-chaos-harness"
trap 'rm -rf "$OUT"' EXIT

command -v kotlinc >/dev/null 2>&1 || { echo "BLOCKED: kotlinc unavailable" >&2; exit 2; }
command -v java >/dev/null 2>&1 || { echo "BLOCKED: java unavailable" >&2; exit 2; }
rm -rf "$OUT"; mkdir -p "$OUT"

kotlinc \
  "$MESH/MeshLimits.kt" \
  "$MESH/MeshIdPolicy.kt" \
  "$MESH/MeshRoute.kt" \
  "$MESH/MeshRouteTable.kt" \
  "$MESH/MeshRouteAdvertisementPolicy.kt" \
  "$MESH/MeshRouteStabilityPolicy.kt" \
  "$MESH/MeshTransportSessionKeyPolicy.kt" \
  "$MESH/MeshRouteRecoveryTracker.kt" \
  "$MESH/MeshSeenPacketTracker.kt" \
  "$DIRECT" \
  "$HARNESS" \
  -include-runtime -d "$OUT/harness.jar"

java -Xms64m -Xmx512m -jar "$OUT/harness.jar"
