#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
HARNESS="$ROOT/flutter/android/app/src/test/kotlin/com/sajjad/locallink/mesh/MeshLoadChaosHarness.kt"
TEST="$ROOT/flutter/android/app/src/test/kotlin/com/sajjad/locallink/mesh/MeshLoadChaosHarnessTest.kt"
RUNNER="$ROOT/scripts/mesh-load-chaos-068-test.sh"

for path in "$HARNESS" "$TEST" "$RUNNER" "$ROOT/LOCAL_LINK_TODO.md"; do
  test -f "$path" || { echo "FAIL missing: ${path#$ROOT/}" >&2; exit 1; }
done

grep -q 'SEED' "$HARNESS"
grep -q '120_000' "$HARNESS"
grep -q '80_000' "$HARNESS"
grep -q 'WORKERS' "$HARNESS"
grep -q 'MAX_ROUTE_TABLE_DESTINATIONS' "$HARNESS"
grep -q 'MAX_SEEN_PACKETS' "$HARNESS"
grep -q 'MAX_ROUTE_RECOVERY_DESTINATIONS' "$HARNESS"
grep -q 'harness.jar' "$RUNNER"
grep -q 'MeshLoadChaosHarness.main' "$TEST"

echo "PHASE 68 STATIC AUDIT: PASS"
