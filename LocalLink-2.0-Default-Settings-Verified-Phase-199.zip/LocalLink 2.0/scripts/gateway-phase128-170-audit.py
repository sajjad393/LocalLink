#!/usr/bin/env python3
from pathlib import Path
import re, sys
root=Path(__file__).resolve().parents[1]
checks=[]
def must(label, ok): checks.append((label, bool(ok)))
svc=(root/'flutter/lib/features/calls/data/gateway/internet_gateway_service.dart').read_text()
models=(root/'flutter/lib/features/calls/data/gateway/gateway_models.dart').read_text()
backend=(root/'backend/internal/httpapi/gateway.go').read_text()
ws=(root/'backend/internal/httpapi/websocket.go').read_text()
native=(root/'flutter/android/app/src/main/kotlin/com/sajjad/locallink/LocalLinkTransportService.kt').read_text()
app=(root/'flutter/lib/app/app_dependencies.dart').read_text()
bloc=(root/'flutter/lib/features/calls/bloc/gateway_bloc.dart').read_text()
profile=(root/'flutter/lib/features/account/presentation/screens/profile_screen.dart').read_text()
for f in ['gateway_runtime.dart','gateway_budget_manager.dart','gateway_bandwidth_manager.dart','gateway_traffic_scheduler.dart','gateway_route_selector.dart','gateway_health_monitor.dart','gateway_tunnel.dart']:
    must(f'helper {f} present', (root/'flutter/lib/features/calls/data/gateway'/f).exists())
must('gateway permission dependency removed from source', not any('allowInternetGateway' in p.read_text(errors='ignore') or 'allow_internet_gateway' in p.read_text(errors='ignore') for p in (root/'flutter/lib').rglob('*.dart')))
must('gateway internet status uses validated capability', "caps['internet_validated'] == true" in svc)
must('gateway advertisement includes bandwidth/budget', all(x in models for x in ['upstream_kbps','downstream_kbps','packet_loss_percent','budget_remaining_bytes']))
must('dynamic route scoring exists', 'return healthScore * .35' in (root/'flutter/lib/features/calls/data/gateway/gateway_route_selector.dart').read_text())
must('real gateway tunnel uses data channel', 'createDataChannel' in (root/'flutter/lib/features/calls/data/gateway/gateway_tunnel.dart').read_text())
must('mesh gateway advertisement delivery exists', 'gateway_advertisement_received' in native)
must('validated Android network state exists', 'NET_CAPABILITY_VALIDATED' in native)
must('backend tunnel signal is allowed', 'gateway_tunnel_signal' in ws and 'handleGatewayTunnelSignal' in backend)
gateway_packet_fn = backend[backend.find('func (a *API) handleGatewayPacket'):backend.find('func (a *API) handleGatewayTunnelSignal')]
must('backend rejects media relay', 'backend_media_relay_disabled' in backend and 'a.hub.SendTo(destination' not in gateway_packet_fn)
must('auto manager wired', 'gatewayAutoManager' in app and 'GatewayAutoManager' in app)
must('GatewayBloc consumes runtime state', 'GatewayRuntimeChanged' in bloc and 'service.runtime' in bloc)
must('UI removes act-as-gateway toggle', 'Allow this device to act as Gateway' not in profile)
must('single call transport architecture preserved', 'InternetGatewayService' in svc and (root/'flutter/lib/features/calls/data/transport/call_transport.dart').exists())
must('gateway unit tests added', (root/'flutter/test/gateway_phase128_170_test.dart').exists())
for label,ok in checks: print(('PASS' if ok else 'FAIL')+' — '+label)
sys.exit(0 if all(ok for _,ok in checks) else 1)
