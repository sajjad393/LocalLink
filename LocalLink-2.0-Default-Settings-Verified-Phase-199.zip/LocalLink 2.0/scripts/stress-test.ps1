param(
  [string]$BaseUrl = $env:LOCALLINK_BASE_URL,
  [string]$DeviceId = $env:LOCALLINK_DEVICE_ID,
  [string]$DeviceToken = $env:LOCALLINK_DEVICE_TOKEN,
  [string]$RecipientId = $env:LOCALLINK_RECIPIENT_ID,
  [int]$Count = $(if ($env:LOCALLINK_MESSAGE_COUNT) {[int]$env:LOCALLINK_MESSAGE_COUNT} else {130})
)
if ([string]::IsNullOrWhiteSpace($BaseUrl) -or [string]::IsNullOrWhiteSpace($DeviceId) -or [string]::IsNullOrWhiteSpace($DeviceToken) -or [string]::IsNullOrWhiteSpace($RecipientId)) {
  throw "Set LOCALLINK_BASE_URL, LOCALLINK_DEVICE_ID, LOCALLINK_DEVICE_TOKEN and LOCALLINK_RECIPIENT_ID."
}
$env:LOCALLINK_BASE_URL = $BaseUrl
$env:LOCALLINK_DEVICE_ID = $DeviceId
$env:LOCALLINK_DEVICE_TOKEN = $DeviceToken
$env:LOCALLINK_RECIPIENT_ID = $RecipientId
$env:LOCALLINK_MESSAGE_COUNT = $Count
python scripts/stress-test.py
