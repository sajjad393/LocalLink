#!/usr/bin/env bash
set -euo pipefail

ADB=${ADB:-adb}

if ! command -v "$ADB" >/dev/null 2>&1; then
  echo "adb is required" >&2
  exit 1
fi

mapfile -t DEVICES < <("$ADB" devices | awk 'NR>1 && $2=="device" {print $1}')
if [[ ${#DEVICES[@]} -lt 2 ]]; then
  echo "Connect at least 2 Android devices with USB debugging enabled." >&2
  "$ADB" devices
  exit 2
fi

echo "LocalLink Android mesh diagnostic"
echo "Devices detected: ${#DEVICES[@]}"
echo

for serial in "${DEVICES[@]}"; do
  echo "===== $serial ====="
  "$ADB" -s "$serial" shell getprop ro.product.manufacturer
  "$ADB" -s "$serial" shell getprop ro.product.model
  "$ADB" -s "$serial" shell getprop ro.build.version.release
  "$ADB" -s "$serial" shell getprop ro.build.version.sdk
  echo "Battery optimization state (best-effort):"
  "$ADB" -s "$serial" shell dumpsys deviceidle whitelist | grep -F 'com.sajjad.locallink' || true
  echo
  echo "Foreground transport service:"
  "$ADB" -s "$serial" shell dumpsys activity services com.sajjad.locallink/.LocalLinkTransportService | head -40 || true
  echo "Recent LocalLink transport log lines:"
  "$ADB" -s "$serial" logcat -d -t 300 | grep -E 'LocalLink|WifiP2p|WiFi|Fgs' | tail -60 || true
  echo
done

echo "Use the Wi-Fi Direct screen in LocalLink to record:"
echo "  peer_count, queued_packets, queued_bytes, packets_sent, packets_received, reconnect_attempts, send_failures"
echo "Run this script before and after each failure/reconnect scenario."
