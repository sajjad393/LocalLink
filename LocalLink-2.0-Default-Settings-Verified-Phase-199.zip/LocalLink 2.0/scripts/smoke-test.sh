#!/usr/bin/env bash
set -euo pipefail

BASE_URL="${LOCALLINK_BASE_URL:-http://127.0.0.1:8080}"

printf 'Health: '
curl -fsS "$BASE_URL/health" >/dev/null && echo OK
printf 'Status: '
curl -fsS "$BASE_URL/api/v1/status" >/dev/null && echo OK

echo "Backend smoke test passed. Device/message authenticated tests require a registered device."
