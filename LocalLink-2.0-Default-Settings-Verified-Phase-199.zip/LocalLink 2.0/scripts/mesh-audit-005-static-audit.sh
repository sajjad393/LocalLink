#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
MESH="$ROOT/flutter/android/app/src/main/kotlin/com/sajjad/locallink/mesh"
PACKET="$MESH/MeshPacket.kt"
ROUTER="$MESH/MeshRouter.kt"
LIMITS="$MESH/MeshLimits.kt"
SERVICE="$ROOT/flutter/android/app/src/main/kotlin/com/sajjad/locallink/LocalLinkTransportService.kt"
TABLE="$MESH/MeshRouteTable.kt"
TEST="$ROOT/flutter/android/app/src/test/kotlin/com/sajjad/locallink/mesh/MeshTtlTest.kt"
for f in "$PACKET" "$ROUTER" "$LIMITS" "$SERVICE" "$TEST"; do test -f "$f"; done

grep -q 'const val MAX_HOPS = 8' "$LIMITS"
grep -q 'const val MAX_TTL = 8' "$LIMITS"
grep -q 'fun isValidInitialTtl' "$LIMITS"
grep -q 'fun canForward' "$LIMITS"
grep -q 'return ttl + hopCount <= maxHops' "$LIMITS"
grep -q 'ttl = nextTtl' "$PACKET"
grep -q 'hopCount = nextHopCount' "$PACKET"
grep -q 'require(MeshLimits.isValidInitialTtl(ttl))' "$PACKET"
grep -q 'mesh path length does not match hop count' "$PACKET"
grep -q 'it.hopCount <= packet.ttl' "$ROUTER"
grep -q 'incomingPeerId' "$ROUTER"
grep -q 'path.lastOrNull() != incoming' "$ROUTER"
grep -q 'MeshLimits.isWithinPacketLifetime(packet.createdAt)' "$ROUTER"
grep -q 'route.hopCount !in 1..MeshLimits.MAX_HOPS' "$TABLE"
grep -q 'packetExpiryAt(packet.createdAt)' "$SERVICE"
grep -q 'MeshLimits.isWithinPacketLifetime(packet.createdAt, now)' "$SERVICE"
grep -q 'hop_or_age_invalid' "$SERVICE"
grep -q 'forwardingConsumesExactlyOneTtlAndOneHop' "$TEST"
grep -q 'packetPathLengthTracksConsumedForwardingHops' "$TEST"
grep -q 'parserRejectsInconsistentTtlHopOrPathState' "$TEST"
grep -q 'routerRejectsIncomingPacketWhosePathDoesNotEndAtPreviousHop' "$ROOT/flutter/android/app/src/test/kotlin/com/sajjad/locallink/mesh/MeshRoutingTest.kt"

# The configured maximum may be used only when constructing a brand-new origin packet.
# Forwarding itself must use the decremented value calculated in MeshPacket.copyForForwarding.
! grep -n -A8 -B8 --include='*.kt' 'ttl = meshPacketTtl' "$ROOT/flutter/android/app/src/main/kotlin/com/sajjad/locallink/LocalLinkTransportService.kt" | grep -q 'copyForForwarding' || true
! grep -n -A12 -B4 'ttl = meshPacketTtl' "$PACKET" || true

# Forwarding must remain centralized through copyForForwarding.
COUNT=$(grep -Rhs --include='*.kt' 'copyForForwarding' "$MESH" | wc -l)
test "$COUNT" -ge 2

echo 'AUDIT-005 static audit: PASS'
