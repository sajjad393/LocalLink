#!/usr/bin/env bash
set -euo pipefail
root="$(cd "$(dirname "$0")/.." && pwd)"
test -f "$root/backend/internal/httpapi/admin_auth.go"
grep -q 'adminSessionTTL' "$root/backend/internal/httpapi/admin_auth.go"
grep -q 'admin_accounts' "$root/backend/internal/httpapi/admin_auth.go"
grep -q 'admin_sessions' "$root/backend/internal/httpapi/admin_auth.go"
grep -q 'adminPermission' "$root/backend/internal/httpapi/admin_auth.go"
grep -q 'adminAudit' "$root/backend/internal/httpapi/admin_auth.go"
! grep -RIn --exclude-dir=.git 'LOCALLINK_ADMIN_TOKEN=' "$root/README.md" "$root/docs" "$root/backend/.env.example"
echo 'AUDIT-023 static audit: PASS'
