#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SERVICE="$ROOT/flutter/android/app/src/main/kotlin/com/sajjad/locallink/LocalLinkTransportService.kt"
ROUTER="$ROOT/flutter/android/app/src/main/kotlin/com/sajjad/locallink/mesh/MeshRouter.kt"
POLICY="$ROOT/flutter/android/app/src/main/kotlin/com/sajjad/locallink/mesh/MeshFinalRecipientPolicy.kt"
TEST="$ROOT/flutter/android/app/src/test/kotlin/com/sajjad/locallink/mesh/MeshFinalRecipientDeliveryTest.kt"
for f in "$SERVICE" "$ROUTER" "$POLICY" "$TEST"; do test -f "$f"; done

# Application delivery must be reachable only from the router's LOCAL_DELIVERY result.
COUNT="$(grep -c 'MeshRouteResult.LOCAL_DELIVERY -> deliverLocalPacket(packet)' "$SERVICE")"
test "$COUNT" -eq 1

grep -q 'private fun deliverLocalPacket(packet: MeshPacket)' "$SERVICE"
grep -q 'MeshFinalRecipientPolicy.isFinalRecipient' "$SERVICE"
grep -q 'destinationNodeId != localNodeId' "$POLICY" || grep -q 'destination != local' "$POLICY"
grep -q 'destinationNodeId == self' "$ROUTER"
grep -q 'MeshFinalRecipientPolicy.isFinalRecipient' "$ROUTER"
grep -q 'aToBToCToDOnlyDCanReturnLocalDelivery' "$TEST"

grep -q 'packet.sourceNodeId' "$SERVICE"
grep -q 'packet.destinationNodeId' "$SERVICE"

grep -q 'origin_auth_failed' "$SERVICE"

grep -q 'mesh_delivered' "$SERVICE"

echo 'AUDIT-012 static audit: PASS'
