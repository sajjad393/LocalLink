#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
fail=0
require() { if ! grep -Fq -- "$1" "$2"; then echo "MISSING: $1 in $2"; fail=1; fi; }
require "protectedPartSuffix = '.enc.part'" "$ROOT/flutter/lib/core/security/sensitive_file_protection_service.dart"
require "plaintextPartSuffix = '.plain.part'" "$ROOT/flutter/lib/core/security/sensitive_file_protection_service.dart"
require "cleanupSensitiveArtifacts" "$ROOT/flutter/lib/core/security/sensitive_file_protection_service.dart"
require "local file is outside protected application storage" "$ROOT/flutter/lib/core/security/sensitive_file_protection_service.dart"
require "final protectedPath = await files.protectLegacyLocalFile(path!)" "$ROOT/flutter/lib/features/messaging/data/services/reliable_messaging_service.dart"
require "cleanupSensitiveArtifacts()" "$ROOT/flutter/lib/app/local_link_app.dart"
require "Native direct-file delivery creates a plaintext final file only until" "$ROOT/flutter/android/app/src/main/kotlin/com/sajjad/locallink/LocalLinkTransportService.kt"
if grep -RIn --include='*.dart' --include='*.kt' --exclude-dir='.dart_tool' '\.view-.*deleteLocalFile' "$ROOT/flutter" >/dev/null; then :; fi
if [[ $fail -ne 0 ]]; then exit 1; fi
echo "PHASE 60 sensitive-file lifecycle static audit: PASS"
