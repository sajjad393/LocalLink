#!/usr/bin/env bash
set -e
printf 'LocalLink - LAN information\n\n'
if command -v ip >/dev/null 2>&1; then
  ip -4 addr show
  printf '\nDefault route:\n'
  ip route | grep '^default' || true
else
  ifconfig || true
fi
printf '\nStart a temporary test server with:\n'
printf 'python3 -m http.server 8080 --bind 0.0.0.0\n'
