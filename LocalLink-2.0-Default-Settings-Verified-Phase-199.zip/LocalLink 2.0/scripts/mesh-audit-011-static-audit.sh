#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SERVICE="$ROOT/flutter/android/app/src/main/kotlin/com/sajjad/locallink/LocalLinkTransportService.kt"
RECOVERY="$ROOT/flutter/android/app/src/main/kotlin/com/sajjad/locallink/mesh/MeshRouteRecoveryTracker.kt"
TABLE="$ROOT/flutter/android/app/src/main/kotlin/com/sajjad/locallink/mesh/MeshRouteTable.kt"
for f in "$SERVICE" "$RECOVERY" "$TABLE"; do test -f "$f"; done
grep -q 'ROUTE_ADVERTISEMENT_INTERVAL_MS' "$SERVICE"
grep -q 'routeAdvertisementLastSentAt' "$SERVICE"
grep -q 'broadcastRouteAdvertisement()' "$SERVICE"
grep -q 'handleRoutesAfterPeerDisconnect' "$SERVICE"
grep -q 'route_recovery_started' "$SERVICE"
grep -q 'broadcastRouteWithdrawal' "$SERVICE"
grep -q 'failedNextHop != senderPeerId' "$SERVICE"
grep -q 'markPeerLost' "$RECOVERY"
grep -q 'markRecovered' "$RECOVERY"
grep -q 'prune' "$RECOVERY"
grep -q 'routeTable.removeVia' "$SERVICE"
echo 'AUDIT-011 static audit: PASS'
