$ErrorActionPreference = 'Stop'
$adb = if ($env:ADB) { $env:ADB } else { 'adb' }

$devices = & $adb devices | Select-Object -Skip 1 | Where-Object { $_ -match '\tdevice$' } | ForEach-Object { ($_ -split '\t')[0] }
if (-not $devices -or $devices.Count -lt 2) {
  Write-Error 'Connect at least 2 Android devices with USB debugging enabled.'
}

Write-Host "LocalLink Android mesh diagnostic"
Write-Host "Devices detected: $($devices.Count)"
Write-Host ''

foreach ($serial in $devices) {
  Write-Host "===== $serial ====="
  & $adb -s $serial shell getprop ro.product.manufacturer
  & $adb -s $serial shell getprop ro.product.model
  & $adb -s $serial shell getprop ro.build.version.release
  & $adb -s $serial shell getprop ro.build.version.sdk
  Write-Host 'Battery optimization state (best-effort):'
  & $adb -s $serial shell dumpsys deviceidle whitelist | Select-String 'com.sajjad.locallink'
  Write-Host 'Foreground transport service:'
  & $adb -s $serial shell dumpsys activity services com.sajjad.locallink/.LocalLinkTransportService | Select-Object -First 40
  Write-Host 'Recent LocalLink transport log lines:'
  & $adb -s $serial logcat -d -t 300 | Select-String 'LocalLink|WifiP2p|WiFi|Fgs' | Select-Object -Last 60
  Write-Host ''
}

Write-Host 'Use the LocalLink Wi-Fi Direct screen to record:'
Write-Host '  peer_count, queued_packets, queued_bytes, packets_sent, packets_received, reconnect_attempts, send_failures'
