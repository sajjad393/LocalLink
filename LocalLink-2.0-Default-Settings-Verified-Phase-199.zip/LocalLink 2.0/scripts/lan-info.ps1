Write-Host "LocalLink - LAN information"
Write-Host ""
Get-NetIPConfiguration |
    Where-Object { $_.IPv4Address -and $_.NetAdapter.Status -eq 'Up' } |
    Select-Object InterfaceAlias,
        @{Name='IPv4';Expression={$_.IPv4Address.IPAddress}},
        @{Name='Gateway';Expression={$_.IPv4DefaultGateway.NextHop}},
        @{Name='DNS';Expression={($_.DNSServer.ServerAddresses -join ', ')}} |
    Format-Table -AutoSize

Write-Host ""
Write-Host "Use the IPv4 address of the adapter connected to the LocalLink router."
Write-Host "Then test from each phone: http://<LAPTOP-IP>:8080"
