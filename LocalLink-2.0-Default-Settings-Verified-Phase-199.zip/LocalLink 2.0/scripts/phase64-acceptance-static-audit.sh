#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
for f in \
  "$ROOT/scripts/android_acceptance_gate.py" \
  "$ROOT/scripts/android-acceptance-preflight.sh" \
  "$ROOT/scripts/android-acceptance-capture.sh" \
  "$ROOT/scripts/android-acceptance-gate.sh" \
  "$ROOT/scripts/android-acceptance-test.ps1" \
  "$ROOT/PHASE_64_REAL_ANDROID_MULTI_DEVICE_ACCEPTANCE.md" \
  "$ROOT/PHASE_64_CHECKLIST.md" \
  "$ROOT/PHASE_64_EVIDENCE_TEMPLATE/results.json"; do
  test -f "$f"
done
python3 -m py_compile "$ROOT/scripts/android_acceptance_gate.py"
bash -n "$ROOT/scripts/android-acceptance-preflight.sh"
bash -n "$ROOT/scripts/android-acceptance-capture.sh"
bash -n "$ROOT/scripts/android-acceptance-gate.sh"
python3 - <<'PY' "$ROOT/PHASE_64_EVIDENCE_TEMPLATE/results.json"
import json, sys
rows=json.load(open(sys.argv[1], encoding='utf-8'))['scenarios']
assert len(rows)==18
assert all(r['status']=='BLOCKED' for r in rows)
assert all(r['devices']==[] and r['evidence']==[] for r in rows)
PY
# No scenario is allowed to be silently PASSed in the template.
! grep -q '"status": "PASS"' "$ROOT/PHASE_64_EVIDENCE_TEMPLATE/results.json"
echo 'PHASE 64 acceptance static audit: PASS'
