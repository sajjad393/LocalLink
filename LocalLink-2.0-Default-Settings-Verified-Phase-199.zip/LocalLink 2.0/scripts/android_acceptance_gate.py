#!/usr/bin/env python3
"""LocalLink PHASE 64 Android/multi-device acceptance harness.

This tool is intentionally fail-closed: it never marks a scenario PASS based on
source inspection. Physical-device scenarios require explicit PASS evidence.
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import os
from pathlib import Path
import re
import subprocess
import sys
from typing import Any

PACKAGE = "com.sajjad.locallink"
MIN_DEVICES = 2
SCENARIOS = [
    ("S01", "Two-device LAN discovery"),
    ("S02", "Direct encrypted message A↔B"),
    ("S03", "Three-node A→B→C routed message"),
    ("S04", "Four-node A→B→C→D routed message"),
    ("S05", "Replay and duplicate rejection on physical devices"),
    ("S06", "Route recovery after intermediate-node loss"),
    ("S07", "LAN loss with Wi-Fi Direct fallback"),
    ("S08", "Wi-Fi Direct disconnect/reconnect recovery"),
    ("S09", "50 MiB encrypted file transfer and resume"),
    ("S10", "Sensitive-file lifecycle leaves no stale plaintext"),
    ("S11", "One-to-one voice call"),
    ("S12", "Voice call survives route change"),
    ("S13", "One-to-one video call and route recovery"),
    ("S14", "Background/locked-screen message and call notification"),
    ("S15", "Doze/background transport continuity"),
    ("S16", "Process/service restart recovery"),
    ("S17", "SQLite restart/integrity recovery"),
    ("S18", "Queue/resource exhaustion remains bounded"),
]


def now() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat()


def run(cmd: list[str], timeout: int = 30) -> tuple[int, str]:
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    except (OSError, subprocess.TimeoutExpired) as exc:
        return 127, str(exc)
    return p.returncode, p.stdout.strip() + ("\n" + p.stderr.strip() if p.stderr.strip() else "")


def adb(adb: str, serial: str, *args: str, timeout: int = 30) -> str:
    code, out = run([adb, "-s", serial, *args], timeout=timeout)
    if code != 0:
        raise RuntimeError(f"adb failed ({code}) for {serial}: {out}")
    return out


def device_serials(adb_path: str) -> list[str]:
    code, out = run([adb_path, "devices"])
    if code != 0:
        raise RuntimeError(out)
    return [line.split("\t", 1)[0] for line in out.splitlines() if "\tdevice" in line]


def package_info(adb_path: str, serial: str) -> dict[str, str]:
    text = adb(adb_path, serial, "shell", "dumpsys", "package", PACKAGE, timeout=15)
    version_code = re.search(r"versionCode=(\d+)", text)
    version_name = re.search(r"versionName=([^\s]+)", text)
    return {
        "version_code": version_code.group(1) if version_code else "unknown",
        "version_name": version_name.group(1) if version_name else "unknown",
    }


def collect_device(adb_path: str, serial: str, out_dir: Path) -> dict[str, Any]:
    props = {}
    for key in ("ro.product.manufacturer", "ro.product.model", "ro.build.version.release", "ro.build.version.sdk"):
        props[key] = adb(adb_path, serial, "shell", "getprop", key)

    info = package_info(adb_path, serial)
    apk_path = "unknown"
    apk_sha256 = "unknown"
    try:
        apk_path = adb(adb_path, serial, "shell", "pm", "path", PACKAGE).splitlines()[0].removeprefix("package:").strip()
        if apk_path:
            try:
                apk_sha256 = adb(adb_path, serial, "shell", "sha256sum", apk_path).split()[0]
            except Exception:
                apk_sha256 = adb(adb_path, serial, "shell", "toybox", "sha256sum", apk_path).split()[0]
    except Exception as exc:
        apk_sha256 = f"collection-error:{exc}"
    commands = {
        "wifi_status": ["shell", "cmd", "wifi", "status"],
        "ip_addr": ["shell", "ip", "-4", "addr"],
        "ip_route": ["shell", "ip", "route"],
        "device_idle": ["shell", "dumpsys", "deviceidle"],
        "connectivity": ["shell", "dumpsys", "connectivity"],
        "wifi_p2p": ["shell", "dumpsys", "wifi"],
        "transport_service": ["shell", "dumpsys", "activity", "services", f"{PACKAGE}/.LocalLinkTransportService"],
        "package_permissions": ["shell", "dumpsys", "package", PACKAGE],
    }
    captured: dict[str, str] = {}
    for name, args in commands.items():
        try:
            captured[name] = adb(adb_path, serial, *args, timeout=30)
        except Exception as exc:
            captured[name] = f"[collection-error] {exc}"

    serial_dir = out_dir / serial
    serial_dir.mkdir(parents=True, exist_ok=True)
    for name, value in captured.items():
        (serial_dir / f"{name}.txt").write_text(value + "\n", encoding="utf-8")

    result = {
        "serial": serial,
        "captured_at": now(),
        "properties": props,
        "package": info | {"apk_path": apk_path, "apk_sha256": apk_sha256},
        "has_local_link_process": PACKAGE in captured["transport_service"],
        "nearby_wifi_granted": "android.permission.NEARBY_WIFI_DEVICES: granted=true" in captured["package_permissions"],
        "notifications_granted": "android.permission.POST_NOTIFICATIONS: granted=true" in captured["package_permissions"],
        "acceptance_evidence_dir": str(serial_dir),
    }
    (serial_dir / "device.json").write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    return result


def init_evidence(root: Path) -> None:
    root.mkdir(parents=True, exist_ok=True)
    rows = [
        {
            "id": sid,
            "name": name,
            "status": "BLOCKED",
            "devices": [],
            "started_at": None,
            "ended_at": None,
            "evidence": [],
            "notes": "Physical execution required; replace BLOCKED with PASS only after observing the expected result on the named devices.",
        }
        for sid, name in SCENARIOS
    ]
    data = {
        "phase": 64,
        "created_at": now(),
        "project": PACKAGE,
        "policy": "Fail closed: source/static checks cannot satisfy physical-device acceptance scenarios.",
        "scenarios": rows,
    }
    (root / "results.json").write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    (root / "README.md").write_text(
        "# LocalLink PHASE 64 evidence\n\n"
        "Run `python3 scripts/android_acceptance_gate.py preflight --out <dir>` with 2–4 physical Android devices.\n"
        "Execute every scenario in `results.json`, attach logs/screenshots/video references, then set each status explicitly to `PASS`.\n"
        "The gate rejects any missing, BLOCKED, or non-PASS scenario.\n",
        encoding="utf-8",
    )


def gate(root: Path) -> int:
    results_file = root / "results.json"
    if not results_file.is_file():
        print(f"FAIL: missing {results_file}", file=sys.stderr)
        return 1
    data = json.loads(results_file.read_text(encoding="utf-8"))
    rows = {row.get("id"): row for row in data.get("scenarios", [])}
    failures: list[str] = []
    for sid, name in SCENARIOS:
        row = rows.get(sid)
        if not row:
            failures.append(f"{sid}: missing")
            continue
        if row.get("status") != "PASS":
            failures.append(f"{sid}: status={row.get('status')!r}")
            continue
        if not row.get("devices"):
            failures.append(f"{sid}: no devices listed")
        if not row.get("evidence"):
            failures.append(f"{sid}: no evidence references")
        for ev in row.get("evidence", []):
            path = root / ev
            if not path.exists():
                failures.append(f"{sid}: missing evidence {ev}")
    if failures:
        print("PHASE 64 physical acceptance gate: BLOCKED/FAIL")
        for item in failures:
            print(f"  - {item}")
        return 2
    print(f"PHASE 64 physical acceptance gate: PASS ({len(SCENARIOS)}/{len(SCENARIOS)} scenarios)")
    return 0


def preflight(adb_path: str, out: Path, expected_devices: int | None) -> int:
    try:
        serials = device_serials(adb_path)
    except Exception as exc:
        print(f"BLOCKED: adb unavailable: {exc}", file=sys.stderr)
        return 2
    if len(serials) < MIN_DEVICES:
        print(f"BLOCKED: need at least {MIN_DEVICES} physical Android devices; found {len(serials)}")
        return 2
    if expected_devices is not None and len(serials) < expected_devices:
        print(f"BLOCKED: requested at least {expected_devices} devices; found {len(serials)}")
        return 2

    out.mkdir(parents=True, exist_ok=True)
    devices = [collect_device(adb_path, s, out / "devices") for s in serials]
    manifest = {"captured_at": now(), "device_count": len(devices), "devices": devices}
    (out / "preflight.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    versions = {(d["package"]["version_code"], d["package"]["version_name"]) for d in devices}
    hashes = {d["package"]["apk_sha256"] for d in devices if re.fullmatch(r"[0-9a-fA-F]{64}", d["package"]["apk_sha256"] or "")}
    if len(versions) != 1:
        print("BLOCKED: installed LocalLink version differs across devices", file=sys.stderr)
        return 2
    if hashes and len(hashes) != 1:
        print("BLOCKED: installed LocalLink APK hash differs across devices", file=sys.stderr)
        return 2
    missing = [d["serial"] for d in devices if not d["has_local_link_process"]]
    if missing:
        print("WARNING: LocalLink transport service is not currently observed on: " + ", ".join(missing))
    print(f"PHASE 64 device preflight: PASS ({len(devices)} device(s), LocalLink {next(iter(versions))})")
    return 0


def capture(adb_path: str, out: Path) -> int:
    serials = device_serials(adb_path)
    if len(serials) < MIN_DEVICES:
        print(f"BLOCKED: need at least {MIN_DEVICES} physical Android devices; found {len(serials)}")
        return 2
    timestamp = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    logs = out / "captures" / timestamp
    logs.mkdir(parents=True, exist_ok=True)
    for serial in serials:
        sdir = logs / serial
        sdir.mkdir(parents=True, exist_ok=True)
        for name, args, timeout in [
            ("logcat.txt", ["logcat", "-d", "-t", "2000", "-v", "threadtime"], 30),
            ("transport_service.txt", ["shell", "dumpsys", "activity", "services", f"{PACKAGE}/.LocalLinkTransportService"], 30),
            ("wifi_p2p.txt", ["shell", "dumpsys", "wifi"], 30),
            ("connectivity.txt", ["shell", "dumpsys", "connectivity"], 30),
            ("routes.txt", ["shell", "ip", "route"], 15),
            ("addresses.txt", ["shell", "ip", "-4", "addr"], 15),
        ]:
            try:
                text = adb(adb_path, serial, *args, timeout=timeout)
            except Exception as exc:
                text = f"[collection-error] {exc}"
            (sdir / name).write_text(text + "\n", encoding="utf-8")
    print(f"Captured PHASE 64 device evidence under {logs}")
    return 0


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("command", choices=["preflight", "capture", "init", "gate"])
    parser.add_argument("--adb", default=os.environ.get("ADB", "adb"))
    parser.add_argument("--out", default="phase64-evidence")
    parser.add_argument("--expected-devices", type=int)
    args = parser.parse_args()
    out = Path(args.out).resolve()
    if args.command == "init":
        init_evidence(out)
        print(f"Initialized PHASE 64 evidence at {out}")
        return 0
    if args.command == "gate":
        return gate(out)
    if args.command == "preflight":
        return preflight(args.adb, out, args.expected_devices)
    return capture(args.adb, out)


if __name__ == "__main__":
    raise SystemExit(main())
