#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
KT="$ROOT/flutter/android/app/src/main/kotlin/com/sajjad/locallink/LocalLinkTransportService.kt"
POLICY="$ROOT/flutter/android/app/src/main/kotlin/com/sajjad/locallink/DirectFileTransferPolicy.kt"
DART="$ROOT/flutter/lib/features/files/data/services/file_transfer_service.dart"
GO="$ROOT/backend/internal/httpapi/attachments.go"

grep -q 'MAX_ACTIVE_INCOMING_TRANSFERS' "$POLICY"
grep -q 'MAX_ACTIVE_OUTGOING_TRANSFERS' "$POLICY"
grep -q 'MAX_ACTIVE_TRANSFER_BYTES' "$POLICY"
grep -q 'MAX_RETRY_ATTEMPTS' "$POLICY"
grep -q 'atomicWriteText' "$KT"
grep -q 'outgoingSendInFlight' "$KT"
grep -q 'cancelledIncomingTransfers' "$KT"
grep -q 'Range.*bytes=' "$DART"
grep -q 'fileUploadGate' "$GO"
grep -q 'fileDownloadGate' "$GO"
grep -q 'StatusTooManyRequests' "$GO"
echo 'PHASE-57 static audit: PASS'
