#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
manifest="$ROOT/flutter/android/app/src/main/AndroidManifest.xml"
gradle="$ROOT/flutter/android/app/build.gradle"
env="$ROOT/backend/.env.example"
xml="$ROOT/flutter/android/app/src/main/res/xml/data_extraction_rules.xml"

grep -q 'android:usesCleartextTraffic="false"' "$manifest"
grep -q 'android:allowBackup="false"' "$manifest"
grep -q 'android:fullBackupContent="false"' "$manifest"
grep -q 'android:dataExtractionRules="@xml/data_extraction_rules"' "$manifest"
grep -q 'minifyEnabled true' "$gradle"
grep -q 'shrinkResources true' "$gradle"
test -f "$xml"
! grep -q 'change-this-to-a-strong-password' "$env"
grep -q 'LOCALLINK_REQUIRE_TLS=true' "$env"
grep -q 'minimum 16' "$env"
test -f "$ROOT/flutter/android/signing.properties.example"
grep -q 'signing.properties' "$ROOT/.gitignore"
echo 'PHASE 63 runtime/release static audit: PASS'
