#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
PACKET="$ROOT/flutter/android/app/src/main/kotlin/com/sajjad/locallink/mesh/MeshPacket.kt"
ROUTER="$ROOT/flutter/android/app/src/main/kotlin/com/sajjad/locallink/mesh/MeshRouter.kt"
SERVICE="$ROOT/flutter/android/app/src/main/kotlin/com/sajjad/locallink/LocalLinkTransportService.kt"
TEST="$ROOT/flutter/android/app/src/test/kotlin/com/sajjad/locallink/mesh/MeshRoutingTest.kt"
for f in "$PACKET" "$ROUTER" "$SERVICE" "$TEST"; do test -f "$f"; done
grep -q 'const val PROTOCOL_VERSION: Int = 1' "$PACKET"
grep -q 'if (!json.has(PROTOCOL_VERSION_KEY)) return null' "$PACKET"
grep -q 'packet.protocolVersion != MeshPacket.PROTOCOL_VERSION' "$ROUTER"
grep -q 'MeshPacket.new(' "$SERVICE"
! grep -q 'MeshPacket.fromLegacyPayload(decrypted' "$SERVICE"
! grep -q 'MeshPacket.fromLegacyPayload(JSONObject(payloadText)' "$SERVICE"
grep -q 'if (packet.destinationNodeId == self)' "$SERVICE"
grep -q 'legacyVersionPacketIsConstructibleOnlyForFixturesAndRouterRejectsIt' "$TEST"
echo "AUDIT-001 static audit: PASS"
