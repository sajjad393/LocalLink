$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent (Split-Path -Parent $MyInvocation.MyCommand.Path)
$out = if ($env:LOCLINK_ACCEPTANCE_EVIDENCE_DIR) { $env:LOCLINK_ACCEPTANCE_EVIDENCE_DIR } else { Join-Path $root 'scripts\phase64-evidence' }
$adb = if ($env:ADB) { $env:ADB } else { 'adb' }
$python = if (Get-Command python3 -ErrorAction SilentlyContinue) { 'python3' } elseif (Get-Command py -ErrorAction SilentlyContinue) { 'py' } else { throw 'Python 3 is required' }
$deviceCount = if ($env:LOCLINK_ACCEPTANCE_DEVICE_COUNT) { [int]$env:LOCLINK_ACCEPTANCE_DEVICE_COUNT } else { 2 }
$script = Join-Path $root 'scripts\android_acceptance_gate.py'
& $python $script preflight --adb $adb --out $out --expected-devices $deviceCount
& $python $script capture --adb $adb --out $out
& $python $script gate --out $out
