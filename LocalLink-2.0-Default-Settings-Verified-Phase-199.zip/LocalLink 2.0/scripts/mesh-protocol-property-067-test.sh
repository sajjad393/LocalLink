#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
MESH="$ROOT/flutter/android/app/src/main/kotlin/com/sajjad/locallink/mesh"
HARNESS="$ROOT/flutter/android/app/src/test/kotlin/com/sajjad/locallink/mesh/MeshProtocolPropertyHarness.kt"
OUT="$ROOT/.phase67-property-harness"
trap 'rm -rf "$OUT"' EXIT

command -v kotlinc >/dev/null 2>&1 || { echo 'BLOCKED: kotlinc unavailable' >&2; exit 2; }
rm -rf "$OUT"; mkdir -p "$OUT"

kotlinc \
  "$MESH/MeshLimits.kt" \
  "$MESH/MeshIdPolicy.kt" \
  "$MESH/MeshRoute.kt" \
  "$MESH/MeshRouteTable.kt" \
  "$MESH/MeshRouteAdvertisementPolicy.kt" \
  "$MESH/MeshRouteStabilityPolicy.kt" \
  "$MESH/MeshTransportSessionKeyPolicy.kt" \
  "$MESH/MeshSeenPacketTracker.kt" \
  "$MESH/MeshRouteRecoveryTracker.kt" \
  "$HARNESS" \
  -include-runtime -d "$OUT/harness.jar"

java -jar "$OUT/harness.jar"
