#!/usr/bin/env bash
set -euo pipefail
root="$(cd "$(dirname "$0")/.." && pwd)"
grep -q 'Authorization.*Bearer' "$root/backend/internal/httpapi/admin_auth.go"
grep -q 'aa.status=.active.' "$root/backend/internal/httpapi/admin_auth.go"
grep -q 'admin_id' "$root/backend/internal/httpapi/admin.go"
grep -q 'status=.revoked.' "$root/backend/internal/httpapi/admin.go"
grep -q 'account-scoped' "$root/backend/internal/httpapi/restoration.go" || true
echo 'AUDIT-022 static audit: PASS'
