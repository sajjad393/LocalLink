#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
FAIL=0
check() { local label="$1"; shift; if "$@"; then echo "PASS: $label"; else echo "FAIL: $label"; FAIL=1; fi; }
check_not() { local label="$1"; shift; if "$@"; then echo "FAIL: $label"; FAIL=1; else echo "PASS: $label"; fi; }

DART="$ROOT/flutter/lib/features/calls"
ANDROID="$ROOT/flutter/android/app/src/main/kotlin/com/sajjad/locallink"
BACKEND="$ROOT/backend/internal/httpapi/websocket.go"

check 'unified CallTransport exists' test -f "$DART/data/transport/call_transport.dart"
check 'CallSessionManager is the concrete call service' grep -q 'final class CallSessionManager implements CallGateway' "$DART/data/services/call_session_manager.dart"
check 'legacy CallService is compatibility alias only' grep -q '^typedef CallService = CallSessionManager;' "$DART/data/services/call_service.dart"
check 'transport factory exists' test -f "$DART/data/transport/call_transport_factory.dart"
check 'native mesh transport exists' grep -q 'NativeMeshCallTransport implements CallTransport' "$DART/data/transport/native_mesh_call_transport.dart"
check 'WebRTC transport is isolated' grep -q 'WebRTCCallTransport implements CallTransport' "$DART/data/transport/webrtc_call_transport.dart"
check 'flutter_webrtc imports stay inside approved adapters' python3 - "$ROOT" <<'PY2'
from pathlib import Path
import sys
root=Path(sys.argv[1])/'flutter/lib'
allowed={root/'features/calls/data/transport/webrtc_call_transport.dart', root/'features/calls/data/gateway/gateway_tunnel.dart'}
found={p for p in root.rglob('*.dart') if 'package:flutter_webrtc/flutter_webrtc.dart' in p.read_text()}
sys.exit(0 if found <= allowed else 1)
PY2
check_not 'CallSessionManager has no RTCPeerConnection' grep -q 'RTCPeerConnection\|createPeerConnection\|MediaStream' "$DART/data/services/call_session_manager.dart"
check 'native mesh transport uses call media adapter' grep -q 'media.start(callId:' "$DART/data/transport/native_mesh_call_transport.dart"
check 'media packet metadata model exists' grep -q 'final class\|class CallMediaPacket' "$DART/data/transport/call_transport_packet.dart"
check 'media packet validates codec' grep -q "codec != 'opus'" "$DART/data/transport/call_transport_packet.dart"
check 'media packet validates ttl' grep -q 'ttl == null' "$DART/data/transport/call_transport_packet.dart"
check 'native media uses AudioRecord' grep -q 'AudioRecord' "$ANDROID/LocalLinkTransportService.kt"
check 'native media uses AudioTrack' grep -q 'AudioTrack' "$ANDROID/LocalLinkTransportService.kt"
check 'native media has Opus capability adapter' test -f "$ANDROID/CallOpusCodec.kt"
check 'native media emits encrypted_payload' grep -q 'encrypted_payload' "$ANDROID/LocalLinkTransportService.kt"
check 'native media AAD binds timestamp and codec' grep -q 'locallink-call-media-v1|.*\$sequence|\$timestamp|\$codec' "$ANDROID/LocalLinkTransportService.kt"
check 'native receiver validates destination' grep -q 'recipient_id.*selfId' "$ANDROID/LocalLinkTransportService.kt"
check 'native receiver validates codec' grep -q 'codec != current.codec' "$ANDROID/LocalLinkTransportService.kt"
check 'native replay cache is bounded' grep -q 'callMediaMaxRecent = 512' "$ANDROID/LocalLinkTransportService.kt"
check 'native jitter buffer is bounded' grep -q 'CALL_MAX_JITTER_FRAMES = 12' "$ANDROID/LocalLinkTransportService.kt"
check 'native audio focus exists' grep -q 'requestCallAudioFocus' "$ANDROID/LocalLinkTransportService.kt"
check 'mesh transport-switch signaling exists in backend' grep -q 'call_transport_switch_request' "$BACKEND"
check 'Flutter handles transport switch messages' grep -q "case 'call_transport_switch_request'" "$DART/data/services/call_session_manager.dart"
check 'AUTO can select mesh or WebRTC' grep -q 'CallTransportMode.auto' "$DART/data/services/call_session_manager.dart" && grep -q 'directTransport.isStarted' "$DART/data/services/call_session_manager.dart"
check 'offline signal path marks mesh call' grep -q "'mesh_call': true" "$DART/data/services/call_session_manager.dart"
check_not 'WebRTC is not imported by native audio platform adapter' grep -q 'flutter_webrtc' "$DART/data/platform/call_audio_platform_service.dart"
check 'CallGateway has common video actions' grep -q 'Future<void> toggleVideo' "$DART/domain/call_gateway.dart"
check 'CallBloc fake implements expanded gateway' grep -q 'Future<void> toggleVideo' "$ROOT/flutter/test/call_bloc_test.dart"

if [[ "$FAIL" -eq 0 ]]; then
  echo 'CALL ARCHITECTURE AUDIT: PASS'
else
  echo 'CALL ARCHITECTURE AUDIT: FAIL' >&2
  exit 1
fi
