#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
ROUTER="$ROOT/flutter/android/app/src/main/kotlin/com/sajjad/locallink/mesh/MeshRouter.kt"
POLICY="$ROOT/flutter/android/app/src/main/kotlin/com/sajjad/locallink/mesh/MeshFinalRecipientPolicy.kt"
SERVICE="$ROOT/flutter/android/app/src/main/kotlin/com/sajjad/locallink/LocalLinkTransportService.kt"
MESSAGING="$ROOT/flutter/lib/features/messaging/data/services/reliable_messaging_service.dart"
TEST="$ROOT/flutter/android/app/src/test/kotlin/com/sajjad/locallink/mesh/MeshFinalRecipientPolicyTest.kt"

for f in "$ROUTER" "$POLICY" "$SERVICE" "$MESSAGING" "$TEST"; do test -f "$f"; done

grep -q 'MeshFinalRecipientPolicy.isFinalRecipient' "$ROUTER"
grep -q 'local_delivery_not_final_recipient' "$SERVICE"
grep -q 'mesh_final_recipient.*true' "$SERVICE"
grep -q 'mesh_destination_id.*self' "$SERVICE"
grep -q "event\['mesh_final_recipient'\] != true" "$MESSAGING"
grep -q "event\['mesh_destination_id'\].*store.deviceId" "$MESSAGING"
grep -q 'onlyFinalNodeCanConsumePacketLocally' "$TEST"
grep -q 'relayCannotMasqueradeAsFinalRecipient' "$TEST"

# A direct peer must not be surfaced as a local message unless the destination is self.
DELIVERY_BLOCK="$(grep -A40 'private fun deliverLocalPacket' "$SERVICE")"
echo "$DELIVERY_BLOCK" | grep -q 'MeshFinalRecipientPolicy.isFinalRecipient'

echo "MESH-5 static audit: PASS"
