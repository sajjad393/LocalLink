#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
fail=0
check(){ local label="$1"; shift; if "$@" >/dev/null 2>&1; then echo "PASS: $label"; else echo "FAIL: $label"; fail=1; fi; }
check "gateway transport mode" grep -q "internet_gateway" "$ROOT/flutter/lib/features/calls/data/transport/call_transport_mode.dart"
check "gateway-aware policy" grep -q "gatewayRouteAvailable" "$ROOT/flutter/lib/features/calls/data/transport/call_transport_selection_policy.dart"
check "unified session manager" grep -q "GatewayService" "$ROOT/flutter/lib/features/calls/data/services/call_session_manager.dart"
check "gateway call transport" test -f "$ROOT/flutter/lib/features/calls/data/gateway/internet_gateway_call_transport.dart"
check "gateway registry" test -f "$ROOT/flutter/lib/features/calls/data/gateway/gateway_registry.dart"
check "gateway bloc" test -f "$ROOT/flutter/lib/features/calls/bloc/gateway_bloc.dart"
check "gateway UI controls" grep -q "Use Internet Gateway" "$ROOT/flutter/lib/features/account/presentation/screens/profile_screen.dart"
check "native opaque packet bridge" grep -q "gateway_packet_outbound" "$ROOT/flutter/android/app/src/main/kotlin/com/sajjad/locallink/LocalLinkTransportService.kt"
check "native gateway envelope" grep -q "gateway_envelope" "$ROOT/flutter/android/app/src/main/kotlin/com/sajjad/locallink/LocalLinkTransportService.kt"
check "backend gateway relay" grep -q "handleGatewayPacket" "$ROOT/backend/internal/httpapi/gateway.go"
check "backend gateway authentication" grep -q "verifyGatewaySignature" "$ROOT/backend/internal/httpapi/gateway.go"
check "backend replay protection" grep -q "rememberGatewayNonce" "$ROOT/backend/internal/httpapi/gateway.go"
check "gateway audit hooks" grep -q "auditGatewayEvent" "$ROOT/backend/internal/httpapi/gateway.go"
check "backend accepts gateway transport switch" grep -q 'mode != "internet_gateway"' "$ROOT/backend/internal/httpapi/websocket.go"
if grep -nEi '(opus|pcm|audio|video|webrtc).*(decode|decrypt|encode)|((decode|decrypt|encode).*(opus|pcm|audio|video|webrtc))' "$ROOT/backend/internal/httpapi/gateway.go" >/tmp/ll-gw-negative.txt 2>/dev/null; then echo "FAIL: gateway backend appears to contain a media codec/decrypt path"; cat /tmp/ll-gw-negative.txt; fail=1; else echo "PASS: gateway backend has no media codec/decrypt path"; fi
python3 - "$ROOT/LOCAL_LINK_TODO.md" <<'PY2'
import re, sys
s=open(sys.argv[1],encoding='utf-8').read()
for n in range(98,128):
    if not re.search(rf'^## Phase {n} — ', s, re.M): raise SystemExit(f'MISSING: Phase {n}')
print('PASS: phases 98-127 present')
PY2
if (( fail )); then exit 1; fi
echo "Internet Gateway static audit: PASS"
