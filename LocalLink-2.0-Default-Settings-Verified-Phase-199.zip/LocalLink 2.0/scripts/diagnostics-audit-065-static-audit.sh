#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
fail(){ echo "FAIL: $*" >&2; exit 1; }
pass(){ echo "PASS: $*"; }

[[ -f "$ROOT/flutter/lib/core/diagnostics/app_diagnostics.dart" ]] || fail "client diagnostics missing"
[[ -f "$ROOT/flutter/lib/features/diagnostics/presentation/diagnostics_screen.dart" ]] || fail "diagnostics screen missing"
[[ -f "$ROOT/backend/internal/httpapi/runtime_diagnostics.go" ]] || fail "backend diagnostics endpoint missing"

grep -q 'maxEvents = 300' "$ROOT/flutter/lib/core/diagnostics/app_diagnostics.dart" || fail "diagnostic event bound changed"
grep -q '_allowedKeys' "$ROOT/flutter/lib/core/diagnostics/app_diagnostics.dart" || fail "diagnostic field allowlist missing"
grep -q "recordException" "$ROOT/flutter/lib/core/services/app_logger.dart" || fail "logger is not connected to diagnostics"
grep -q 'requireAdmin' "$ROOT/backend/internal/httpapi/runtime_diagnostics.go" || fail "runtime endpoint is not admin protected"
grep -q 'runtimeDiagnostics' "$ROOT/flutter/lib/features/admin/domain/admin_repository_contract.dart" || fail "admin client contract missing diagnostics"
grep -q 'GET /api/v1/admin/runtime-diagnostics' "$ROOT/backend/cmd/server/main.go" || fail "runtime endpoint is not wired"
grep -q 'SetRuntimeDiagnosticsProvider(metrics.snapshot)' "$ROOT/backend/cmd/server/main.go" || fail "runtime provider is not wired"

# Diagnostic stores must stay memory-only; these paths must not be introduced by the phase.
! grep -RInE 'writeAsString|File\(|SharedPreferences|INSERT INTO.*diagnostic|CREATE TABLE.*diagnostic' \
  "$ROOT/flutter/lib/core/diagnostics" "$ROOT/flutter/lib/features/diagnostics" >/dev/null || fail "diagnostics are being persisted"

# No obvious sensitive field names are permitted in diagnostic output code.
if grep -RInE "['\"](body|message|plaintext|password|token|authorization|phone|device_id|account_id|file_path|ciphertext)['\"]" \
  "$ROOT/flutter/lib/core/diagnostics" "$ROOT/flutter/lib/features/diagnostics" "$ROOT/backend/internal/httpapi/runtime_diagnostics.go" >/dev/null; then
  fail "sensitive diagnostic field detected"
fi

pass "client diagnostics bounded + allowlisted"
pass "logger integration present"
pass "admin runtime endpoint authenticated + wired"
pass "diagnostics persistence scan clean"
pass "sensitive-field scan clean"
