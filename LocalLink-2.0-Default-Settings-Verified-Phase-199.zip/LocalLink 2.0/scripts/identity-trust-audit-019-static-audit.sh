#!/usr/bin/env bash
set -euo pipefail
root="$(cd "$(dirname "$0")/.." && pwd)"
test -f "$root/flutter/lib/core/security/identity_trust_service.dart"
grep -q 'IdentityTrustState { unverified, verified, changed, revoked }' "$root/flutter/lib/core/security/identity_trust_service.dart"
grep -q 'fingerprint' "$root/flutter/lib/core/security/identity_trust_service.dart"
grep -q 'verifyQrPayload' "$root/flutter/lib/core/security/identity_trust_service.dart"
grep -q 'markVerified' "$root/flutter/lib/core/security/identity_trust_service.dart"
echo 'AUDIT-019 static audit: PASS'
