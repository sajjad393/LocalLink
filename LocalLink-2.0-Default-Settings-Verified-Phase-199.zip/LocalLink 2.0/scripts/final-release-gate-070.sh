#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
RESULT_DIR="${LOCLINK_GATE_RESULT_DIR:-$ROOT/.phase70-release-gate}"
RELEASE_ARTIFACT=""
RELEASE_MODE=0
REQUIRE_PHYSICAL="${LOCLINK_REQUIRE_PHYSICAL_ACCEPTANCE:-0}"

usage() {
  cat <<USAGE
Usage: $0 [--release-artifact /path/to/app.aab] [--release]

Default mode validates the repository release-gate structure and automated
repository/JVM gates. --release additionally requires a signed AAB and release
version/tag consistency. Physical acceptance is required only when
LOCLINK_REQUIRE_PHYSICAL_ACCEPTANCE=1.
USAGE
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --release)
      RELEASE_MODE=1
      ;;
    --release-artifact)
      [[ $# -ge 2 ]] || { echo "FAIL: --release-artifact needs a path" >&2; exit 1; }
      RELEASE_ARTIFACT="$2"
      shift
      ;;
    -h|--help)
      usage
      exit 0
      ;;
    *)
      echo "FAIL: unknown argument $1" >&2
      exit 1
      ;;
  esac
  shift
done

mkdir -p "$RESULT_DIR"
RESULTS="$RESULT_DIR/results.tsv"
: > "$RESULTS"
FAILURES=0
BLOCKED=0

record() {
  printf '%s\t%s\t%s\n' "$1" "$2" "$3" >> "$RESULTS"
}

pass() { record "$1" PASS "$2"; }
fail() { record "$1" FAIL "$2"; FAILURES=$((FAILURES + 1)); }
blocked() { record "$1" BLOCKED "$2"; BLOCKED=$((BLOCKED + 1)); }
skipped() { record "$1" SKIPPED "$2"; }

run_gate() {
  local name="$1" script="$2"
  if [[ ! -x "$ROOT/$script" ]]; then
    fail "$name" "missing executable $script"
    return
  fi
  local rc
  if "$ROOT/$script"; then
    pass "$name" "completed"
  else
    rc=$?
    if [[ $rc -eq 2 ]]; then
      blocked "$name" "environment/toolchain unavailable"
    else
      fail "$name" "exit=$rc"
    fi
  fi
}

required_files=(
  PHASE_63_COMPLETION_REPORT.md
  PHASE_64_COMPLETION_REPORT.md
  PHASE_65_COMPLETION_REPORT.md
  PHASE_66_COMPLETION_REPORT.md
  PHASE_67_COMPLETION_REPORT.md
  PHASE_68_COMPLETION_REPORT.md
  PHASE_69_COMPLETION_REPORT.md
  PHASE_70_CHECKLIST.md
  PHASE_70_FINAL_RELEASE_GATE.md
)
for file in "${required_files[@]}"; do
  if [[ -f "$ROOT/$file" ]]; then pass "artifact:$file" "present"; else fail "artifact:$file" "missing"; fi
done

# Latest deterministic regression layers. The older phase reports remain the
# historical evidence for phases 50-65; these executable gates protect the
# highest-risk cumulative layers from regression at release time. In CI, the
# dedicated verify job may execute them before this final aggregation gate.
if [[ "${LOCLINK_REGRESSIONS_PRECHECKED:-0}" == "1" ]]; then
  skipped phase66-68-regressions "already executed by CI verification job"
else
  run_gate phase66-chaos scripts/chaos-resilience-066-test.sh
  run_gate phase66-static scripts/phase66-chaos-static-audit.sh
  run_gate phase67-property scripts/mesh-protocol-property-067-test.sh
  run_gate phase67-static scripts/protocol-fuzz-067-static-audit.sh
  run_gate phase68-load-chaos scripts/mesh-load-chaos-068-test.sh
  run_gate phase68-static scripts/phase68-load-chaos-static-audit.sh
fi
run_gate phase65-privacy scripts/diagnostics-audit-065-static-audit.sh
run_gate phase63-release-static scripts/runtime-environment-063-audit.sh

if [[ -n "$(find "$ROOT" -maxdepth 2 -type d -name .git -print -quit 2>/dev/null)" ]]; then
  if [[ -z "$(git -C "$ROOT" status --short)" ]]; then
    pass git-working-tree "clean"
  else
    fail git-working-tree "working tree has uncommitted changes"
  fi
else
  if [[ $RELEASE_MODE -eq 1 ]]; then
    blocked git-working-tree "not a Git checkout"
  else
    skipped git-working-tree "not applicable outside a Git checkout"
  fi
fi

if [[ $RELEASE_MODE -eq 1 || -n "${GITHUB_REF_NAME:-}" && "${GITHUB_REF_NAME}" == v* ]]; then
  RELEASE_MODE=1
  TAG="${GITHUB_REF_NAME:-}"
  VERSION_LINE="$(grep -E '^version:[[:space:]]*[0-9]+\.[0-9]+\.[0-9]+\+[0-9]+$' "$ROOT/flutter/pubspec.yaml" || true)"
  VERSION="${VERSION_LINE#version: }"
  SEMVER="${VERSION%%+*}"

  if [[ -n "$TAG" && "$TAG" == "v$SEMVER" ]]; then
    pass release-version "tag $TAG matches pubspec version $VERSION"
  else
    fail release-version "tag ${TAG:-<missing>} does not match pubspec version ${VERSION:-<missing>}"
  fi

  for required in LOCLINK_RELEASE_STORE_PASSWORD LOCLINK_RELEASE_KEY_ALIAS LOCLINK_RELEASE_KEY_PASSWORD; do
    if [[ -n "${!required:-}" ]]; then
      pass "release-secret:$required" "configured"
    else
      fail "release-secret:$required" "missing"
    fi
  done

  if [[ -n "${LOCLINK_RELEASE_STORE_FILE:-}" && -f "${LOCLINK_RELEASE_STORE_FILE}" ]]; then
    pass release-keystore "keystore exists"
  else
    fail release-keystore "LOCLINK_RELEASE_STORE_FILE is missing or unreadable"
  fi

  if [[ -n "$RELEASE_ARTIFACT" && -f "$RELEASE_ARTIFACT" ]]; then
    pass release-artifact "${RELEASE_ARTIFACT} exists"
    if command -v jarsigner >/dev/null 2>&1; then
      if jarsigner -verify -strict "$RELEASE_ARTIFACT" >/dev/null 2>&1; then
        pass release-artifact-signature "jarsigner verification passed"
      else
        fail release-artifact-signature "AAB is not verified as signed"
      fi
    else
      blocked release-artifact-signature "jarsigner unavailable"
    fi
    sha256sum "$RELEASE_ARTIFACT" > "$RESULT_DIR/release-artifact.sha256"
  else
    fail release-artifact "release AAB not supplied"
  fi

  if [[ "$REQUIRE_PHYSICAL" == "1" ]]; then
    run_gate physical-android-acceptance scripts/android-acceptance-gate.sh
  else
    skipped physical-android-acceptance "not enabled; set LOCLINK_REQUIRE_PHYSICAL_ACCEPTANCE=1 to make physical acceptance mandatory"
  fi
fi

# A release sign-off is fail-closed: no FAIL and no BLOCKED result is allowed.
if [[ $FAILURES -gt 0 ]]; then
  echo "PHASE 70 FINAL RELEASE GATE: FAIL (failures=$FAILURES blocked=$BLOCKED)"
  exit 1
fi
if [[ $BLOCKED -gt 0 ]]; then
  echo "PHASE 70 FINAL RELEASE GATE: BLOCKED (blocked=$BLOCKED)"
  exit 2
fi

echo "PHASE 70 FINAL RELEASE GATE: PASS"
