#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
MESH="$ROOT/flutter/android/app/src/main/kotlin/com/sajjad/locallink/mesh"
SERVICE="$ROOT/flutter/android/app/src/main/kotlin/com/sajjad/locallink/LocalLinkTransportService.kt"
TEST="$ROOT/flutter/android/app/src/test/kotlin/com/sajjad/locallink/mesh"
PACKET="$MESH/MeshPacket.kt"

# Legacy decoding/encoding must not exist in production routing code.
! grep -Rqs 'fromLegacyPayload' "$MESH" || { echo 'legacy decoder still present in production mesh package'; exit 1; }
! grep -Rqs 'toLegacyPayload' "$MESH" || { echo 'legacy wire encoder still present in production mesh package'; exit 1; }

# Application compatibility is explicitly named and is only consumed after final-recipient validation.
grep -q 'fun toApplicationPayload()' "$PACKET"
grep -q 'packet.toApplicationPayload()' "$SERVICE"
grep -q 'MeshFinalRecipientPolicy.isFinalRecipient' "$SERVICE"

# Canonical parser remains the only transport ingress parser.
grep -q 'MeshPacket.fromJson(decrypted)' "$SERVICE"
! grep -q 'MeshPacket.fromLegacyPayload' "$SERVICE"


# Test suite must cover the migration boundary and legacy rejection.
grep -q 'legacyVersionPacketIsConstructibleOnlyForFixturesAndRouterRejectsIt' "$TEST/MeshRoutingTest.kt"
grep -q 'canonicalParserRejectsLegacyShapedApplicationPayload' "$TEST/LegacyMeshPacketBoundaryTest.kt"
grep -q 'routerRejectsNonCanonicalLegacyPacket' "$TEST/MeshRoutingTest.kt"

echo 'AUDIT-003 static audit: PASS'
