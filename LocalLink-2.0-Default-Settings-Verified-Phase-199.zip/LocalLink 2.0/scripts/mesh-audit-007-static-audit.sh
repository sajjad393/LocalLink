#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
REG="$ROOT/flutter/android/app/src/main/kotlin/com/sajjad/locallink/mesh/MeshPeerRegistry.kt"
POL="$ROOT/flutter/android/app/src/main/kotlin/com/sajjad/locallink/mesh/MeshPeerLifecyclePolicy.kt"
TEST="$ROOT/flutter/android/app/src/test/kotlin/com/sajjad/locallink/mesh/MeshPeerLifecyclePolicyTest.kt"
for f in "$REG" "$POL" "$TEST"; do test -f "$f"; done
grep -q 'MeshPeerLifecyclePolicy.shouldIgnoreObservation' "$REG"
grep -q 'MeshTransportPolicy.isSupportedTransport' "$REG"
grep -q 'lastSeenAt < previous.lastSeenAt' "$REG"
grep -q 'CONNECTED' "$POL"
grep -q 'DISCOVERED' "$POL"
grep -q 'connectedPeerCannotRegressToDiscovery' "$TEST"
grep -q 'registryKeepsLivePeerWhenLanBeaconArrivesAfterConnection' "$TEST"
echo 'AUDIT-007 static audit: PASS'
