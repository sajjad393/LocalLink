#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
ACT="$ROOT/flutter/android/app/src/main/kotlin/com/sajjad/locallink/MainActivity.kt"
SERVICE="$ROOT/flutter/android/app/src/main/kotlin/com/sajjad/locallink/LocalLinkTransportService.kt"
for f in "$ACT" "$SERVICE"; do test -f "$f"; done
grep -q 'WIFI_P2P_STATE_CHANGED_ACTION' "$ACT"
grep -q 'LocalLinkTransportService.updateConnection(context, false, false, null)' "$ACT"
grep -q 'valid Wi-Fi Direct device address is required' "$ACT"
grep -q 'groupOwnerIntent=50' "$ACT"
grep -q 'connectTransportToOwner' "$SERVICE"
grep -q 'ensureTransportServer' "$SERVICE"
grep -q 'WIFI_DIRECT_PORT' "$SERVICE"
echo 'AUDIT-009 static audit: PASS'
