#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
pass(){ echo "PASS: $1"; }
blocked(){ echo "BLOCKED: $1"; }

if command -v flutter >/dev/null 2>&1; then
  pass "Flutter SDK available"
else
  blocked "Flutter SDK unavailable"
fi
if [ -x "$ROOT/flutter/android/gradlew" ] || [ -f "$ROOT/flutter/android/gradlew" ]; then
  pass "Gradle wrapper present"
else
  blocked "Gradle wrapper unavailable"
fi
if command -v adb >/dev/null 2>&1; then
  pass "ADB available"
else
  blocked "ADB unavailable"
fi

if [ -d "$ROOT/flutter/android/app/src/main" ]; then pass "Android source present"; else exit 1; fi
if grep -q 'MeshTransportSessionKeyPolicy.currentEpoch' "$ROOT/flutter/android/app/src/main/kotlin/com/sajjad/locallink/LocalLinkTransportService.kt"; then pass "Live data path carries session key epochs"; else exit 1; fi
if grep -q 'routeAdvertisementPolicy.evaluate' "$ROOT/flutter/android/app/src/main/kotlin/com/sajjad/locallink/LocalLinkTransportService.kt"; then pass "Live route-control path enforces replay/rate admission"; else exit 1; fi
