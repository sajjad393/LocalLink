#!/usr/bin/env bash
set -euo pipefail
root="$(cd "$(dirname "$0")/.." && pwd)"
test -f "$root/flutter/lib/core/security/sensitive_file_protection_service.dart"
grep -q 'AesGcm.with256bits' "$root/flutter/lib/core/security/sensitive_file_protection_service.dart"
grep -q 'locallink_local_file_key_v1' "$root/flutter/lib/core/security/sensitive_file_protection_service.dart"
grep -q "return protectedTarget" "$root/flutter/lib/features/files/data/services/file_transfer_service.dart"
grep -q 'protectLegacyLocalFile' "$root/flutter/lib/features/files/data/services/file_transfer_service.dart"
grep -q 'materializeForView' "$root/flutter/lib/core/security/sensitive_file_protection_service.dart"
echo 'AUDIT-018 static audit: PASS'
