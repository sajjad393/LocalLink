#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT="${LOCLINK_ACCEPTANCE_EVIDENCE_DIR:-$ROOT/scripts/phase64-evidence}"
python3 "$ROOT/scripts/android_acceptance_gate.py" gate --out "$OUT"
