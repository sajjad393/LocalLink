#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SVC="$ROOT/flutter/android/app/src/main/kotlin/com/sajjad/locallink/LocalLinkTransportService.kt"
SEC="$ROOT/flutter/android/app/src/main/kotlin/com/sajjad/locallink/DirectFileSecurity.kt"
TEST="$ROOT/flutter/android/app/src/test/kotlin/com/sajjad/locallink/DirectFileSecurityTest.kt"
PEER="$ROOT/flutter/lib/features/connectivity/domain/peer_transport_contract.dart"
WIFI="$ROOT/flutter/lib/features/connectivity/data/services/wifi_direct_transport_service.dart"
BLOC="$ROOT/flutter/lib/features/files/bloc/file_transfer_bloc.dart"
MAIN="$ROOT/flutter/android/app/src/main/kotlin/com/sajjad/locallink/MainActivity.kt"
for f in "$SVC" "$SEC" "$TEST" "$PEER" "$WIFI" "$BLOC" "$MAIN"; do test -f "$f"; done

grep -q 'const val CRYPTO_VERSION = "v2"' "$SEC"
grep -q 'deriveFileKey' "$SEC"
grep -q 'chunkAad' "$SEC"
grep -q 'authTag' "$SEC"
grep -q 'encryptChunk' "$SEC"
grep -q 'decryptChunk' "$SEC"
grep -q 'crypto_version.*DirectFileSecurity.CRYPTO_VERSION' "$SVC"
grep -q 'deriveFileKey(key,context)' "$SVC"
grep -q 'transfer.fileName != fileName' "$SVC"
grep -q 'transfer.contentType != contentType' "$SVC"
grep -q 'direct_file_cancel' "$SVC"
grep -q 'cancelledDirectTransfers' "$SVC"
grep -q 'Future<void> cancelFile(String fileId)' "$PEER"
grep -q "invokeMethod('cancelFile'" "$WIFI"
grep -q 'cancelDirectFile' "$BLOC"
grep -q '"cancelFile"' "$MAIN"
if grep -R -nE 'encryptBytesE2e|decryptBytesE2e|hmacFile' "$ROOT/flutter/android/app/src/main/kotlin"; then
  echo 'legacy direct-file crypto helpers remain' >&2; exit 1
fi
grep -q 'differentFilesDeriveDifferentKeys' "$TEST"
grep -q 'metadataChangeBreaksChunkDecryption' "$TEST"
grep -q 'authenticationBindsChunkIndexAndCiphertext' "$TEST"
echo 'AUDIT-015 static audit: PASS'
