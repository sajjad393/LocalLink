#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SERVICE="$ROOT/flutter/android/app/src/main/kotlin/com/sajjad/locallink/LocalLinkTransportService.kt"
TABLE="$ROOT/flutter/android/app/src/main/kotlin/com/sajjad/locallink/mesh/MeshRouteTable.kt"
TRACKER="$ROOT/flutter/android/app/src/main/kotlin/com/sajjad/locallink/mesh/MeshRouteRecoveryTracker.kt"
TEST="$ROOT/flutter/android/app/src/test/kotlin/com/sajjad/locallink/mesh/MeshRouteRecoveryTrackerTest.kt"

for f in "$SERVICE" "$TABLE" "$TRACKER" "$TEST"; do test -f "$f"; done

grep -q 'handleRoutesAfterPeerDisconnect' "$SERVICE"
grep -q 'routeRecovery.markPeerLost' "$SERVICE"
grep -q 'routeRecovery.markRecovered' "$SERVICE"
grep -q 'route_recovery_started' "$SERVICE"
grep -q 'route_recovery_expired' "$SERVICE"
grep -q 'route_withdrawal' "$SERVICE"
grep -q 'handleRouteWithdrawal' "$SERVICE"
grep -q 'broadcastRouteWithdrawal' "$SERVICE"
grep -q 'Thread { flushMeshQueue() }.start()' "$SERVICE"
grep -q 'remove(destinationNodeId: String, nextHopNodeId: String)' "$TABLE"
grep -q 'recovering_routes' "$SERVICE"
# Do not allow transport disconnects to bypass route recovery handling.
grep -q 'private fun stopWifiDirectSockets' "$SERVICE"
grep -q 'private fun closePeerLinksForTransport' "$SERVICE"
grep -q 'private fun handleRoutesAfterPeerDisconnect' "$SERVICE"
grep -q 'private fun broadcastRouteWithdrawal' "$SERVICE"
# Avoid accidental use of whole-destination removal in the withdrawal handler.
HANDLER="$(grep -A35 'private fun handleRouteWithdrawal' "$SERVICE")"
echo "$HANDLER" | grep -q 'routeTable.remove(destination, senderPeerId)'
echo "$HANDLER" | grep -q 'MeshRouteAdvertisementAuthenticator.verify'

echo "MESH-4 static audit: PASS"
