#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TEST="$ROOT/flutter/android/app/src/test/kotlin/com/sajjad/locallink/mesh"
MESH="$ROOT/flutter/android/app/src/main/kotlin/com/sajjad/locallink/mesh"

for f in \
  "$TEST/MeshProtocolPropertyHarness.kt" \
  "$TEST/MeshPacketFuzzTest.kt" \
  "$ROOT/scripts/mesh-protocol-property-067-test.sh"; do
  test -f "$f"
done

grep -q 'SEED = 0x6c6f63616c6c696eL' "$TEST/MeshProtocolPropertyHarness.kt"
grep -q 'ITERATIONS = 20_000' "$TEST/MeshProtocolPropertyHarness.kt"
grep -q 'malformedMutationsNeverThrow' "$TEST/MeshPacketFuzzTest.kt"
grep -q 'canonicalRoundTripPreservesSecurityInvariants' "$TEST/MeshPacketFuzzTest.kt"
grep -q '4_000' "$TEST/MeshPacketFuzzTest.kt"
grep -q 'routeControlFuzzNeverAcceptsTamperedAuthentication' "$TEST/MeshPacketFuzzTest.kt"
grep -q 'AES/GCM/NoPadding' "$TEST/MeshProtocolPropertyHarness.kt"
! grep -R -n 'println(' "$MESH" >/dev/null 2>&1

echo 'PHASE 67 protocol fuzz/property static audit: PASS'
