#!/usr/bin/env bash
set -u
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PASS=0; BLOCKED=0; FAIL=0
REPORT="$ROOT/PHASE_63_RELEASE_GATE_RESULTS.txt"
: > "$REPORT"
check() {
  local name="$1"; shift
  if "$@" >>"$REPORT" 2>&1; then
    echo "PASS: $name"; echo "PASS: $name" >>"$REPORT"; PASS=$((PASS+1))
  else
    local rc=$?
    echo "FAIL: $name (rc=$rc)"; echo "FAIL: $name (rc=$rc)" >>"$REPORT"; FAIL=$((FAIL+1))
  fi
}
block() {
  echo "BLOCKED: $1"; echo "BLOCKED: $1" >>"$REPORT"; BLOCKED=$((BLOCKED+1))
}

static_gate() {
  grep -q 'android:usesCleartextTraffic="false"' "$ROOT/flutter/android/app/src/main/AndroidManifest.xml" &&
  grep -q 'android:allowBackup="false"' "$ROOT/flutter/android/app/src/main/AndroidManifest.xml" &&
  grep -q 'android:fullBackupContent="false"' "$ROOT/flutter/android/app/src/main/AndroidManifest.xml" &&
  grep -q 'android:dataExtractionRules="@xml/data_extraction_rules"' "$ROOT/flutter/android/app/src/main/AndroidManifest.xml" &&
  grep -q 'minifyEnabled true' "$ROOT/flutter/android/app/build.gradle" &&
  grep -q 'shrinkResources true' "$ROOT/flutter/android/app/build.gradle" &&
  test -f "$ROOT/flutter/android/app/src/main/res/xml/data_extraction_rules.xml" &&
  test -f "$ROOT/flutter/android/signing.properties.example" &&
  ! grep -qE '^(LOCALLINK_ADMIN_BOOTSTRAP_PASSWORD|LOCALLINK_PAIRING_CODE)=[^[:space:]#]+' "$ROOT/backend/.env.example"
}
check "release static configuration" static_gate
check "existing static audit suite" "$ROOT/scripts/runtime-environment-062-audit.sh"
check "mesh adversarial suite" "$ROOT/scripts/mesh-runtime-adversarial-062-test.sh"

if command -v go >/dev/null 2>&1; then
  GO_LOG=$(mktemp)
  if (cd "$ROOT/backend" && go test ./cmd/server ./internal/discovery ./internal/ws) >"$GO_LOG" 2>&1; then
    echo "PASS: backend runtime tests" | tee -a "$REPORT"; PASS=$((PASS+1))
  elif grep -qE 'proxy.golang.org|connection refused|no network|cannot download|missing go.sum' "$GO_LOG"; then
    block "Backend runtime tests blocked by unavailable dependency/network access"
    cat "$GO_LOG" >>"$REPORT"
  else
    echo "FAIL: backend runtime tests" | tee -a "$REPORT"; cat "$GO_LOG" | tee -a "$REPORT"; FAIL=$((FAIL+1))
  fi
  rm -f "$GO_LOG"
else
  block "Go toolchain unavailable"
fi

if command -v flutter >/dev/null 2>&1; then
  (cd "$ROOT/flutter" && flutter analyze) || FAIL=$((FAIL+1))
  (cd "$ROOT/flutter" && flutter test) || FAIL=$((FAIL+1))
  (cd "$ROOT/flutter" && flutter build appbundle --release --dart-define=LOCLINK_RELEASE_CONFIGURED=true) || FAIL=$((FAIL+1))
else
  block "Flutter SDK unavailable: analyze/test/release AAB were not executed"
fi

if command -v adb >/dev/null 2>&1; then
  echo "INFO: ADB available; physical-device matrix must be executed separately." | tee -a "$REPORT"
else
  block "ADB unavailable: physical Android validation not executed"
fi

printf '\nSUMMARY PASS=%d BLOCKED=%d FAIL=%d\n' "$PASS" "$BLOCKED" "$FAIL" | tee -a "$REPORT"
# A blocked environment is not a product failure; a real gate failure is.
if (( FAIL > 0 )); then exit 1; fi
exit 0
