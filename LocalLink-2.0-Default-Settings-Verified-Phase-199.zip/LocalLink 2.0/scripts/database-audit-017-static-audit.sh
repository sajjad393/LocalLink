#!/usr/bin/env bash
set -euo pipefail
root="$(cd "$(dirname "$0")/.." && pwd)"
grep -q '^  sqflite_sqlcipher:' "$root/flutter/pubspec.yaml"
test -f "$root/flutter/lib/core/storage/database_encryption_service.dart"
grep -q 'password: key' "$root/flutter/lib/core/storage/database_encryption_service.dart"
grep -q 'Random.secure' "$root/flutter/lib/core/storage/database_encryption_service.dart"
grep -q 'flutter_secure_storage' "$root/flutter/lib/core/security/secure_storage_service.dart"
grep -q 'sqflite_sqlcipher/sqflite.dart' "$root/flutter/lib/core/services/local_store.dart"
test -f "$root/flutter/android/app/proguard-rules.pro"
echo 'AUDIT-017 static audit: PASS'
