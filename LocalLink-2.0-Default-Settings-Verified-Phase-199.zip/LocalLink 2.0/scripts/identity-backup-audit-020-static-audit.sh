#!/usr/bin/env bash
set -euo pipefail
root="$(cd "$(dirname "$0")/.." && pwd)"
test -f "$root/flutter/lib/core/models/sensitive_identity_bundle.dart"
grep -q 'class SensitiveIdentityBundle' "$root/flutter/lib/core/models/sensitive_identity_bundle.dart"
grep -q 'SensitiveIdentityKeyRecord' "$root/flutter/lib/core/models/sensitive_identity_bundle.dart"
grep -q 'PBKDF2' "$root/flutter/lib/features/recovery/data/services/account_restoration_service.dart"
grep -q 'AesGcm' "$root/flutter/lib/features/recovery/data/services/account_restoration_service.dart"
echo 'AUDIT-020 static audit: PASS'
