#!/usr/bin/env python3
"""LocalLink Phase 14 smoke/stress test using only the Python standard library.

Required environment:
  LOCALLINK_BASE_URL=http://127.0.0.1:8080
  LOCALLINK_DEVICE_ID=PHONE_A
  LOCALLINK_DEVICE_TOKEN=<token>
  LOCALLINK_RECIPIENT_ID=PHONE_B
Optional:
  LOCALLINK_MESSAGE_COUNT=130 (rate-limit regression test)
  LOCALLINK_TIMEOUT=10
"""
from __future__ import annotations
import concurrent.futures
import json
import os
import ssl
import sys
import time
import urllib.error
import urllib.request
import uuid

BASE = os.environ.get("LOCALLINK_BASE_URL", "http://127.0.0.1:8080").rstrip("/")
DEVICE = os.environ.get("LOCALLINK_DEVICE_ID", "").strip()
TOKEN = os.environ.get("LOCALLINK_DEVICE_TOKEN", "").strip()
RECIPIENT = os.environ.get("LOCALLINK_RECIPIENT_ID", "").strip()
COUNT = int(os.environ.get("LOCALLINK_MESSAGE_COUNT", "130"))
TIMEOUT = float(os.environ.get("LOCALLINK_TIMEOUT", "10"))

if not DEVICE or not TOKEN or not RECIPIENT:
    print("Set LOCALLINK_DEVICE_ID, LOCALLINK_DEVICE_TOKEN and LOCALLINK_RECIPIENT_ID", file=sys.stderr)
    raise SystemExit(2)

ctx = ssl._create_unverified_context() if BASE.startswith("https://") else None
HEADERS = {
    "Authorization": f"Bearer {TOKEN}",
    "X-Device-ID": DEVICE,
    "Content-Type": "application/json",
    "Accept": "application/json",
}


def post_message(i: int) -> tuple[int, float, str]:
    payload = {
        "id": str(uuid.uuid4()),
        "sender_id": DEVICE,
        "recipient_id": RECIPIENT,
        "body": f"phase14-stress-{i}-{uuid.uuid4().hex}",
    }
    req = urllib.request.Request(
        f"{BASE}/api/v1/messages",
        data=json.dumps(payload).encode(),
        headers=HEADERS,
        method="POST",
    )
    started = time.perf_counter()
    try:
        with urllib.request.urlopen(req, timeout=TIMEOUT, context=ctx) as r:
            body = r.read()
            return r.status, time.perf_counter() - started, body.decode(errors="replace")
    except urllib.error.HTTPError as e:
        return e.code, time.perf_counter() - started, e.read().decode(errors="replace")
    except Exception as e:
        return 0, time.perf_counter() - started, str(e)


def get_json(path: str):
    req = urllib.request.Request(f"{BASE}{path}", headers={k: v for k, v in HEADERS.items() if k != "Content-Type"})
    with urllib.request.urlopen(req, timeout=TIMEOUT, context=ctx) as r:
        return r.status, json.loads(r.read().decode())

print(f"LocalLink Phase 14 stress: {COUNT} concurrent message submissions")
started = time.perf_counter()
with concurrent.futures.ThreadPoolExecutor(max_workers=min(16, COUNT)) as pool:
    results = list(pool.map(post_message, range(COUNT)))
elapsed = time.perf_counter() - started

counts: dict[int, int] = {}
for status, _, _ in results:
    counts[status] = counts.get(status, 0) + 1
latencies = sorted(x[1] for x in results if x[0])
p50 = latencies[len(latencies)//2] if latencies else 0
p95 = latencies[min(len(latencies)-1, int(len(latencies)*0.95))] if latencies else 0
print(f"elapsed={elapsed:.2f}s throughput={COUNT/elapsed:.1f} req/s")
print(f"statuses={counts}")
print(f"latency_p50={p50:.3f}s latency_p95={p95:.3f}s")

# The backend deliberately limits each device to 120 messages/minute.
if counts.get(0, 0):
    print(f"FAIL: {counts[0]} requests failed at the transport/client level", file=sys.stderr)
    raise SystemExit(1)

if COUNT >= 125:
    accepted = counts.get(201, 0) + counts.get(200, 0)
    limited = counts.get(429, 0)
    expected_limited = COUNT - 120
    if accepted != 120 or limited != expected_limited:
        print(f"FAIL: expected 120 accepted and {expected_limited} rate-limited, got {accepted} and {limited}", file=sys.stderr)
        raise SystemExit(1)

status, _ = get_json("/health")
print(f"health_status={status}")
if status != 200:
    raise SystemExit(1)

print("PASS")
