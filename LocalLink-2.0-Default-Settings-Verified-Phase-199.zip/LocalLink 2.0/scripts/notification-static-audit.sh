#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
ANDROID="$ROOT/flutter/android/app/src/main/kotlin/com/sajjad/locallink"
DART="$ROOT/flutter/lib/core/notifications"
APP="$ROOT/flutter/lib/app/local_link_app.dart"

fail() { echo "FAIL: $1" >&2; exit 1; }
pass() { echo "PASS: $1"; }

grep -q 'locallink_messages_v2' "$ANDROID/LocalLinkNotificationManager.kt" || fail 'v2 message channel missing'
grep -q 'locallink_system_v2' "$ANDROID/LocalLinkNotificationManager.kt" || fail 'v2 system channel missing'
! grep -q 'setDeleteIntent' "$ANDROID/LocalLinkNotificationManager.kt" || fail 'notification delete intent still present'
grep -q 'notificationIdForDirectMessage' "$ROOT/flutter/lib/core/notifications/local_link_notification_service.dart" || fail 'exact direct notification IDs missing'
grep -q 'notificationIdForGroupMessage' "$ROOT/flutter/lib/core/notifications/local_link_notification_service.dart" || fail 'exact group notification IDs missing'
grep -q 'notificationStateMatches' "$ROOT/flutter/lib/core/notifications/local_link_notification_service.dart" || fail 'persisted action-state validation missing'
grep -q 'isBlockedPeer' "$ROOT/flutter/lib/core/notifications/local_link_notification_service.dart" || fail 'blocked-peer validation missing'
grep -q 'localAvatarPath' "$DART/notification_identity_resolver.dart" || fail 'avatar fallback resolver missing'
! grep -q 'notifications.requestPermission' "$APP" || fail 'startup notification permission request still present'
grep -q 'deletedMessageIds' "$ROOT/flutter/lib/core/services/local_store.dart" || fail 'message deletion invalidation event missing'
grep -q 'setPublicVersion' "$ANDROID/LocalLinkNotificationManager.kt" || fail 'Android private notification redaction missing'
grep -q 'policy.shouldBeSilent' "$ROOT/flutter/lib/core/notifications/local_link_notification_service.dart" || fail 'call/message silence integration missing'
grep -q 'notification_id.dart' "$ROOT/flutter/lib/core/notifications/local_link_notification_service.dart" || fail 'central notification ID helper missing'

pass 'N-FIX static notification invariants'
