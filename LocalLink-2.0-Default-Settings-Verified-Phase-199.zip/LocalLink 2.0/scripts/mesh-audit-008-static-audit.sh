#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
SERVICE="$ROOT/flutter/android/app/src/main/kotlin/com/sajjad/locallink/LocalLinkTransportService.kt"
POLICY="$ROOT/flutter/android/app/src/main/kotlin/com/sajjad/locallink/mesh/MeshTransportPolicy.kt"
for f in "$SERVICE" "$POLICY"; do test -f "$f"; done
grep -q 'LAN_BEACON_MAX_SIZE' "$SERVICE"
grep -q 'LAN_BEACON_MAX_AGE_MS' "$SERVICE"
grep -q 'LAN_BEACON_FUTURE_SKEW_MS' "$SERVICE"
grep -q 'address.isMulticastAddress' "$SERVICE"
grep -q 'lastLanBeaconAt' "$SERVICE"
grep -q 'handleRoutesAfterPeerDisconnect(nodeId, "lan_discovery_timeout")' "$SERVICE"
grep -q 'LAN_ENDPOINT_RETENTION_MS' "$POLICY"
grep -q 'LAN_DISCOVERY_PORT' "$POLICY"
echo 'AUDIT-008 static audit: PASS'
