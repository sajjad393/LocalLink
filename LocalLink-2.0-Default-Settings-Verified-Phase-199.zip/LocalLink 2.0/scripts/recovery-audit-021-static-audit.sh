#!/usr/bin/env bash
set -euo pipefail
root="$(cd "$(dirname "$0")/.." && pwd)"
test -f "$root/backend/internal/httpapi/phase43_account_recovery_test.go"
grep -q 'replay' "$root/backend/internal/httpapi/phase43_account_recovery_test.go"
grep -q 'expired' "$root/backend/internal/httpapi/phase43_account_recovery_test.go"
grep -q 'revoked' "$root/backend/internal/httpapi/phase43_account_recovery_test.go"
grep -q 'target_identity_public_key' "$root/backend/internal/httpapi/recovery.go"
echo 'AUDIT-021 static audit: PASS'
