#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
MESH="$ROOT/flutter/android/app/src/main/kotlin/com/sajjad/locallink/mesh"
ROUTE="$MESH/MeshRoute.kt"
TABLE="$MESH/MeshRouteTable.kt"
ROUTER="$MESH/MeshRouter.kt"
SERVICE="$ROOT/flutter/android/app/src/main/kotlin/com/sajjad/locallink/LocalLinkTransportService.kt"
TEST="$ROOT/flutter/android/app/src/test/kotlin/com/sajjad/locallink/mesh/MeshRoutingTest.kt"
for f in "$ROUTE" "$TABLE" "$ROUTER" "$SERVICE" "$TEST"; do test -f "$f"; done

grep -q 'DISCOVERED' "$ROUTE"
grep -q 'ACTIVE' "$ROUTE"
grep -q 'STALE' "$ROUTE"
grep -q 'INVALID' "$ROUTE"
grep -q 'RECOVERING' "$ROUTE"
grep -q 'REMOVED' "$ROUTE"
grep -q 'routeVersion > route.routeVersion' "$TABLE"
grep -q 'sameTopology' "$TABLE"
grep -q 'path\[1\] != route.nextHopNodeId' "$TABLE"
grep -q 'localNodeId' "$TABLE"
grep -q 'markRecoveringVia' "$ROUTER"
grep -q 'route_protocol_version' "$SERVICE"
grep -q 'advertisement.optString("sender_id").trim() != peerId' "$SERVICE"
grep -q 'optJSONObject(i)' "$SERVICE"
! grep -q 'Legacy route advertisements contained only destination IDs' "$SERVICE"
grep -q 'private val routeTable = MeshRouteTable { transportDeviceId }' "$SERVICE"
grep -q 'routeTableRejectsEqualVersionTopologyMutation' "$TEST"
echo 'AUDIT-006 static audit: PASS'
