param([string]$BaseUrl = $env:LOCALLINK_BASE_URL)
if ([string]::IsNullOrWhiteSpace($BaseUrl)) { $BaseUrl = "http://127.0.0.1:8080" }

Write-Host "Health: " -NoNewline
Invoke-WebRequest "$BaseUrl/health" -UseBasicParsing | Out-Null
Write-Host "OK"
Write-Host "Status: " -NoNewline
Invoke-WebRequest "$BaseUrl/api/v1/status" -UseBasicParsing | Out-Null
Write-Host "OK"
Write-Host "Backend smoke test passed."
