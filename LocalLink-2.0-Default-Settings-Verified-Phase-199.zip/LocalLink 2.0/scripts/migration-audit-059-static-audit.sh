#!/usr/bin/env bash
set -euo pipefail
root="$(cd "$(dirname "$0")/.." && pwd)"
store="$root/backend/internal/store/store.go"
testfile="$root/backend/internal/store/store_test.go"

grep -q 'schema_migration_ledger' "$store"
grep -q 'strict-ordered-migration-framework' "$store"
grep -q 'strictMigrationChecksum' "$store"
grep -q 'validateLegacyMigrationHistory' "$store"
grep -q 'migration ordering violation' "$store"
grep -q 'database schema version %d is newer than this binary supports' "$store"
grep -q 'schema_migration_ledger' "$testfile"
grep -q 'TestPhase59RejectsLegacySchemaGap' "$testfile"
grep -q 'TestPhase59RejectsLedgerChecksumDrift' "$testfile"
grep -q 'TestPhase59RejectsDatabaseFromFutureMigration' "$testfile"
grep -q 'TestPhase59StrictMigrationLedgerIdempotentAcrossRestart' "$testfile"

if grep -nE 'INSERT OR IGNORE INTO schema_migrations\(version\) VALUES\(5[1-9]' "$store"; then
  echo "FAIL: strict migrations must use transactional plain INSERT markers" >&2
  exit 1
fi

echo 'PHASE-59 migration static audit: PASS'
