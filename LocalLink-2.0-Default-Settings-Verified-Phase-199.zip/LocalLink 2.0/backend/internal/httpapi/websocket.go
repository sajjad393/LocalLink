package httpapi

import (
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"net/http"
	"strings"
	"time"

	"locallink/backend/internal/ws"
)

type WSMessage struct {
	Type                        string       `json:"type"`
	ID                          string       `json:"id,omitempty"`
	SenderID                    string       `json:"sender_id,omitempty"`
	RecipientID                 string       `json:"recipient_id,omitempty"`
	Body                        string       `json:"body,omitempty"`
	CreatedAt                   string       `json:"created_at,omitempty"`
	Status                      string       `json:"status,omitempty"`
	ClientMessageID             string       `json:"client_message_id,omitempty"`
	ServerSeq                   int64        `json:"server_seq,omitempty"`
	GroupID                     string       `json:"group_id,omitempty"`
	AttachmentIDs               []string     `json:"attachment_ids,omitempty"`
	Attachments                 []Attachment `json:"attachments,omitempty"`
	CallID                      string       `json:"call_id,omitempty"`
	SDP                         string       `json:"sdp,omitempty"`
	SDPType                     string       `json:"sdp_type,omitempty"`
	Candidate                   string       `json:"candidate,omitempty"`
	SDPMLineIndex               int          `json:"sdp_m_line_index,omitempty"`
	SDPMid                      string       `json:"sdp_mid,omitempty"`
	Reason                      string       `json:"reason,omitempty"`
	TransportMode               string       `json:"transport_mode,omitempty"`
	SelectedMediaCodec          string       `json:"selected_media_codec,omitempty"`
	Error                       string       `json:"error,omitempty"`
	DeviceID                    string       `json:"device_id,omitempty"`
	NetworkStatus               string       `json:"network_status,omitempty"`
	ServerConnected             bool         `json:"server_connected,omitempty"`
	InternetAvailable           bool         `json:"internet_available,omitempty"`
	WiFiDirectConnected         bool         `json:"wifi_direct_connected,omitempty"`
	StatusUpdatedAt             string       `json:"status_updated_at,omitempty"`
	LastSeenAt                  string       `json:"last_seen_at,omitempty"`
	GatewayID                   string       `json:"gateway_id,omitempty"`
	GatewayNodeID               string       `json:"node_id,omitempty"`
	GatewaySessionID            string       `json:"gateway_session_id,omitempty"`
	GatewayNonce                string       `json:"gateway_nonce,omitempty"`
	GatewaySignature            string       `json:"gateway_signature,omitempty"`
	GatewayIdentityPublicKey    string       `json:"identity_public_key,omitempty"`
	SigningPublicKey            string       `json:"signing_public_key,omitempty"`
	GatewayRequestID            string       `json:"request_id,omitempty"`
	GatewayDestinationID        string       `json:"destination_id,omitempty"`
	GatewayPacket               string       `json:"gateway_packet,omitempty"`
	GatewayTunnelType           string       `json:"gateway_tunnel_type,omitempty"`
	GatewayUpstreamKbps         int          `json:"upstream_kbps,omitempty"`
	GatewayDownstreamKbps       int          `json:"downstream_kbps,omitempty"`
	GatewayPacketLossPercent    any          `json:"packet_loss_percent,omitempty"`
	GatewayHealthScore          any          `json:"health_score,omitempty"`
	GatewayBudgetLimitBytes     int64        `json:"budget_limit_bytes,omitempty"`
	GatewayBudgetUsedBytes      int64        `json:"budget_used_bytes,omitempty"`
	GatewayBudgetRemainingBytes int64        `json:"budget_remaining_bytes,omitempty"`
	GatewayBudgetResetAt        string       `json:"budget_reset_at,omitempty"`
	GatewayReachable            bool         `json:"reachable,omitempty"`
	GatewayNextHopID            string       `json:"next_hop_id,omitempty"`
	GatewayHopCount             int          `json:"hop_count,omitempty"`
	GatewayLatencyMs            any          `json:"latency_ms,omitempty"`
	GatewayAdvertisedAt         string       `json:"advertised_at,omitempty"`
	GatewayExpiresAt            string       `json:"expires_at,omitempty"`
	GatewayResolvedAt           string       `json:"resolved_at,omitempty"`
	GatewayAvailableSlots       int          `json:"available_slots,omitempty"`
	GatewayCapable              bool         `json:"gateway_capable,omitempty"`
	GatewayAvailable            bool         `json:"gateway_available,omitempty"`
	GatewayVersion              string       `json:"gateway_version,omitempty"`
	MaxGatewaySessions          int          `json:"max_gateway_sessions,omitempty"`
	CurrentGatewaySessions      int          `json:"current_gateway_sessions,omitempty"`
	LanAvailable                bool         `json:"lan_available,omitempty"`
	MeshAvailable               bool         `json:"mesh_available,omitempty"`
}

func (a *API) WebSocket(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodGet {
		w.Header().Set("Allow", http.MethodGet)
		writeError(w, http.StatusMethodNotAllowed, "GET is required")
		return
	}
	if !headerHasToken(r.Header.Values("Upgrade"), "websocket") || !headerHasToken(r.Header.Values("Connection"), "upgrade") || strings.TrimSpace(r.Header.Get("Sec-WebSocket-Version")) != "13" {
		writeError(w, http.StatusBadRequest, "invalid websocket upgrade headers")
		return
	}
	deviceID := strings.TrimSpace(r.Header.Get("X-Device-ID"))
	auth := strings.TrimSpace(r.Header.Get("Authorization"))
	if deviceID == "" || auth == "" || !strings.HasPrefix(strings.ToLower(auth), "bearer ") {
		writeError(w, http.StatusUnauthorized, "device credentials must use X-Device-ID and Authorization: Bearer")
		return
	}
	if strings.TrimSpace(auth[len("Bearer "):]) == "" {
		writeError(w, http.StatusUnauthorized, "device credentials are required")
		return
	}
	if r.URL.Query().Get("token") != "" || r.URL.Query().Get("device_id") != "" {
		writeError(w, http.StatusForbidden, "websocket credentials must not be sent in query parameters")
		return
	}
	if _, ok := a.authorizeDevice(r); !ok {
		writeError(w, http.StatusUnauthorized, "invalid device credentials")
		return
	}

	setSecurityHeaders(w)
	key := strings.TrimSpace(r.Header.Get("Sec-WebSocket-Key"))
	if !validWebSocketKey(key) {
		writeError(w, http.StatusBadRequest, "websocket upgrade required")
		return
	}
	hj, ok := w.(http.Hijacker)
	if !ok {
		writeError(w, http.StatusInternalServerError, "websocket unsupported")
		return
	}
	conn, rw, err := hj.Hijack()
	if err != nil {
		return
	}
	if err := ws.Handshake(conn, key); err != nil {
		_ = conn.Close()
		return
	}

	client := ws.NewClient(deviceID, conn)
	a.hub.Add(deviceID, client)
	if d, changed := a.setPresence(deviceID, true, false, false); changed {
		a.broadcastPresence(deviceID, d)
	}
	defer func() {
		a.hub.Remove(deviceID, client)
		client.Close()
		if !a.hub.HasDevice(deviceID) {
			d, _ := a.setPresence(deviceID, false, false, false)
			a.broadcastPresence(deviceID, d)
		}
	}()

	_ = client.WriteText(mustJSON(WSMessage{Type: "ready", CreatedAt: time.Now().UTC().Format(time.RFC3339Nano)}))

	stopPing := make(chan struct{})
	defer close(stopPing)
	go func() {
		ticker := time.NewTicker(30 * time.Second)
		defer ticker.Stop()
		for {
			select {
			case <-ticker.C:
				if err := client.WritePing(nil); err != nil {
					_ = conn.Close()
					return
				}
			case <-stopPing:
				return
			}
		}
	}()

	for {
		_ = client.SetDeadline(time.Now().Add(90 * time.Second))
		opcode, payload, err := ws.ReadFrame(rw.Reader)
		if err != nil {
			return
		}
		switch opcode {
		case ws.TextFrame:
			var msg WSMessage
			if json.Unmarshal(payload, &msg) != nil {
				_ = client.WriteText(mustJSON(WSMessage{Type: "error", Error: "invalid JSON"}))
				continue
			}
			switch msg.Type {
			case "presence_update":
				if !a.allowPresenceUpdate(deviceID) {
					_ = client.WriteText(mustJSON(WSMessage{Type: "error", Error: "presence update rate limit exceeded"}))
					continue
				}
				presence := DevicePresence{ServerConnected: true, InternetAvailable: msg.InternetAvailable, WiFiDirectConnected: msg.WiFiDirectConnected, LanAvailable: msg.LanAvailable, MeshAvailable: msg.MeshAvailable, GatewayCapable: msg.GatewayCapable, GatewayAvailable: msg.GatewayAvailable, GatewayVersion: msg.GatewayVersion, MaxGatewaySessions: msg.MaxGatewaySessions, CurrentGatewaySessions: msg.CurrentGatewaySessions, LastCapabilityUpdate: msg.StatusUpdatedAt, SigningPublicKey: msg.SigningPublicKey}
				d, changed := a.setPresence(deviceID, true, msg.InternetAvailable, msg.WiFiDirectConnected, presence)
				if changed {
					a.broadcastPresence(deviceID, d)
				}
				continue
			case "gateway_advertisement", "gateway_route_query", "gateway_route_response", "gateway_session_create", "gateway_session_accept", "gateway_session_reject", "gateway_call_signal", "gateway_tunnel_signal", "gateway_packet", "gateway_session_close":
				if a.handleGatewayWSMessage(client, deviceID, msg) {
					continue
				}
			case "call_invite":
				if strings.TrimSpace(msg.RecipientID) == "" || strings.TrimSpace(msg.CallID) == "" {
					_ = client.WriteText(mustJSON(WSMessage{Type: "error", CallID: msg.CallID, Error: "recipient_id and call_id are required for call_invite"}))
					continue
				}
				if msg.RecipientID == deviceID || !a.deviceExists(msg.RecipientID) {
					_ = client.WriteText(mustJSON(WSMessage{Type: "error", CallID: msg.CallID, Error: "recipient device not found"}))
					continue
				}
				if !a.allowCallSignaling(deviceID) {
					_ = client.WriteText(mustJSON(WSMessage{Type: "error", CallID: msg.CallID, Error: "call signaling rate limit exceeded"}))
					continue
				}
				call, existing, err := a.createCall(deviceID, msg.RecipientID, msg.CallID)
				if err != nil {
					_ = client.WriteText(mustJSON(WSMessage{Type: "error", CallID: msg.CallID, Error: err.Error()}))
					continue
				}
				_ = client.WriteText(mustJSON(WSMessage{Type: "call_invite_ack", CallID: call.ID, SenderID: call.CallerID, RecipientID: call.CalleeID, Status: call.Status, CreatedAt: call.StartedAt}))
				if !existing {
					a.hub.SendTo(call.CalleeID, mustJSON(WSMessage{Type: "call_invite", CallID: call.ID, SenderID: call.CallerID, RecipientID: call.CalleeID, Status: call.Status, CreatedAt: call.StartedAt}))
				}
			case "call_accept", "call_reject", "call_end", "call_busy":
				if strings.TrimSpace(msg.CallID) == "" {
					_ = client.WriteText(mustJSON(WSMessage{Type: "error", Error: "call_id is required"}))
					continue
				}
				call, err := a.callForParticipant(msg.CallID, deviceID)
				if err != nil {
					_ = client.WriteText(mustJSON(WSMessage{Type: "error", CallID: msg.CallID, Error: err.Error()}))
					continue
				}
				if !a.allowCallSignaling(deviceID) {
					_ = client.WriteText(mustJSON(WSMessage{Type: "error", CallID: msg.CallID, Error: "call signaling rate limit exceeded"}))
					continue
				}
				status := "ended"
				if msg.Type == "call_accept" {
					if deviceID != call.CalleeID || call.Status != "ringing" {
						_ = client.WriteText(mustJSON(WSMessage{Type: "error", CallID: msg.CallID, Error: "only the callee can accept a ringing call"}))
						continue
					}
					status = "connected"
				} else if msg.Type == "call_reject" || msg.Type == "call_busy" {
					if deviceID != call.CalleeID || call.Status != "ringing" {
						_ = client.WriteText(mustJSON(WSMessage{Type: "error", CallID: msg.CallID, Error: "only the callee can reject a ringing call"}))
						continue
					}
					status = "rejected"
					if msg.Type == "call_busy" && msg.Reason == "" {
						msg.Reason = "busy"
					}
				} else if call.Status != "ringing" && call.Status != "connected" {
					_ = client.WriteText(mustJSON(WSMessage{Type: "error", CallID: msg.CallID, Error: "call is no longer active"}))
					continue
				}
				if msg.Type == "call_end" && strings.TrimSpace(msg.Reason) == "missed" {
					status = "missed"
				} else if msg.Type == "call_end" && strings.TrimSpace(msg.Reason) == "timeout" {
					status = "canceled"
				} else if msg.Type == "call_end" && strings.TrimSpace(msg.Reason) == "failed" {
					status = "failed"
				}
				updated, err := a.updateCallState(call.ID, deviceID, status, msg.Reason)
				if err != nil {
					_ = client.WriteText(mustJSON(WSMessage{Type: "error", CallID: msg.CallID, Error: err.Error()}))
					continue
				}
				peerID := updated.CalleeID
				if peerID == deviceID {
					peerID = updated.CallerID
				}
				_ = client.WriteText(mustJSON(WSMessage{Type: "call_state", CallID: updated.ID, SenderID: updated.CallerID, RecipientID: updated.CalleeID, Status: updated.Status, CreatedAt: updated.StartedAt, Reason: updated.EndReason}))
				a.hub.SendTo(peerID, mustJSON(WSMessage{Type: "call_state", CallID: updated.ID, SenderID: updated.CallerID, RecipientID: updated.CalleeID, Status: updated.Status, CreatedAt: updated.StartedAt, Reason: updated.EndReason}))
			case "call_transport_switch_request", "call_transport_switch_accept", "call_transport_switch_reject":
				if strings.TrimSpace(msg.CallID) == "" || strings.TrimSpace(msg.RecipientID) == "" {
					_ = client.WriteText(mustJSON(WSMessage{Type: "error", CallID: msg.CallID, Error: "call_id and recipient_id are required"}))
					continue
				}
				call, err := a.callForParticipant(msg.CallID, deviceID)
				if err != nil || call.Status != "connected" || msg.RecipientID != callOtherParticipant(call, deviceID) || !a.allowCallSignaling(deviceID) {
					_ = client.WriteText(mustJSON(WSMessage{Type: "error", CallID: msg.CallID, Error: "invalid transport switch request"}))
					continue
				}
				mode := strings.TrimSpace(msg.TransportMode)
				if mode != "offline_mesh" && mode != "webrtc" && mode != "internet_gateway" {
					_ = client.WriteText(mustJSON(WSMessage{Type: "error", CallID: msg.CallID, Error: "invalid transport mode"}))
					continue
				}
				a.hub.SendTo(msg.RecipientID, mustJSON(WSMessage{
					Type: msg.Type, CallID: call.ID, SenderID: deviceID, RecipientID: msg.RecipientID,
					TransportMode: mode, SelectedMediaCodec: msg.SelectedMediaCodec, Reason: msg.Reason,
					GatewayID: msg.GatewayID, GatewaySessionID: msg.GatewaySessionID, GatewayNonce: msg.GatewayNonce,
					GatewaySignature: msg.GatewaySignature, GatewayIdentityPublicKey: msg.GatewayIdentityPublicKey,
					SigningPublicKey: msg.SigningPublicKey, GatewayHopCount: msg.GatewayHopCount, GatewayLatencyMs: msg.GatewayLatencyMs,
				}))
			case "call_recover":
				if strings.TrimSpace(msg.CallID) == "" || strings.TrimSpace(msg.RecipientID) == "" {
					_ = client.WriteText(mustJSON(WSMessage{Type: "error", CallID: msg.CallID, Error: "call_id and recipient_id are required"}))
					continue
				}
				call, err := a.callForParticipant(msg.CallID, deviceID)
				if err != nil || call.Status != "connected" || msg.RecipientID != callOtherParticipant(call, deviceID) || !a.allowCallSignaling(deviceID) {
					_ = client.WriteText(mustJSON(WSMessage{Type: "error", CallID: msg.CallID, Error: "invalid recovery request"}))
					continue
				}
				reconnecting := mustJSON(WSMessage{Type: "call_state", CallID: call.ID, SenderID: call.CallerID, RecipientID: call.CalleeID, Status: "reconnecting", CreatedAt: call.StartedAt, Reason: msg.Reason})
				_ = client.WriteText(reconnecting)
				a.hub.SendTo(msg.RecipientID, reconnecting)
				a.hub.SendTo(msg.RecipientID, mustJSON(WSMessage{Type: "call_recover", CallID: call.ID, SenderID: deviceID, RecipientID: msg.RecipientID, Reason: msg.Reason}))
			case "call_heartbeat":
				if strings.TrimSpace(msg.CallID) == "" {
					_ = client.WriteText(mustJSON(WSMessage{Type: "error", CallID: msg.CallID, Error: "call_id is required"}))
					continue
				}
				if !a.allowCallHeartbeat(deviceID) {
					_ = client.WriteText(mustJSON(WSMessage{Type: "error", CallID: msg.CallID, Error: "call heartbeat rate limit exceeded"}))
					continue
				}
				call, err := a.TouchCall(msg.CallID, deviceID)
				if err != nil {
					_ = client.WriteText(mustJSON(WSMessage{Type: "error", CallID: msg.CallID, Error: err.Error()}))
					continue
				}
				_ = client.WriteText(mustJSON(WSMessage{Type: "call_heartbeat_ack", CallID: call.ID, Status: call.Status, CreatedAt: call.LastActivityAt}))
			case "call_offer", "call_answer", "call_candidate":
				if strings.TrimSpace(msg.CallID) == "" || strings.TrimSpace(msg.RecipientID) == "" {
					_ = client.WriteText(mustJSON(WSMessage{Type: "error", CallID: msg.CallID, Error: "call_id and recipient_id are required"}))
					continue
				}
				call, err := a.callForParticipant(msg.CallID, deviceID)
				if err != nil || msg.RecipientID != callOtherParticipant(call, deviceID) {
					_ = client.WriteText(mustJSON(WSMessage{Type: "error", CallID: msg.CallID, Error: "device is not a valid call participant"}))
					continue
				}
				if call.Status != "connected" || (msg.Type == "call_offer" && (deviceID != call.CallerID || msg.RecipientID != call.CalleeID)) || (msg.Type == "call_answer" && (deviceID != call.CalleeID || msg.RecipientID != call.CallerID)) {
					_ = client.WriteText(mustJSON(WSMessage{Type: "error", CallID: msg.CallID, Error: "invalid signaling role or call state"}))
					continue
				}
				if !a.deviceExists(msg.RecipientID) || !a.allowCallSignaling(deviceID) {
					_ = client.WriteText(mustJSON(WSMessage{Type: "error", CallID: msg.CallID, Error: "call signaling rate limit exceeded or recipient not found"}))
					continue
				}
				a.hub.SendTo(msg.RecipientID, mustJSON(WSMessage{Type: msg.Type, CallID: msg.CallID, SenderID: deviceID, RecipientID: msg.RecipientID, SDP: msg.SDP, SDPType: msg.SDPType, Candidate: msg.Candidate, SDPMLineIndex: msg.SDPMLineIndex, SDPMid: msg.SDPMid}))
			case "ack_delivery":
				if strings.TrimSpace(msg.ID) == "" {
					_ = client.WriteText(mustJSON(WSMessage{Type: "error", Error: "id is required for ack_delivery"}))
					continue
				}
				m, err := a.markDelivered(msg.ID, deviceID)
				if err != nil {
					errorText := "message not found"
					if errors.Is(err, errMessageRecipientOnly) {
						errorText = "device is not message recipient"
					}
					_ = client.WriteText(mustJSON(WSMessage{Type: "error", ID: msg.ID, Error: errorText}))
					continue
				}
				a.hub.SendTo(m.SenderID, mustJSON(WSMessage{Type: "delivery_ack", ID: m.ID, SenderID: m.SenderID, RecipientID: m.RecipientID, Status: m.Status, CreatedAt: m.DeliveredAt, ServerSeq: m.ServerSeq, Attachments: m.Attachments}))
			case "send_group_message":
				createdAt, timestampOK := normalizeGroupMessageCreatedAt(msg.CreatedAt)
				if strings.TrimSpace(msg.GroupID) == "" || !timestampOK || !strings.HasPrefix(msg.Body, "gme:v1:") || len(msg.Body) > maxEncryptedGroupMessageBody || len(msg.AttachmentIDs) > maxAttachmentsPerMessage {
					_ = client.WriteText(mustJSON(WSMessage{Type: "error", ID: msg.ID, Error: "encrypted group message, group_id and valid created_at are required; max 10 attachments"}))
					continue
				}
				if !a.isGroupMember(msg.GroupID, deviceID) {
					_ = client.WriteText(mustJSON(WSMessage{Type: "error", ID: msg.ID, Error: "device is not a group member"}))
					continue
				}
				if !a.allowMessage(deviceID) {
					_ = client.WriteText(mustJSON(WSMessage{Type: "error", ID: msg.ID, Error: "message rate limit exceeded"}))
					continue
				}
				m, existing, err := a.insertGroupMessage(deviceID, msg.GroupID, msg.Body, createdAt, msg.ID, msg.AttachmentIDs)
				if err != nil {
					_ = client.WriteText(mustJSON(WSMessage{Type: "error", ID: msg.ID, Error: err.Error()}))
					continue
				}
				_ = client.WriteText(mustJSON(WSMessage{Type: "group_message_ack", ID: m.ID, GroupID: m.GroupID, SenderID: m.SenderID, Body: m.Body, CreatedAt: m.CreatedAt, ServerSeq: m.ServerSeq, ClientMessageID: msg.ID, Attachments: m.Attachments}))
				if !existing {
					a.broadcastGroupMessage(m)
				}
			case "send_message":
				if strings.TrimSpace(msg.ID) == "" || len(msg.ID) > 128 || hasControlChars(msg.ID) || strings.TrimSpace(msg.RecipientID) == "" || len(msg.RecipientID) > 128 || hasControlChars(msg.RecipientID) || (msg.Body == "" && len(msg.AttachmentIDs) == 0) || len(msg.AttachmentIDs) > maxAttachmentsPerMessage {
					_ = client.WriteText(mustJSON(WSMessage{Type: "error", ID: msg.ID, Error: "message id, recipient_id and encrypted body or attachments are required; max 10 attachments"}))
					continue
				}
				if err := validateDirectE2EEnvelope(msg.Body, deviceID, msg.RecipientID, msg.ID); err != nil {
					_ = client.WriteText(mustJSON(WSMessage{Type: "error", ID: msg.ID, Error: err.Error()}))
					continue
				}
				if msg.SenderID != "" && msg.SenderID != deviceID {
					_ = client.WriteText(mustJSON(WSMessage{Type: "error", ID: msg.ID, Error: "sender_id does not match connection"}))
					continue
				}
				if msg.RecipientID == deviceID || !a.deviceExists(msg.RecipientID) {
					_ = client.WriteText(mustJSON(WSMessage{Type: "error", ID: msg.ID, Error: "recipient device not found"}))
					continue
				}
				if !a.allowMessage(deviceID) {
					_ = client.WriteText(mustJSON(WSMessage{Type: "error", ID: msg.ID, Error: "message rate limit exceeded"}))
					continue
				}
				m, existing, err := a.insertMessage(deviceID, msg.RecipientID, msg.Body, msg.ID, msg.AttachmentIDs)
				if err != nil {
					_ = client.WriteText(mustJSON(WSMessage{Type: "error", ID: msg.ID, Error: err.Error()}))
					continue
				}
				ack := WSMessage{Type: "message_ack", ID: m.ID, SenderID: m.SenderID, RecipientID: m.RecipientID, Body: m.Body, CreatedAt: m.CreatedAt, Status: m.Status, ClientMessageID: msg.ID, ServerSeq: m.ServerSeq, Attachments: m.Attachments}
				_ = client.WriteText(mustJSON(ack))
				if !existing {
					a.hub.SendTo(msg.RecipientID, mustJSON(WSMessage{Type: "message", ID: m.ID, SenderID: m.SenderID, RecipientID: m.RecipientID, Body: m.Body, CreatedAt: m.CreatedAt, Status: m.Status, ServerSeq: m.ServerSeq, Attachments: m.Attachments}))
				}
			default:
				_ = client.WriteText(mustJSON(WSMessage{Type: "error", Error: fmt.Sprintf("unsupported message type %q", msg.Type)}))
			}
		case ws.PingFrame:
			_ = client.WritePong(payload)
		case ws.CloseFrame:
			_ = client.WriteClose()
			return
		case ws.PongFrame:
		default:
			_ = client.WriteText(mustJSON(WSMessage{Type: "error", Error: "unsupported websocket opcode"}))
		}
	}
}
func mustJSON(v any) []byte { b, _ := json.Marshal(v); return b }

func headerHasToken(values []string, want string) bool {
	for _, value := range values {
		for _, part := range strings.Split(value, ",") {
			if strings.EqualFold(strings.TrimSpace(part), want) {
				return true
			}
		}
	}
	return false
}

func validWebSocketKey(value string) bool {
	b, err := base64.StdEncoding.DecodeString(value)
	return err == nil && len(b) == 16
}
