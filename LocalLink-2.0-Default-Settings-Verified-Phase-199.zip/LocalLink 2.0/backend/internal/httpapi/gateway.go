package httpapi

import (
	"crypto/ed25519"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"strings"
	"time"

	"locallink/backend/internal/ws"
)

const (
	gatewayAdvertisementTTL = 35 * time.Second
	gatewaySessionTTL       = 5 * time.Minute
	gatewayMaxPacketBytes   = 256 * 1024
	gatewayMaxSignalBytes   = 32 * 1024
)

func (a *API) auditGatewayEvent(action, deviceID, detail string) {
	_ = a.auditSecurity(action, "", deviceID, "gateway", detail)
}

type GatewayAdvertisement struct {
	GatewayID              string    `json:"gateway_id"`
	NodeID                 string    `json:"node_id"`
	InternetAvailable      bool      `json:"internet_available"`
	LanAvailable           bool      `json:"lan_available"`
	WiFiDirectAvailable    bool      `json:"wifi_direct_available"`
	MeshAvailable          bool      `json:"mesh_available"`
	GatewayCapable         bool      `json:"gateway_capable"`
	GatewayAvailable       bool      `json:"gateway_available"`
	GatewayVersion         string    `json:"gateway_version"`
	MaxGatewaySessions     int       `json:"max_gateway_sessions"`
	CurrentGatewaySessions int       `json:"current_gateway_sessions"`
	AvailableSlots         int       `json:"available_slots"`
	LatencyMs              any       `json:"latency_ms"`
	UpstreamKbps           int       `json:"upstream_kbps"`
	DownstreamKbps         int       `json:"downstream_kbps"`
	PacketLossPercent      any       `json:"packet_loss_percent"`
	HealthScore            any       `json:"health_score"`
	BudgetLimitBytes       int64     `json:"budget_limit_bytes"`
	BudgetUsedBytes        int64     `json:"budget_used_bytes"`
	BudgetRemainingBytes   int64     `json:"budget_remaining_bytes"`
	BudgetResetAt          string    `json:"budget_reset_at"`
	IdentityPublicKey      string    `json:"identity_public_key"`
	SigningPublicKey       string    `json:"signing_public_key"`
	AdvertisedAt           time.Time `json:"advertised_at"`
	ExpiresAt              time.Time `json:"expires_at"`
}

type GatewaySessionRecord struct {
	SessionID     string
	GatewayID     string
	CallerID      string
	DestinationID string
	Nonce         string
	CreatedAt     time.Time
	ExpiresAt     time.Time
	CreatedAtText string
	ExpiresAtText string
}

func gatewayCanonicalAdvertisement(msg WSMessage) ([]byte, error) {
	if _, err := time.Parse(time.RFC3339Nano, msg.GatewayAdvertisedAt); err != nil {
		return nil, fmt.Errorf("invalid advertised_at")
	}
	if _, err := time.Parse(time.RFC3339Nano, msg.GatewayExpiresAt); err != nil {
		return nil, fmt.Errorf("invalid expires_at")
	}
	// Preserve the exact RFC3339 strings used by the device signature.
	// Re-formatting through time.Time could drop explicit .000 fractional seconds.
	v := struct {
		GatewayID              string `json:"gateway_id"`
		NodeID                 string `json:"node_id"`
		InternetAvailable      bool   `json:"internet_available"`
		LanAvailable           bool   `json:"lan_available"`
		WiFiDirectAvailable    bool   `json:"wifi_direct_available"`
		MeshAvailable          bool   `json:"mesh_available"`
		GatewayCapable         bool   `json:"gateway_capable"`
		GatewayAvailable       bool   `json:"gateway_available"`
		GatewayVersion         string `json:"gateway_version"`
		MaxGatewaySessions     int    `json:"max_gateway_sessions"`
		CurrentGatewaySessions int    `json:"current_gateway_sessions"`
		AvailableSlots         int    `json:"available_slots"`
		LatencyMs              any    `json:"latency_ms"`
		UpstreamKbps           int    `json:"upstream_kbps"`
		DownstreamKbps         int    `json:"downstream_kbps"`
		PacketLossPercent      any    `json:"packet_loss_percent"`
		HealthScore            any    `json:"health_score"`
		BudgetLimitBytes       int64  `json:"budget_limit_bytes"`
		BudgetUsedBytes        int64  `json:"budget_used_bytes"`
		BudgetRemainingBytes   int64  `json:"budget_remaining_bytes"`
		BudgetResetAt          string `json:"budget_reset_at"`
		IdentityPublicKey      string `json:"identity_public_key"`
		SigningPublicKey       string `json:"signing_public_key"`
		AdvertisedAt           string `json:"advertised_at"`
		ExpiresAt              string `json:"expires_at"`
	}{msg.GatewayID, msg.GatewayNodeID, msg.InternetAvailable, msg.LanAvailable, msg.WiFiDirectAvailable, msg.MeshAvailable, msg.GatewayCapable, msg.GatewayAvailable, msg.GatewayVersion, msg.MaxGatewaySessions, msg.CurrentGatewaySessions, msg.GatewayAvailableSlots, msg.GatewayLatencyMs, msg.GatewayUpstreamKbps, msg.GatewayDownstreamKbps, msg.GatewayPacketLossPercent, msg.GatewayHealthScore, msg.GatewayBudgetLimitBytes, msg.GatewayBudgetUsedBytes, msg.GatewayBudgetRemainingBytes, msg.GatewayBudgetResetAt, msg.GatewayIdentityPublicKey, msg.SigningPublicKey, msg.GatewayAdvertisedAt, msg.GatewayExpiresAt}
	return json.Marshal(v)
}

func gatewayCanonicalSession(msg WSMessage, expiresAt time.Time) ([]byte, error) {
	if _, err := time.Parse(time.RFC3339Nano, msg.CreatedAt); err != nil {
		return nil, errors.New("invalid created_at")
	}
	if expiresAt.IsZero() {
		if _, err := time.Parse(time.RFC3339Nano, msg.GatewayExpiresAt); err != nil {
			return nil, errors.New("invalid expires_at")
		}
	}
	expiresText := msg.GatewayExpiresAt
	if expiresText == "" {
		expiresText = expiresAt.UTC().Format(time.RFC3339Nano)
	}
	v := struct {
		SessionID     string `json:"session_id"`
		GatewayID     string `json:"gateway_id"`
		CallerID      string `json:"caller_id"`
		DestinationID string `json:"destination_id"`
		Nonce         string `json:"nonce"`
		CreatedAt     string `json:"created_at"`
		ExpiresAt     string `json:"expires_at"`
	}{msg.GatewaySessionID, msg.GatewayID, msg.SenderID, msg.GatewayDestinationID, msg.GatewayNonce, msg.CreatedAt, expiresText}
	return json.Marshal(v)
}

func gatewayCanonicalRoute(msg WSMessage) []byte {
	var nextHop any
	if strings.TrimSpace(msg.GatewayNextHopID) == "" {
		nextHop = nil
	} else {
		nextHop = msg.GatewayNextHopID
	}
	v := struct {
		GatewayID     string `json:"gateway_id"`
		DestinationID string `json:"destination_id"`
		Reachable     bool   `json:"reachable"`
		NextHopID     any    `json:"next_hop_id"`
		HopCount      int    `json:"hop_count"`
		LatencyMs     any    `json:"latency_ms"`
		ExpiresAt     string `json:"expires_at"`
		ResolvedAt    string `json:"resolved_at"`
		Reason        string `json:"reason"`
	}{msg.GatewayID, msg.GatewayDestinationID, msg.GatewayReachable, nextHop, msg.GatewayHopCount, msg.GatewayLatencyMs, msg.GatewayExpiresAt, msg.GatewayResolvedAt, msg.Reason}
	out, _ := json.Marshal(v)
	return out
}

func decodeGatewayPublicKey(value string) (ed25519.PublicKey, bool) {
	raw, err := base64.RawURLEncoding.DecodeString(strings.TrimSpace(value))
	if err != nil {
		raw, err = base64.StdEncoding.DecodeString(strings.TrimSpace(value))
	}
	if err != nil || len(raw) != ed25519.PublicKeySize {
		return nil, false
	}
	return ed25519.PublicKey(raw), true
}

func verifyGatewaySignature(publicKey, signature string, canonical []byte) bool {
	key, ok := decodeGatewayPublicKey(publicKey)
	if !ok {
		return false
	}
	sig, err := base64.RawURLEncoding.DecodeString(strings.TrimSpace(signature))
	if err != nil {
		sig, err = base64.StdEncoding.DecodeString(strings.TrimSpace(signature))
	}
	return err == nil && len(sig) == ed25519.SignatureSize && ed25519.Verify(key, canonical, sig)
}

func gatewaySignature(msg WSMessage) string {
	if strings.TrimSpace(msg.GatewaySignature) != "" {
		return strings.TrimSpace(msg.GatewaySignature)
	}
	return strings.TrimSpace(msg.Signature)
}

func (a *API) gatewayRememberSigningKey(deviceID, key string) bool {
	deviceID, key = strings.TrimSpace(deviceID), strings.TrimSpace(key)
	if deviceID == "" || key == "" {
		return false
	}
	a.gatewayMu.Lock()
	defer a.gatewayMu.Unlock()
	if old := a.gatewaySigning[deviceID]; old != "" && old != key {
		return false
	}
	a.gatewaySigning[deviceID] = key
	return true
}

func (a *API) gatewaySigningKey(deviceID string) string {
	a.gatewayMu.RLock()
	defer a.gatewayMu.RUnlock()
	return a.gatewaySigning[deviceID]
}

func (a *API) gatewaySession(id string) (GatewaySessionRecord, bool) {
	a.gatewayMu.RLock()
	defer a.gatewayMu.RUnlock()
	s, ok := a.gatewaySessions[id]
	if !ok || time.Now().After(s.ExpiresAt) {
		return GatewaySessionRecord{}, false
	}
	return s, true
}

func (a *API) gatewayStoreSession(s GatewaySessionRecord) {
	a.gatewayMu.Lock()
	a.gatewaySessions[s.SessionID] = s
	a.gatewayMu.Unlock()
}
func (a *API) gatewayDeleteSession(id string) {
	a.gatewayMu.Lock()
	delete(a.gatewaySessions, id)
	a.gatewayMu.Unlock()
}

func (a *API) gatewayCleanup() {
	now := time.Now()
	a.gatewayMu.Lock()
	for id, s := range a.gatewaySessions {
		if now.After(s.ExpiresAt) {
			delete(a.gatewaySessions, id)
		}
	}
	a.gatewayMu.Unlock()
}

// handleGatewayWSMessage consumes authenticated gateway control/signaling.
// Internet gateway media stays on the endpoint tunnel and is never decoded by the backend.
func (a *API) handleGatewayWSMessage(client *ws.Client, deviceID string, msg WSMessage) bool {
	switch msg.Type {
	case "gateway_advertisement":
		if !a.allowPresenceUpdate(deviceID) {
			_ = client.WriteText(mustJSON(WSMessage{Type: "gateway_error", Error: "gateway advertisement rate limit exceeded"}))
			a.auditGatewayEvent("gateway_rejected", deviceID, "reason=advertisement_rate_limit")
			return true
		}
		if msg.GatewayID == "" || msg.GatewayID != deviceID || (msg.GatewayNodeID != "" && msg.GatewayNodeID != deviceID) || msg.SigningPublicKey == "" || gatewaySignature(msg) == "" {
			_ = client.WriteText(mustJSON(WSMessage{Type: "gateway_error", Error: "invalid gateway advertisement"}))
			return true
		}
		canonical, err := gatewayCanonicalAdvertisement(msg)
		if err != nil || !verifyGatewaySignature(msg.SigningPublicKey, gatewaySignature(msg), canonical) || msg.GatewayExpiresAt == "" {
			_ = client.WriteText(mustJSON(WSMessage{Type: "gateway_error", Error: "gateway advertisement authentication failed"}))
			return true
		}
		exp, _ := time.Parse(time.RFC3339Nano, msg.GatewayExpiresAt)
		adv, _ := time.Parse(time.RFC3339Nano, msg.GatewayAdvertisedAt)
		if exp.Before(time.Now().Add(-5*time.Second)) || exp.After(time.Now().Add(gatewayAdvertisementTTL+10*time.Second)) || adv.After(time.Now().Add(5*time.Second)) {
			_ = client.WriteText(mustJSON(WSMessage{Type: "gateway_error", Error: "gateway advertisement expired or invalid"}))
			return true
		}
		if !a.gatewayRememberSigningKey(deviceID, msg.SigningPublicKey) {
			_ = client.WriteText(mustJSON(WSMessage{Type: "gateway_error", Error: "gateway signing key mismatch"}))
			return true
		}
		a.setPresenceFromGateway(deviceID, msg)
		a.auditGatewayEvent("gateway_registered", deviceID, "gateway_id="+msg.GatewayID+" version="+msg.GatewayVersion)
		forwarded := msg
		forwarded.RecipientID = ""
		forwarded.SenderID = deviceID
		for _, peer := range a.hub.DeviceIDs() {
			if peer != deviceID {
				forwarded.RecipientID = peer
				_ = a.hub.SendTo(peer, mustJSON(forwarded))
			}
		}
		return true
	case "gateway_route_query":
		if !a.allowCallSignaling(deviceID) {
			a.auditGatewayEvent("gateway_rejected", deviceID, "reason=route_query_rate_limit")
			return true
		}
		gatewayID := strings.TrimSpace(msg.GatewayID)
		if gatewayID == "" {
			gatewayID = strings.TrimSpace(msg.RecipientID)
		}
		destination := strings.TrimSpace(msg.GatewayDestinationID)
		if destination == "" {
			destination = strings.TrimSpace(msg.RecipientID)
		}
		if gatewayID == "" || gatewayID != deviceID || destination == "" || destination == deviceID {
			_ = client.WriteText(mustJSON(WSMessage{Type: "gateway_error", GatewayRequestID: msg.GatewayRequestID, Error: "invalid gateway route query"}))
			return true
		}
		// The gateway itself must answer reachability using its local MeshRouter.
		out := msg
		out.Type = "gateway_route_query"
		out.SenderID = deviceID
		out.RecipientID = gatewayID
		out.GatewayID = gatewayID
		out.GatewayDestinationID = destination
		_ = a.hub.SendTo(gatewayID, mustJSON(out))
		return true
	case "gateway_route_response":
		if msg.GatewayID != deviceID || msg.RecipientID == "" || msg.GatewayDestinationID == "" || gatewaySignature(msg) == "" {
			return true
		}
		if msg.SigningPublicKey == "" {
			msg.SigningPublicKey = a.gatewaySigningKey(deviceID)
		}
		if msg.SigningPublicKey == "" || msg.SigningPublicKey != a.gatewaySigningKey(deviceID) || !verifyGatewaySignature(msg.SigningPublicKey, gatewaySignature(msg), gatewayCanonicalRoute(msg)) {
			return true
		}
		a.hub.SendTo(msg.RecipientID, mustJSON(msg))
		return true
	case "gateway_session_create":
		if !a.allowCallSignaling(deviceID) {
			_ = client.WriteText(mustJSON(WSMessage{Type: "gateway_session_reject", GatewaySessionID: msg.GatewaySessionID, GatewayID: msg.GatewayID, Error: "gateway session rate limit exceeded"}))
			a.auditGatewayEvent("gateway_rejected", deviceID, "reason=session_rate_limit")
			return true
		}
		if msg.GatewayID == "" || msg.GatewayID == msg.SenderID || msg.GatewaySessionID == "" || msg.GatewayDestinationID == "" || msg.GatewayNonce == "" || msg.SigningPublicKey == "" || msg.GatewaySignature == "" {
			_ = client.WriteText(mustJSON(WSMessage{Type: "gateway_session_reject", GatewaySessionID: msg.GatewaySessionID, GatewayID: msg.GatewayID, Error: "invalid gateway session request"}))
			return true
		}
		if !a.deviceExists(msg.SenderID) || !a.deviceExists(msg.GatewayDestinationID) {
			_ = client.WriteText(mustJSON(WSMessage{Type: "gateway_session_reject", GatewaySessionID: msg.GatewaySessionID, GatewayID: msg.GatewayID, Error: "unknown participant"}))
			return true
		}
		signing := a.gatewaySigningKey(msg.SenderID)
		if signing != "" && signing != msg.SigningPublicKey {
			_ = client.WriteText(mustJSON(WSMessage{Type: "gateway_session_reject", GatewaySessionID: msg.GatewaySessionID, GatewayID: msg.GatewayID, Error: "caller signing key mismatch"}))
			return true
		}
		if _, ok := a.gatewaySession(msg.GatewaySessionID); ok {
			_ = client.WriteText(mustJSON(WSMessage{Type: "gateway_session_reject", GatewaySessionID: msg.GatewaySessionID, GatewayID: msg.GatewayID, Error: "gateway session already exists"}))
			a.auditGatewayEvent("gateway_rejected", deviceID, "reason=session_replay session_id="+msg.GatewaySessionID)
			return true
		}
		if !a.rememberGatewayNonce(msg.SenderID, msg.GatewayNonce) {
			_ = client.WriteText(mustJSON(WSMessage{Type: "gateway_session_reject", GatewaySessionID: msg.GatewaySessionID, GatewayID: msg.GatewayID, Error: "gateway nonce replay"}))
			a.auditGatewayEvent("gateway_rejected", deviceID, "reason=nonce_replay")
			return true
		}
		expires, _ := time.Parse(time.RFC3339Nano, msg.GatewayExpiresAt)
		canonical, err := gatewayCanonicalSession(msg, expires)
		if err != nil || !verifyGatewaySignature(msg.SigningPublicKey, msg.GatewaySignature, canonical) || expires.Before(time.Now()) || expires.After(time.Now().Add(gatewaySessionTTL+10*time.Second)) {
			_ = client.WriteText(mustJSON(WSMessage{Type: "gateway_session_reject", GatewaySessionID: msg.GatewaySessionID, GatewayID: msg.GatewayID, Error: "session authentication failed"}))
			return true
		}
		a.gatewayStoreSession(GatewaySessionRecord{SessionID: msg.GatewaySessionID, GatewayID: msg.GatewayID, CallerID: msg.SenderID, DestinationID: msg.GatewayDestinationID, Nonce: msg.GatewayNonce, CreatedAt: time.Now().UTC(), ExpiresAt: expires, CreatedAtText: msg.CreatedAt, ExpiresAtText: msg.GatewayExpiresAt})
		a.auditGatewayEvent("gateway_session_created", deviceID, "session_id="+msg.GatewaySessionID+" destination="+msg.GatewayDestinationID)
		f := msg
		f.RecipientID = msg.GatewayID
		f.SenderID = msg.SenderID
		_ = a.hub.SendTo(msg.GatewayID, mustJSON(f))
		return true
	case "gateway_session_accept":
		sess, ok := a.gatewaySession(msg.GatewaySessionID)
		if !ok || sess.GatewayID != deviceID || msg.GatewayID != deviceID {
			return true
		}
		if msg.GatewaySignature == "" || msg.SigningPublicKey == "" || msg.SigningPublicKey != a.gatewaySigningKey(deviceID) || !verifyGatewaySignature(msg.SigningPublicKey, gatewaySignature(msg), gatewayCanonicalSession(WSMessage{GatewaySessionID: sess.SessionID, GatewayID: sess.GatewayID, SenderID: sess.CallerID, GatewayDestinationID: sess.DestinationID, GatewayNonce: sess.Nonce, CreatedAt: sess.CreatedAtText, GatewayExpiresAt: sess.ExpiresAtText}, sess.ExpiresAt)) {
			return true
		}
		f := msg
		f.RecipientID = sess.CallerID
		_ = a.hub.SendTo(sess.CallerID, mustJSON(f))
		return true
	case "gateway_session_reject":
		sess, ok := a.gatewaySession(msg.GatewaySessionID)
		if !ok || sess.GatewayID != deviceID {
			return true
		}
		f := msg
		f.RecipientID = sess.CallerID
		_ = a.hub.SendTo(sess.CallerID, mustJSON(f))
		a.gatewayDeleteSession(sess.SessionID)
		return true
	case "gateway_call_signal":
		return a.handleGatewayCallSignal(client, deviceID, msg)
	case "gateway_tunnel_signal":
		return a.handleGatewayTunnelSignal(client, deviceID, msg)
	case "gateway_packet":
		return a.handleGatewayPacket(client, deviceID, msg)
	case "gateway_session_close":
		if sess, ok := a.gatewaySession(msg.GatewaySessionID); ok && (deviceID == sess.GatewayID || deviceID == sess.CallerID || deviceID == sess.DestinationID) {
			a.gatewayDeleteSession(sess.SessionID)
			a.auditGatewayEvent("gateway_session_closed", deviceID, "session_id="+sess.SessionID)
			f := msg
			f.Type = "gateway_session_closed"
			f.RecipientID = callOtherGatewayParticipant(sess, deviceID)
			_ = a.hub.SendTo(f.RecipientID, mustJSON(f))
		}
		return true
	}
	a.gatewayCleanup()
	return false
}

func (a *API) setPresenceFromGateway(deviceID string, msg WSMessage) {
	now := time.Now().UTC().Format(time.RFC3339Nano)
	p := DevicePresence{ServerConnected: true, InternetAvailable: msg.InternetAvailable, WiFiDirectConnected: msg.WiFiDirectConnected, LanAvailable: msg.LanAvailable, MeshAvailable: msg.MeshAvailable, GatewayCapable: msg.GatewayCapable, GatewayAvailable: msg.GatewayAvailable, GatewayVersion: msg.GatewayVersion, MaxGatewaySessions: msg.MaxGatewaySessions, CurrentGatewaySessions: msg.CurrentGatewaySessions, LastCapabilityUpdate: now, SigningPublicKey: msg.SigningPublicKey, UpdatedAt: now}
	_, _ = a.setPresence(deviceID, true, msg.InternetAvailable, msg.WiFiDirectConnected, p)
}

func (a *API) handleGatewayCallSignal(client *ws.Client, deviceID string, msg WSMessage) bool {
	sess, ok := a.gatewaySession(msg.GatewaySessionID)
	if !ok || msg.GatewayID != sess.GatewayID {
		_ = client.WriteText(mustJSON(WSMessage{Type: "gateway_error", CallID: msg.CallID, GatewaySessionID: msg.GatewaySessionID, Error: "gateway session not found"}))
		return true
	}
	body := WSMessage{}
	if len(msg.Body) > gatewayMaxSignalBytes || json.Unmarshal([]byte(msg.Body), &body) != nil {
		_ = client.WriteText(mustJSON(WSMessage{Type: "gateway_error", CallID: msg.CallID, GatewaySessionID: msg.GatewaySessionID, Error: "invalid gateway call signal"}))
		return true
	}
	if deviceID != sess.GatewayID && deviceID != sess.CallerID && deviceID != sess.DestinationID {
		return true
	}
	if body.SenderID != "" && body.SenderID != deviceID && deviceID != sess.GatewayID {
		return true
	}
	destination := msg.GatewayDestinationID
	if destination == "" {
		destination = body.RecipientID
	}
	if destination != sess.CallerID && destination != sess.DestinationID {
		return true
	}
	if body.CallID != "" && msg.CallID != "" && body.CallID != msg.CallID {
		return true
	}
	if body.CallID == "" {
		body.CallID = msg.CallID
	}
	if body.Type == "call_invite" && deviceID == sess.CallerID {
		if _, existing, err := a.createCall(sess.CallerID, sess.DestinationID, body.CallID); err != nil || existing { /* idempotent */
		}
	}
	if body.Type == "call_accept" || body.Type == "call_reject" || body.Type == "call_busy" || body.Type == "call_end" {
		if call, err := a.callForParticipant(body.CallID, deviceID); err == nil {
			status := "ended"
			if body.Type == "call_accept" {
				status = "connected"
			} else if body.Type == "call_reject" || body.Type == "call_busy" {
				status = "rejected"
			} else if strings.TrimSpace(body.Reason) == "missed" {
				status = "missed"
			} else if strings.TrimSpace(body.Reason) == "timeout" {
				status = "canceled"
			} else if strings.TrimSpace(body.Reason) == "failed" {
				status = "failed"
			}
			_, _ = a.updateCallState(call.ID, deviceID, status, body.Reason)
		}
	}
	if body.Type == "call_heartbeat" {
		_, _ = a.TouchCall(body.CallID, deviceID)
	}
	f := msg
	f.Type = "gateway_call_signal"
	f.SenderID = body.SenderID
	f.GatewayDestinationID = destination
	f.Body = msg.Body
	f.CallID = body.CallID
	if deviceID == sess.GatewayID {
		f.RecipientID = destination
		_ = a.hub.SendTo(destination, mustJSON(f))
	} else {
		f.RecipientID = sess.GatewayID
		_ = a.hub.SendTo(sess.GatewayID, mustJSON(f))
	}
	return true
}

func (a *API) handleGatewayPacket(client *ws.Client, deviceID string, msg WSMessage) bool {
	_ = client
	if _, ok := a.gatewaySession(msg.GatewaySessionID); !ok {
		a.auditGatewayEvent("gateway_rejected", deviceID, "reason=backend_media_relay_disabled_unknown_session")
		return true
	}
	a.auditGatewayEvent("gateway_packet_rejected", deviceID, "reason=backend_media_relay_disabled session_id="+msg.GatewaySessionID)
	return true
}

func (a *API) handleGatewayTunnelSignal(client *ws.Client, deviceID string, msg WSMessage) bool {
	_ = client
	sess, ok := a.gatewaySession(msg.GatewaySessionID)
	if !ok || sess.GatewayID != msg.GatewayID || (deviceID != sess.GatewayID && deviceID != sess.DestinationID) || msg.RecipientID == "" || msg.RecipientID == deviceID {
		return true
	}
	if msg.RecipientID != sess.GatewayID && msg.RecipientID != sess.DestinationID {
		return true
	}
	kind := strings.TrimSpace(msg.GatewayTunnelType)
	if kind != "offer" && kind != "answer" && kind != "candidate" {
		return true
	}
	if len(msg.SDP) > gatewayMaxSignalBytes || len(msg.Candidate) > gatewayMaxSignalBytes || len(msg.GatewayTunnelType) > 64 {
		return true
	}
	f := msg
	f.Type = "gateway_tunnel_signal"
	f.SenderID = deviceID
	_ = a.hub.SendTo(msg.RecipientID, mustJSON(f))
	return true
}

func callOtherGatewayParticipant(s GatewaySessionRecord, deviceID string) string {
	if deviceID == s.CallerID {
		return s.DestinationID
	}
	return s.CallerID
}
