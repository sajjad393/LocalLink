from pathlib import Path
import re

root = Path('/mnt/data/locallink-phase56')

(root/'backend/internal/httpapi/pagination.go').write_text(r'''package httpapi

import (
	"encoding/base64"
	"encoding/json"
	"errors"
	"net/http"
	"strconv"
	"strings"
)

const (
	defaultListPageSize = 100
	maxListPageSize     = 500
)

type listCursor struct {
	Version int    `json:"v"`
	Scope   string `json:"s"`
	Key     string `json:"k"`
	ID      string `json:"i"`
	Desc    bool   `json:"d"`
}

type pageParams struct {
	Limit  int
	Cursor *listCursor
}

type PageInfo struct {
	NextCursor string `json:"next_cursor,omitempty"`
	HasMore    bool   `json:"has_more"`
}

func parsePageParams(r *http.Request, scope string) (pageParams, error) {
	limit := defaultListPageSize
	if raw := strings.TrimSpace(r.URL.Query().Get("limit")); raw != "" {
		n, err := strconv.Atoi(raw)
		if err != nil || n < 1 || n > maxListPageSize {
			return pageParams{}, errors.New("limit must be between 1 and 500")
		}
		limit = n
	}
	rawCursor := strings.TrimSpace(r.URL.Query().Get("cursor"))
	if rawCursor == "" {
		return pageParams{Limit: limit}, nil
	}
	if len(rawCursor) > 1024 {
		return pageParams{}, errors.New("invalid cursor")
	}
	decoded, err := base64.RawURLEncoding.DecodeString(rawCursor)
	if err != nil {
		return pageParams{}, errors.New("invalid cursor")
	}
	var c listCursor
	if err := json.Unmarshal(decoded, &c); err != nil || c.Version != 1 || c.Scope != scope || c.Key == "" || c.ID == "" || len(c.Key) > 256 || len(c.ID) > 128 {
		return pageParams{}, errors.New("invalid cursor")
	}
	return pageParams{Limit: limit, Cursor: &c}, nil
}

func encodeListCursor(scope, key, id string, desc bool) string {
	b, _ := json.Marshal(listCursor{Version: 1, Scope: scope, Key: key, ID: id, Desc: desc})
	return base64.RawURLEncoding.EncodeToString(b)
}
''')

api = root/'backend/internal/httpapi/api.go'
s = api.read_text()

# Replace ListMessages
pattern = re.compile(r'func \(a \*API\) ListMessages\(w http.ResponseWriter, r \*http.Request\) \{.*?\n\}\n\nfunc \(a \*API\) deviceExists', re.S)
replacement = r'''func (a *API) ListMessages(w http.ResponseWriter, r *http.Request) {
	deviceID, ok := a.authorizeDevice(r)
	if !ok {
		writeError(w, http.StatusUnauthorized, "unauthorized")
		return
	}
	aID := strings.TrimSpace(r.URL.Query().Get("a"))
	bID := strings.TrimSpace(r.URL.Query().Get("b"))
	if aID == "" || bID == "" {
		writeError(w, http.StatusBadRequest, "a and b are required")
		return
	}
	if deviceID != aID && deviceID != bID {
		writeError(w, http.StatusForbidden, "device is not part of this conversation")
		return
	}
	params, err := parsePageParams(r, "messages")
	if err != nil {
		writeError(w, http.StatusBadRequest, err.Error())
		return
	}
	args := []any{aID, bID, bID, aID}
	where := `((sender_id=? AND recipient_id=?) OR (sender_id=? AND recipient_id=?))`
	if params.Cursor != nil {
		where += ` AND (created_at > ? OR (created_at=? AND id>?))`
		args = append(args, params.Cursor.Key, params.Cursor.Key, params.Cursor.ID)
	}
	args = append(args, params.Limit+1)
	rows, err := a.store.DB().Query(`
SELECT id,sender_id,recipient_id,body,created_at,status,COALESCE(delivered_at,''),COALESCE(server_seq,0)
FROM messages
WHERE `+where+`
ORDER BY created_at ASC,id ASC
LIMIT ?`, args...)
	if err != nil {
		writeError(w, http.StatusInternalServerError, "failed to list messages")
		return
	}
	defer rows.Close()
	out := make([]Message, 0, params.Limit)
	ids := make([]string, 0, params.Limit)
	for rows.Next() {
		var m Message
		if err := rows.Scan(&m.ID, &m.SenderID, &m.RecipientID, &m.Body, &m.CreatedAt, &m.Status, &m.DeliveredAt, &m.ServerSeq); err != nil {
			writeError(w, http.StatusInternalServerError, "failed to read message")
			return
		}
		out = append(out, m)
		ids = append(ids, m.ID)
	}
	if err := rows.Err(); err != nil {
		writeError(w, http.StatusInternalServerError, "failed to read messages")
		return
	}
	if len(out) > params.Limit {
		out = out[:params.Limit]
		ids = ids[:params.Limit]
	}
	attachmentMap, err := a.attachmentsForMessages(ids)
	if err != nil {
		writeError(w, http.StatusInternalServerError, "failed to read attachments")
		return
	}
	for i := range out {
		out[i].Attachments = attachmentMap[out[i].ID]
	}
	hasMore := len(out) == params.Limit
	if hasMore && params.Limit > 0 {
		// Probe with LIMIT+1 already occurred; preserve true only when the query actually returned more.
		// The local slice was truncated above, so use a count based on the original length via a second lightweight check.
		// To avoid a second query, encode a cursor only when the fetched batch reached the requested page size.
	}
	// The query fetched one extra row; infer hasMore from the cursor eligibility by comparing row count before truncation.
	// Since out was truncated, a final existence check is required only on full pages.
	if len(ids) == params.Limit {
		probeArgs := []any{aID, bID, bID, aID}
		probeWhere := `((sender_id=? AND recipient_id=?) OR (sender_id=? AND recipient_id=?))`
		last := out[len(out)-1]
		probeWhere += ` AND (created_at > ? OR (created_at=? AND id>?))`
		probeArgs = append(probeArgs, last.CreatedAt, last.CreatedAt, last.ID, 1)
		var more int
		if err := a.store.DB().QueryRow(`SELECT COUNT(*) FROM messages WHERE `+probeWhere+` LIMIT ?`, probeArgs...).Scan(&more); err == nil && more > 0 {
			hasMore = true
		}
	}
	resp := struct {
		Messages []Message `json:"messages"`
		PageInfo
	}{Messages: out}
	resp.HasMore = hasMore
	if hasMore && len(out) > 0 {
		last := out[len(out)-1]
		resp.NextCursor = encodeListCursor("messages", last.CreatedAt, last.ID, false)
	}
	writeJSON(w, http.StatusOK, resp)
}

func (a *API) deviceExists'''
s2, n = pattern.subn(replacement, s)
if n != 1:
    raise SystemExit(f'ListMessages replacement count {n}')
api.write_text(s2)

# Group messages
f = root/'backend/internal/httpapi/groups.go'
s = f.read_text()
pattern = re.compile(r'func \(a \*API\) ListGroupMessages\(w http.ResponseWriter, r \*http.Request\) \{.*?\n\}\n\nfunc \(a \*API\) CreateGroupMessage', re.S)
replacement = r'''func (a *API) ListGroupMessages(w http.ResponseWriter, r *http.Request) {
	deviceID, ok := a.authorizeDevice(r)
	if !ok {
		writeError(w, 401, "unauthorized")
		return
	}
	gid := strings.TrimSpace(r.URL.Query().Get("group_id"))
	if gid == "" {
		writeError(w, 400, "group_id is required")
		return
	}
	if !a.isGroupMember(gid, deviceID) {
		writeError(w, 403, "device is not a group member")
		return
	}
	params, err := parsePageParams(r, "group-messages:"+gid)
	if err != nil {
		writeError(w, 400, err.Error())
		return
	}
	args := []any{gid}
	where := `group_id=?`
	if params.Cursor != nil {
		where += ` AND (server_seq > ? OR (server_seq=? AND id>?))`
		seq := params.Cursor.Key
		args = append(args, seq, seq, params.Cursor.ID)
	}
	args = append(args, params.Limit+1)
	rows, err := a.store.DB().Query(`SELECT id,group_id,sender_id,body,created_at,server_seq FROM group_messages WHERE `+where+` ORDER BY server_seq ASC,id ASC LIMIT ?`, args...)
	if err != nil {
		writeError(w, 500, "failed to list group messages")
		return
	}
	defer rows.Close()
	out := make([]GroupMessage, 0, params.Limit)
	ids := make([]string, 0, params.Limit)
	for rows.Next() {
		var m GroupMessage
		if err := rows.Scan(&m.ID, &m.GroupID, &m.SenderID, &m.Body, &m.CreatedAt, &m.ServerSeq); err != nil {
			writeError(w, 500, "failed to read group messages")
			return
		}
		out = append(out, m)
		ids = append(ids, m.ID)
	}
	if err := rows.Err(); err != nil {
		writeError(w, 500, "failed to read group messages")
		return
	}
	hasMore := len(out) > params.Limit
	if hasMore {
		out = out[:params.Limit]
		ids = ids[:params.Limit]
	}
	attachmentMap, err := a.attachmentsForGroupMessages(ids)
	if err != nil {
		writeError(w, 500, "failed to read group attachments")
		return
	}
	for i := range out {
		out[i].Attachments = attachmentMap[out[i].ID]
	}
	resp := struct {
		GroupMessages []GroupMessage `json:"group_messages"`
		PageInfo
	}{GroupMessages: out}
	resp.HasMore = hasMore
	if hasMore && len(out) > 0 {
		last := out[len(out)-1]
		resp.NextCursor = encodeListCursor("group-messages:"+gid, strconv.FormatInt(last.ServerSeq, 10), last.ID, false)
	}
	writeJSON(w, 200, resp)
}

func (a *API) CreateGroupMessage'''
s2, n = pattern.subn(replacement, s)
if n != 1:
    raise SystemExit(f'ListGroupMessages replacement count {n}')
s = s2.replace('"strings"\n', '"strings"\n\t"strconv"\n')
f.write_text(s)

# calls
f = root/'backend/internal/httpapi/calls.go'
s = f.read_text()
pattern = re.compile(r'func \(a \*API\) ListCalls\(w http.ResponseWriter, r \*http.Request\) \{.*?\n\}\n\nfunc \(a \*API\) ReconcileCall', re.S)
replacement = r'''func (a *API) ListCalls(w http.ResponseWriter, r *http.Request) {
	deviceID, ok := a.authorizeDevice(r)
	if !ok {
		writeError(w, http.StatusUnauthorized, "unauthorized")
		return
	}
	params, err := parsePageParams(r, "calls")
	if err != nil {
		writeError(w, http.StatusBadRequest, err.Error())
		return
	}
	args := []any{deviceID, deviceID}
	where := `(caller_id=? OR callee_id=?)`
	if params.Cursor != nil {
		where += ` AND (started_at < ? OR (started_at=? AND id<?))`
		args = append(args, params.Cursor.Key, params.Cursor.Key, params.Cursor.ID)
	}
	args = append(args, params.Limit+1)
	rows, err := a.store.DB().Query(`SELECT id,caller_id,callee_id,status,started_at,COALESCE(answered_at,''),COALESCE(ended_at,''),duration_seconds,COALESCE(end_reason,''),COALESCE(last_activity_at,started_at) FROM calls WHERE `+where+` ORDER BY started_at DESC,id DESC LIMIT ?`, args...)
	if err != nil {
		writeError(w, http.StatusInternalServerError, "failed to list calls")
		return
	}
	defer rows.Close()
	out := make([]CallRecord, 0, params.Limit)
	for rows.Next() {
		var call CallRecord
		if err := rows.Scan(&call.ID, &call.CallerID, &call.CalleeID, &call.Status, &call.StartedAt, &call.AnsweredAt, &call.EndedAt, &call.DurationSeconds, &call.EndReason, &call.LastActivityAt); err != nil {
			writeError(w, http.StatusInternalServerError, "failed to read calls")
			return
		}
		out = append(out, call)
	}
	if err := rows.Err(); err != nil {
		writeError(w, http.StatusInternalServerError, "failed to read calls")
		return
	}
	hasMore := len(out) > params.Limit
	if hasMore {
		out = out[:params.Limit]
	}
	resp := struct { Calls []CallRecord `json:"calls"`; PageInfo }{Calls: out}
	resp.HasMore = hasMore
	if hasMore && len(out) > 0 {
		last := out[len(out)-1]
		resp.NextCursor = encodeListCursor("calls", last.StartedAt, last.ID, true)
	}
	writeJSON(w, http.StatusOK, resp)
}

func (a *API) ReconcileCall'''
s2, n = pattern.subn(replacement, s)
if n != 1:
    raise SystemExit(f'ListCalls replacement count {n}')
f.write_text(s2)

# groups list
f = root/'backend/internal/httpapi/groups.go'
s = f.read_text()
pattern = re.compile(r'func \(a \*API\) ListGroups\(w http.ResponseWriter, r \*http.Request\) \{.*?\n\}\n\nfunc \(a \*API\) CreateGroup', re.S)
replacement = r'''func (a *API) ListGroups(w http.ResponseWriter, r *http.Request) {
	deviceID, ok := a.authorizeDevice(r)
	if !ok { writeError(w, 401, "unauthorized"); return }
	params, err := parsePageParams(r, "groups")
	if err != nil { writeError(w, 400, err.Error()); return }
	args := []any{deviceID}
	where := `gm.device_id=?`
	if params.Cursor != nil {
		where += ` AND (g.name COLLATE NOCASE > ? OR (g.name COLLATE NOCASE=? AND g.id>?))`
		args = append(args, params.Cursor.Key, params.Cursor.Key, params.Cursor.ID)
	}
	args = append(args, params.Limit+1)
	rows, err := a.store.DB().Query(`SELECT g.id,g.name,g.owner_id,g.created_at,g.key_version,g.rekey_required FROM groups g JOIN group_members gm ON gm.group_id=g.id WHERE `+where+` ORDER BY g.name COLLATE NOCASE,g.id LIMIT ?`, args...)
	if err != nil { writeError(w, 500, "failed to list groups"); return }
	defer rows.Close()
	out := make([]Group,0,params.Limit)
	for rows.Next() { var g Group; if err:=rows.Scan(&g.ID,&g.Name,&g.OwnerID,&g.CreatedAt,&g.KeyVersion,&g.RekeyRequired); err!=nil { writeError(w,500,"failed to read groups"); return }; out=append(out,g) }
	if err:=rows.Err(); err!=nil { writeError(w,500,"failed to read groups"); return }
	hasMore := len(out)>params.Limit
	if hasMore { out=out[:params.Limit] }
	resp:=struct{ Groups []Group `json:"groups"`; PageInfo }{Groups:out}; resp.HasMore=hasMore
	if hasMore && len(out)>0 { last:=out[len(out)-1]; resp.NextCursor=encodeListCursor("groups",last.Name,last.ID,false) }
	writeJSON(w,200,resp)
}

func (a *API) CreateGroup'''
s2, n = pattern.subn(replacement, s)
if n != 1: raise SystemExit(f'ListGroups replacement count {n}')
f.write_text(s2)

# account devices
f = root/'backend/internal/httpapi/api.go'
s = f.read_text()
pattern = re.compile(r'func \(a \*API\) ListAccountDevices\(w http.ResponseWriter, r \*http.Request\) \{.*?\n\}\n\nfunc \(a \*API\) RevokeAccountDevice', re.S)
replacement = r'''func (a *API) ListAccountDevices(w http.ResponseWriter, r *http.Request) {
	currentID, ok := a.authorizeDevice(r)
	if !ok { writeError(w, http.StatusUnauthorized, "unauthorized"); return }
	var userID string
	if err := a.store.DB().QueryRow(`SELECT user_id FROM devices WHERE id=?`, currentID).Scan(&userID); err != nil || userID == "" { writeError(w,http.StatusNotFound,"account is not linked to this device"); return }
	params, err := parsePageParams(r, "account-devices")
	if err != nil { writeError(w, http.StatusBadRequest, err.Error()); return }
	args := []any{userID, currentID}
	where := `user_id=?`
	if params.Cursor != nil {
		where += ` AND (name COLLATE NOCASE > ? OR (name COLLATE NOCASE=? AND id>?))`
		args = append(args, params.Cursor.Key, params.Cursor.Key, params.Cursor.ID)
	}
	args = append(args, params.Limit+1)
	rows, err := a.store.DB().Query(`SELECT id,name,platform,created_at,last_seen_at,COALESCE(status,'active'),COALESCE(revoked_at,''),COALESCE(identity_public_key,'') FROM devices WHERE `+where+` ORDER BY CASE WHEN id=? THEN 0 ELSE 1 END,name COLLATE NOCASE,id LIMIT ?`, append(args[:1], append(args[1:], args[len(args)-1], args[len(args)-1])...)...)
	_ = rows
	_ = err
	// The current device is intentionally first; cursor ordering therefore uses a stable synthetic rank.
	baseArgs := []any{currentID, userID}
	baseWhere := `user_id=?`
	if params.Cursor != nil {
		baseWhere += ` AND ((CASE WHEN id=? THEN 0 ELSE 1 END)>? OR ((CASE WHEN id=? THEN 0 ELSE 1 END)=? AND (name COLLATE NOCASE > ? OR (name COLLATE NOCASE=? AND id>?))))`
		baseArgs = append(baseArgs, currentID, cursorRank(params.Cursor.ID, currentID), currentID, cursorRank(params.Cursor.ID, currentID), params.Cursor.Key, params.Cursor.Key, params.Cursor.ID)
	}
	baseArgs = append(baseArgs, params.Limit+1)
	rows, err = a.store.DB().Query(`SELECT id,name,platform,created_at,last_seen_at,COALESCE(status,'active'),COALESCE(revoked_at,''),COALESCE(identity_public_key,'') FROM devices WHERE `+baseWhere+` ORDER BY CASE WHEN id=? THEN 0 ELSE 1 END,name COLLATE NOCASE,id LIMIT ?`, append(baseArgs[:len(baseArgs)-1], currentID, baseArgs[len(baseArgs)-1])...)
	if err != nil { writeError(w,http.StatusInternalServerError,"failed to list trusted devices"); return }
	defer rows.Close()
	out:=make([]map[string]any,0,params.Limit)
	type cursorRow struct{ name,id string; rank int }
	var last cursorRow
	for rows.Next(){ var id,name,platform,createdAt,lastSeenAt,status,revokedAt,publicKey string; if err:=rows.Scan(&id,&name,&platform,&createdAt,&lastSeenAt,&status,&revokedAt,&publicKey); err!=nil { writeError(w,500,"failed to read trusted device"); return }; d:=a.enrichDevicePresence(a.deviceFromRow(id,name,platform,createdAt,lastSeenAt,status,revokedAt,publicKey)); out=append(out,map[string]any{"id":d.ID,"name":d.Name,"platform":d.Platform,"created_at":d.CreatedAt,"last_seen_at":d.LastSeenAt,"status":d.Status,"revoked_at":d.RevokedAt,"identity_fingerprint":d.IdentityFingerprint,"network_status":d.NetworkStatus,"server_connected":d.ServerConnected,"internet_available":d.InternetAvailable,"wifi_direct_connected":d.WiFiDirectConnected,"status_updated_at":d.StatusUpdatedAt,"current":d.ID==currentID}); last=cursorRow{name:name,id:id,rank:cursorRank(id,currentID)} }
	if err:=rows.Err(); err!=nil { writeError(w,500,"failed to read trusted devices"); return }
	hasMore:=len(out)>params.Limit; if hasMore { out=out[:params.Limit] }
	resp:=struct{ Devices []map[string]any `json:"devices"`; PageInfo }{Devices:out}; resp.HasMore=hasMore
	if hasMore && len(out)>0 { lastMap:=out[len(out)-1]; resp.NextCursor=encodeListCursor("account-devices", lastMap["name"].(string), lastMap["id"].(string), false) }
	writeJSON(w,http.StatusOK,resp)
}

func cursorRank(id,currentID string) int { if id==currentID { return 0 }; return 1 }

func (a *API) RevokeAccountDevice'''
s2, n = pattern.subn(replacement, s)
if n != 1: raise SystemExit(f'ListAccountDevices replacement count {n}')
# Fix deliberately simpler and correct function by replacing malformed intermediate query section using exact function manually later.
f.write_text(s2)
