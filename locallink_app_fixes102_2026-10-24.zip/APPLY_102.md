# Bundle 102 — Scenario B: complete offline-first registration

Register and use LocalLink **fully offline**: when no server is reachable the
account is created on the phone only (PBKDF2-HMAC-SHA256 180 000 iterations,
bit-identical to the backend's `derivePasswordKey`), mesh chat/calls work
immediately, and the account auto-publishes via the existing
`/api/v1/auth/register` the moment a server answers again. **Zero backend
changes.**

## What changes for the user

1. Register screen now offers **"Create account offline"** when (and only
   when) the server connection fails — a bordered card, not a new flow.
2. Offline signup stores only hash+salt in secure storage (no plaintext
   password anywhere), shows a recovery code in the exact backend format
   (`XXXXX-XXXXX-XXXXX-XXXXX`), and lands on the dashboard with mesh chat,
   calls, groups, notifications working. Server-backed features (presence,
   policies, directory sync) stay quiet.
3. A subtle banner tops the Chats tab: *"Account saved on this phone —
   publishes when the server is available."* Dismissible per launch.
4. When a server answers (dashboard entry check or banner tap), a sheet asks
   for the offline password once — verified locally first, then sent only to
   that server, with an optional pairing-code field. On 409 the same sheet
   asks for a new username and retries; on success it shows the **new,
   server-issued recovery code** (replaces the offline one) and starts the
   full app services in place.
5. Danger guard: "Reset setup" warns that an unpublished account is deleted
   permanently.
6. `initializeConfiguredServices()` is untouched for normal accounts; a new
   `initializeLocalOnlyServices()` boots the offline subset. All `start()`
   methods re-enter safely, so publishing mid-session starts the full stack
   without duplicates.

## Apply (from the localLink repo root)

```powershell
Expand-Archive -Force .\locallink_app_fixes102_2026-10-24.zip C:\temp\s102
robocopy C:\temp\s102\lib .\lib /E /XX
robocopy C:\temp\s102\test .\test /E /XX
```

(Each robocopy line copies the bundle's files over/into the repo; `/XX`
leaves your unrelated untracked files alone.)

## Verify

1. `flutter analyze lib test/password_kdf_test.dart` — expect no new issues.
2. `flutter test test/password_kdf_test.dart` — 6 tests green (vectors were
   validated byte-for-byte against a manual transcription of the Go KDF).
3. Manual flow:
   - Airplane mode / server off → Register → error appears →
     *Create account offline* → save code → dashboard opens, chats work.
   - Start server (or rejoin its network) → publish sheet prompts once →
     confirm password → new recovery code → banner gone.
   - Force a username clash for the rename picker; wrong password is caught
     locally without a network call.
4. The pairing-code field is only needed for `LOCALLINK_PAIRING_CODE`
   deployments.

## Notes

- Constants mirrored from `internal/httpapi/auth.go`: iterations 180 000,
  salt 16 bytes, key 32 bytes, RawURLEncoding storage, recovery code = 15
  random bytes → uppercase base64 with `+`→`A`, `/`→`B`.
- Offline re-login is not a separate screen: while `sync_state == local_only`
  the app boots straight into the shell; password proof happens at publish.
- If publishing is declined, it re-offers on next launch (or banner tap).
